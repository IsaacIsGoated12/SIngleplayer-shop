package dev.isaac.pocketshop;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents.Disconnect;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents.Init;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents.Join;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents.AfterInit;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents.Remove;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.HolderLookup.Provider;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.item.ItemStack;

public final class SellPricesClient implements ClientModInitializer {
   private static final RemotePriceState remotePrices = new RemotePriceState();
   private static Screen shopScreen;
   private static AbstractContainerMenu shopMenu;
   private static MinecraftServer priceServer;
   private static ShopCatalog priceCatalog;
   private static Provider priceRegistries;
   private static SellPriceIndex priceIndex;

   public void onInitializeClient() {
      TooltipOptions.load();
      net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
         dispatcher.register(com.mojang.brigadier.builder.LiteralArgumentBuilder.<net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource>literal("sellprices")
            .executes(context -> {
               TooltipOptions.enabled = !TooltipOptions.enabled;
               boolean saved=TooltipOptions.save();
               context.getSource().sendFeedback(net.minecraft.network.chat.Component.literal("Sell price tooltips " + (TooltipOptions.enabled ? "enabled" : "disabled") + (saved ? "." : ". Could not save this preference.")));
               return 1;
            })
            .then(com.mojang.brigadier.builder.LiteralArgumentBuilder.<net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource>literal("compact").executes(context -> {
               TooltipOptions.compact = !TooltipOptions.compact;
               boolean saved=TooltipOptions.save();
               context.getSource().sendFeedback(net.minecraft.network.chat.Component.literal("Compact sell prices " + (TooltipOptions.compact ? "enabled" : "disabled") + (saved ? "." : ". Could not save this preference.")));
               return 1;
            }))
            .then(com.mojang.brigadier.builder.LiteralArgumentBuilder.<net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource>literal("details").executes(context -> {
               TooltipOptions.details=!TooltipOptions.details;
               boolean saved=TooltipOptions.save();
               context.getSource().sendFeedback(net.minecraft.network.chat.Component.literal("Individual enchantment prices "+(TooltipOptions.details?"enabled":"hidden")+(saved?".":". Could not save preference.")));
               return 1;
            }))
            .then(com.mojang.brigadier.builder.LiteralArgumentBuilder.<net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource>literal("reload").executes(context -> {
               boolean loaded=TooltipOptions.load();
               context.getSource().sendFeedback(net.minecraft.network.chat.Component.literal(loaded ? "Sell price preferences reloaded." : "Invalid preferences; last working settings kept."));
               return loaded ? 1 : 0;
            })));
      });
      ClientPlayConnectionEvents.INIT.register((Init)(handler, client) -> {
         clearMenu();
         clearPrices();
         remotePrices.begin(handler);
      });
      ClientPlayConnectionEvents.JOIN.register((Join)(handler, sender, client) -> {
         clearPrices();
      });
      ClientPlayNetworking.registerGlobalReceiver(SellPricePayload.TYPE, (payload, context) -> {
         LocalPlayer player = context.player();
         ClientPacketListener connection = player.connection;
         context.client().execute(() -> {
            Minecraft client = context.client();
            if (client.player == player && client.level != null && client.getConnection() == connection) {
               remotePrices.receive(connection, payload, client.level.registryAccess());
            }
         });
      });
      ScreenEvents.AFTER_INIT
         .register(
            (AfterInit)(client, screen, width, height) -> {
               if (screen instanceof AbstractContainerScreen<?> container
                  && screen.getTitle().getString().startsWith("Singleplayer Shop ")
                  && container.getMenu() instanceof ChestMenu chest
                  && chest.getRowCount() == 6) {
                  shopScreen = screen;
                  shopMenu = container.getMenu();
                  ScreenEvents.remove(screen).register((Remove)removed -> {
                     if (shopScreen == removed) {
                        clearMenu();
                     }
                  });
               } else {
                  clearMenu();
               }
            }
         );
      ClientPlayConnectionEvents.DISCONNECT.register((Disconnect)(handler, client) -> {
         remotePrices.clear();
         clearMenu();
         clearPrices();
      });
      ItemTooltipCallback.EVENT.register((ItemTooltipCallback)(stack, context, type, lines) -> {
         Minecraft client = Minecraft.getInstance();
         if (TooltipOptions.enabled && client.player != null && client.level != null && !isShopIcon(client, stack)) {
            Provider registries = client.level.registryAccess();
            SellPriceIndex synchronizedPrices = remotePrices.indexFor(client.getConnection(), registries);
            if (synchronizedPrices != null) {
               SellPriceTooltip.appendIndex(synchronizedPrices, stack, lines);
            } else {
               MinecraftServer server = client.getSingleplayerServer();
               ShopCatalog catalog = ShopPriceState.catalogFor(server);
               if (catalog == null) {
                  clearPrices();
               } else {
                  if (catalog != priceCatalog || server != priceServer || registries != priceRegistries) {
                     priceIndex = SellPriceIndex.create(catalog, server.registryAccess(), registries);
                     priceServer = server;
                     priceCatalog = catalog;
                     priceRegistries = registries;
                  }

                  SellPriceTooltip.appendIndex(priceIndex, stack, lines);
               }
            }
         }
      });
   }

   public static boolean hasSyncedPrices() {
      Minecraft client = Minecraft.getInstance();
      return client.level != null && remotePrices.indexFor(client.getConnection(), client.level.registryAccess()) != null;
   }

   public static long syncedRevision() {
      return remotePrices.revision();
   }

   private static boolean isShopIcon(Minecraft client, ItemStack stack) {
      if (shopMenu != null && client.player.containerMenu == shopMenu) {
         for (int slot = 0; slot < Math.min(54, shopMenu.slots.size()); slot++) {
            if (shopMenu.getSlot(slot).getItem() == stack) {
               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   private static void clearMenu() {
      shopScreen = null;
      shopMenu = null;
   }

   private static void clearPrices() {
      priceServer = null;
      priceCatalog = null;
      priceRegistries = null;
      priceIndex = null;
   }
}
