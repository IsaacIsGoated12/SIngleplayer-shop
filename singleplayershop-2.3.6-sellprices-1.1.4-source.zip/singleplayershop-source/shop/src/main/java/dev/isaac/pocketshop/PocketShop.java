package dev.isaac.pocketshop;

import com.mojang.authlib.GameProfile;
import com.mojang.brigadier.arguments.LongArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents.EndDataPackReload;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.permissions.Permissions;
import net.minecraft.server.players.NameAndId;
import net.minecraft.world.SimpleMenuProvider;

public final class PocketShop implements ModInitializer {
   public static final String MOD_ID = "pocketshop";
   private static final org.slf4j.Logger LOGGER = org.slf4j.LoggerFactory.getLogger(MOD_ID);
   private static ShopCatalog catalog;
   private static ShopTransactions transactions;

   public void onInitialize() {
      PayCommand.initialize();
      SellAxe.register();
      ServerLifecycleEvents.SERVER_STARTED.register(PocketShop::loadCatalog);
      ServerLifecycleEvents.SERVER_STOPPED.register(server -> {
         catalog = null;
         transactions = null;
      });
      ServerLifecycleEvents.END_DATA_PACK_RELOAD.register((EndDataPackReload)(server, resources, success) -> {
         if (success) {
            loadCatalog(server);
         }
      });
      CommandRegistrationCallback.EVENT
         .register(
            (CommandRegistrationCallback)(dispatcher, registryAccess, environment) -> {
               PayCommand.register(dispatcher);
               ShopCommands.register(dispatcher);
               dispatcher.register(
                  (LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal(
                                    "shop"
                                 )
                                 .executes(context -> {
                                    openShop(((CommandSourceStack)context.getSource()).getPlayerOrException(), false);
                                    return 1;
                                 }))
                              .then(Commands.literal("earn").executes(context -> {
                                 openMenu(((CommandSourceStack)context.getSource()).getPlayerOrException(), "earn", "");
                                 return 1;
                              })))
                           .then(Commands.literal("enchants").executes(context -> {
                              openMenu(((CommandSourceStack)context.getSource()).getPlayerOrException(), "enchants", "");
                              return 1;
                           })))
                        .then(Commands.literal("potions").executes(context -> {
                           openMenu(((CommandSourceStack)context.getSource()).getPlayerOrException(), "potions", "");
                           return 1;
                        })))
                     .then(Commands.literal("search").then(Commands.argument("item", StringArgumentType.greedyString()).executes(context -> {
                        String query = StringArgumentType.getString(context, "item");
                        if (query.length() > 64) {
                           ((CommandSourceStack)context.getSource()).sendFailure(Component.literal("Keep your search under 65 characters."));
                           return 0;
                        } else {
                           openMenu(((CommandSourceStack)context.getSource()).getPlayerOrException(), "shop", query);
                           return 1;
                        }
                     })))
               );
               dispatcher.register((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("earn").executes(context -> {
                  openMenu(((CommandSourceStack)context.getSource()).getPlayerOrException(), "earn", "");
                  return 1;
               })).then(Commands.literal("prices").executes(context -> {
                  openMenu(((CommandSourceStack)context.getSource()).getPlayerOrException(), "prices", "");
                  return 1;
               }))).then(Commands.literal("search").then(Commands.argument("quest", StringArgumentType.greedyString()).executes(context -> {
                  String query = StringArgumentType.getString(context, "quest");
                  if (query.length() > 64) {
                     ((CommandSourceStack)context.getSource()).sendFailure(Component.literal("Keep your search under 65 characters."));
                     return 0;
                  } else {
                     openMenu(((CommandSourceStack)context.getSource()).getPlayerOrException(), "earn", query);
                     return 1;
                  }
               }))));
               dispatcher.register(
                  (LiteralArgumentBuilder)Commands.literal("worth")
                     .executes(
                        context -> {
                           ServerPlayer player = ((CommandSourceStack)context.getSource()).getPlayerOrException();
                           int slot = player.getInventory().getSelectedSlot();
                           ShopTransactions.Quote quote = transactions.quote(player.getInventory(), slot, slot + 1);
                           boolean shulker = SaleContents.isShulker(player.getInventory().getItem(slot));
                           player.sendSystemMessage(
                              Component.literal(
                                    shulker
                                       ? (
                                          quote.count() > 0
                                             ? "Shulker contents: "
                                                + quote.count()
                                                + " sellable items worth "
                                                + ShopTransactions.money(quote.total())
                                                + ". Shulker box kept."
                                             : "No sellable contents in this shulker box. Shulker box kept."
                                       )
                                       : (
                                          quote.count() > 0
                                             ? "Held stack: "
                                                + quote.count()
                                                + " items worth "
                                                + ShopTransactions.money(quote.total())
                                                + ". Use /sell to review."
                                             : "This held item is protected or has no sell price. Use /earn to see what you can sell."
                                       )
                                 )
                                 .withStyle(ChatFormatting.GOLD)
                           );
                           return 1;
                        }
                     )
               );
               dispatcher.register((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("sell").executes(context -> {
                  openSell(((CommandSourceStack)context.getSource()).getPlayerOrException());
                  return 1;
               })).then(Commands.literal("hand").executes(context -> {
                  ServerPlayer player = ((CommandSourceStack)context.getSource()).getPlayerOrException();
                  int selected = player.getInventory().getSelectedSlot();
                  feedback(player, transactions.sell(player.getInventory(), selected, selected + 1, wallets(player), player.getUUID()));
                  player.containerMenu.broadcastChanges();
                  return 1;
               }))).then(Commands.literal("all").executes(context -> {
                  openShop(((CommandSourceStack)context.getSource()).getPlayerOrException(), true);
                  return 1;
               })));
               dispatcher.register(
                  (LiteralArgumentBuilder)Commands.literal("balance")
                     .executes(context -> showBalance(((CommandSourceStack)context.getSource()).getPlayerOrException()))
               );
               dispatcher.register(
                  (LiteralArgumentBuilder)Commands.literal("bal")
                     .executes(context -> showBalance(((CommandSourceStack)context.getSource()).getPlayerOrException()))
               );
               dispatcher.register(
                  (LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("money")
                        .executes(context -> showBalance(((CommandSourceStack)context.getSource()).getPlayerOrException())))
                     .then(
                        ((LiteralArgumentBuilder)Commands.literal("give").requires(PocketShop::canManageMoney))
                           .then(
                              Commands.argument("amount", LongArgumentType.longArg(1L, 1000000000000L))
                                 .executes(
                                    context -> giveMoney(
                                       ((CommandSourceStack)context.getSource()).getPlayerOrException(), LongArgumentType.getLong(context, "amount")
                                    )
                                 )
                           )
                     )
               );
            }
         );
   }

   private static void loadCatalog(MinecraftServer server) {
      try {
         reloadCatalog(server);
      } catch (Exception exception) {
         if (catalog == null) {
            throw new IllegalStateException("Singleplayer Shop could not read config/pocketshop.json. " + exception.getMessage(), exception);
         }
         LOGGER.error("Shop reload rejected; continuing with the last working prices.", exception);
      }
   }

   static void reloadCatalog(MinecraftServer server) throws java.io.IOException {
      ShopCatalog replacement = ShopCatalog.load(FabricLoader.getInstance().getConfigDir().resolve("pocketshop.json"), server.registryAccess());
      ShopTransactions replacementTransactions = new ShopTransactions(replacement);
      for (ServerPlayer player : server.getPlayerList().getPlayers()) {
         if (player.containerMenu instanceof VanillaShopMenu) player.closeContainer();
      }
      catalog = replacement;
      transactions = replacementTransactions;
   }

   static ShopCatalog catalog() {
      return catalog;
   }

   static ShopTransactions transactions() {
      return transactions;
   }

   static Wallets wallets(ServerPlayer player) {
      return Wallets.get(player.level().getServer());
   }

   static long balance(ServerPlayer player) {
      return wallets(player).balance(player.getUUID(), catalog.startingBalance());
   }

   static void openShop(ServerPlayer player, boolean sellAll) {
      openMenu(player, sellAll ? "sell_all" : "shop", "");
   }

   static void openSellAxe(ServerPlayer player) { openMenu(player,"shop","sell axe"); }

   static void openSell(ServerPlayer player) {
      openMenu(player, "sell", "");
   }

   private static void openMenu(ServerPlayer player, String page, String query) {
      if (player.isAlive() && !player.isSpectator()) {
         player.openMenu(
            new SimpleMenuProvider(
               (id, inventory, ignored) -> new VanillaShopMenu(id, inventory, player, page, query),
               Component.literal("Singleplayer Shop ")
                  .withStyle(ChatFormatting.DARK_GRAY)
                  .append(Component.literal("2.3.6").withStyle(ChatFormatting.DARK_AQUA))
            )
         );
      }
   }

   static void feedback(ServerPlayer player, ShopTransactions.Result result) {
      player.sendSystemMessage(
         Component.literal("[Singleplayer Shop] ")
            .withStyle(ChatFormatting.GOLD)
            .append(Component.literal(result.message()).withStyle(result.success() ? ChatFormatting.GREEN : ChatFormatting.RED))
      );
      if (player.containerMenu != null) {
         player.containerMenu.broadcastChanges();
      }

      if (player.containerMenu instanceof VanillaShopMenu menu) {
         menu.refresh();
      }
   }

   private static boolean canManageMoney(CommandSourceStack source) {
      ServerPlayer player = source.getPlayer();
      if (player == null) {
         return false;
      }

      MinecraftServer server = source.getServer();
      if (!server.isSingleplayer()) {
         return source.permissions().hasPermission(Permissions.COMMANDS_GAMEMASTER);
      }

      GameProfile owner = server.getSingleplayerProfile();
      return owner != null && owner.id().equals(player.getUUID()) && server.isSingleplayerOwner(new NameAndId(player.getGameProfile()));
   }

   private static int giveMoney(ServerPlayer player, long amount) {
      if (!wallets(player).credit(player.getUUID(), catalog.startingBalance(), amount)) {
         feedback(
            player, new ShopTransactions.Result(false, "That amount would exceed the balance limit of " + ShopTransactions.money(1000000000000L) + ".", 0, 0L)
         );
         return 0;
      } else {
         feedback(
            player,
            new ShopTransactions.Result(
               true, "Added " + ShopTransactions.money(amount) + ". Your balance is " + ShopTransactions.money(balance(player)) + ".", 0, amount
            )
         );
         return 1;
      }
   }

   private static int showBalance(ServerPlayer player) {
      player.sendSystemMessage(Component.literal("Your balance: " + ShopTransactions.money(balance(player))).withStyle(ChatFormatting.GOLD));
      return 1;
   }
}
