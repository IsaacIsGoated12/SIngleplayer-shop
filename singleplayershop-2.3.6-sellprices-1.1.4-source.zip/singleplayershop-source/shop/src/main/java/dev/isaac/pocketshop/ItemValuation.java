package dev.isaac.pocketshop;

import java.util.*;
import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.ItemEnchantments;

/** The server and synchronized client use this same deterministic appraisal. */
public final class ItemValuation {
   public static final long MAX_PRICE=1_000_000_000L;
   public static final int ENCHANTMENT_PERCENT=40;
   private final Map<Item,List<Offer>> offers;
   private final Map<String,Long> enchantmentBooks;

   public ItemValuation(List<Offer> entries) {
      Map<Item,List<Offer>> indexed=new HashMap<>();
      Map<String,Long> books=new HashMap<>();
      for(Offer offer:entries) {
         ItemStack template=offer.stack();
         indexed.computeIfAbsent(template.getItem(),ignored->new ArrayList<>()).add(offer);
         if(template.is(Items.ENCHANTED_BOOK)) {
            var stored=template.getOrDefault(DataComponents.STORED_ENCHANTMENTS,ItemEnchantments.EMPTY);
            if(stored.size()==1) for(var entry:stored.entrySet()) {
               String key=key(entry.getKey(),entry.getIntValue());
               if(key!=null) books.merge(key,offer.buy(),Math::min);
            }
         }
      }
      Map<Item,List<Offer>> immutable=new HashMap<>();
      indexed.forEach((item,rows)->immutable.put(item,List.copyOf(rows)));
      offers=Map.copyOf(immutable);enchantmentBooks=Map.copyOf(books);
   }

   public long sellPrice(ItemStack stack) { return quote(stack).total(); }

   public Breakdown quote(ItemStack stack) {
      if(stack==null || stack.isEmpty()) return rejected("Empty item");
      if(PurchaseOrigin.isPurchased(stack)) return rejected("Shop purchase - cannot resell");
      var enchantments=stack.getOrDefault(stack.is(Items.ENCHANTED_BOOK)?DataComponents.STORED_ENCHANTMENTS:DataComponents.ENCHANTMENTS,ItemEnchantments.EMPTY);
      if(stack.has(DataComponents.CUSTOM_NAME) && enchantments.isEmpty()) return rejected("Named item protected");
      List<Offer> choices=offers.getOrDefault(stack.getItem(),List.of());
      Profile profile=profile(stack);
      for(Offer offer:choices) if(offer.sell()>0 && ItemStack.isSameItemSameComponents(stack,offer.template)) {
         return new Breakdown(offer.sell(),0,0,0,0,0,100,offer.sell(),offer.sell(),profile,List.of(),"",!enchantments.isEmpty());
      }
      if(!stack.isDamageableItem() && enchantments.isEmpty()) return rejected("No accepted listing for these item components");
      ItemStack plain=new ItemStack(stack.getItem()),normalized=stack.copyWithCount(1);
      restore(normalized,plain,DataComponents.DAMAGE);
      restore(normalized,plain,DataComponents.ENCHANTMENTS);
      restore(normalized,plain,DataComponents.STORED_ENCHANTMENTS);
      restore(normalized,plain,DataComponents.REPAIR_COST);
      restore(normalized,plain,DataComponents.TRIM);
      restore(normalized,plain,DataComponents.DYED_COLOR);
      restore(normalized,plain,DataComponents.BANNER_PATTERNS);
      restore(normalized,plain,DataComponents.BASE_COLOR);
      if(!enchantments.isEmpty()) {
         restore(normalized,plain,DataComponents.CUSTOM_NAME);
         restore(normalized,plain,DataComponents.LORE);
      }
      if(!ItemStack.isSameItemSameComponents(normalized,plain)) return rejected("Stored contents or modified gameplay components protected");
      long base=0;
      if(!stack.is(Items.ENCHANTED_BOOK)) {
         for(Offer offer:choices) if(ItemStack.isSameItemSameComponents(plain,offer.template)) { base=offer.sell();break; }
         if(base<=0) return rejected("No ordinary sell price configured for this item");
      }
      long enchantmentValue=0;int curses=0,maxLevels=0;
      List<EnchantmentLine> lines=new ArrayList<>();
      for(var entry:enchantments.entrySet()) {
         Holder<Enchantment> holder=entry.getKey();int level=entry.getIntValue();
         if(!holder.isBound() || level<1 || level>holder.value().getMaxLevel()) return rejected("Invalid enchantment level protected");
         String id=holder.unwrapKey().map(value->value.identifier().toString()).orElse(null);
         if(id==null) return rejected("Unregistered enchantment protected");
         boolean curse=id.equals("minecraft:binding_curse") || id.equals("minecraft:vanishing_curse");
         Long book=enchantmentBooks.get(key(holder,level));
         long contribution=curse || book==null ? 0 : book*ENCHANTMENT_PERCENT/100*profile.enchantmentPercent()/100;
         if(curse) curses++;
         else if(contribution>0 && level==holder.value().getMaxLevel()) maxLevels++;
         enchantmentValue+=contribution;
         lines.add(new EnchantmentLine(holder,level,contribution,curse,book!=null));
      }
      lines.sort(Comparator.comparing(line->key(line.enchantment(),line.level())));
      // A complete high-level loadout earns at most 15%; books receive no equipment bonus.
      int bonusPercent=stack.isDamageableItem()?Math.min(15,Math.max(0,maxLevels-1)*5):0;
      long bonus=enchantmentValue*bonusPercent/100;
      long raw=base+enchantmentValue+bonus;
      long capped=Math.min(MAX_PRICE,raw),limitLoss=raw-capped;
      long afterCurse=capped;
      for(int i=0;i<curses;i++) afterCurse=afterCurse*75/100;
      long total=afterCurse;int condition=100;
      if(stack.isDamageableItem()) {
         int maximum=stack.getMaxDamage();int remaining=Math.max(0,maximum-stack.getDamageValue());
         if(maximum<=0 || remaining<=0) return rejected("Broken item has no remaining sell value");
         total=afterCurse*remaining/maximum;
         condition=(int)((long)remaining*100/maximum);
      }
      return new Breakdown(base,enchantmentValue,bonus,capped-afterCurse,afterCurse-total,limitLoss,condition,afterCurse,total,profile,lines,total>0?"":raw>0?"No sell value remains after discounts":"No priced non-curse enchantments",false);
   }

   /** Percentages apply to enchantment value, not the item's ordinary material price. */
   public static Profile profile(ItemStack stack) {
      String id=BuiltInRegistries.ITEM.getKey(stack.getItem()).getPath();
      if(stack.is(Items.ENCHANTED_BOOK)) return new Profile("Enchanted book",100);
      if(stack.is(Items.ELYTRA)) return new Profile("Elytra / End treasure",200);
      if(stack.is(Items.TRIDENT)) return new Profile("Trident / rare weapon",150);
      if(stack.is(Items.MACE)) return new Profile("Mace / trial treasure",180);
      int material=35;String name="Utility equipment";
      String[] prefixes={"wooden_","stone_","copper_","leather_","golden_","chainmail_","iron_","diamond_","netherite_"};
      int[] factors={2,4,8,6,12,18,25,100,160};
      String[] names={"Wood","Stone","Copper","Leather","Gold","Chainmail","Iron","Diamond","Netherite"};
      for(int i=0;i<prefixes.length;i++) if(id.startsWith(prefixes[i])) {material=factors[i];name=names[i];break;}
      int type=100;
      if(id.endsWith("_chestplate")) type=140;
      else if(id.endsWith("_leggings")) type=125;
      else if(id.endsWith("_boots")) type=90;
      else if(id.endsWith("_pickaxe")) type=110;
      else if(id.endsWith("_axe")) type=105;
      else if(id.endsWith("_shovel")) type=65;
      else if(id.endsWith("_hoe")) type=60;
      else if(id.endsWith("_spear")) type=115;
      if(stack.is(Items.BOW)) {material=65;name="Bow";}
      if(stack.is(Items.CROSSBOW)) {material=75;name="Crossbow";}
      if(stack.is(Items.FISHING_ROD)) {material=55;name="Fishing rod";}
      if(stack.is(Items.TURTLE_HELMET)) {material=65;name="Turtle shell";}
      return new Profile(name,Math.min(200,Math.max(1,material*type/100)));
   }

   private static Breakdown rejected(String reason) {return new Breakdown(0,0,0,0,0,0,0,0,0,new Profile("Protected",0),List.of(),reason,false);}
   private static <T> void restore(ItemStack stack,ItemStack plain,DataComponentType<T> type) {
      T value=plain.get(type);if(value==null) stack.remove(type);else stack.set(type,value);
   }
   private static String key(Holder<Enchantment> enchantment,int level) {return enchantment.unwrapKey().map(id->id.identifier()+"#"+level).orElse(null);}
   public record Offer(ItemStack template,long buy,long sell) {
      public Offer {
         Objects.requireNonNull(template,"template");
         if(template.isEmpty() || template.getCount()!=1 || buy<1 || buy>MAX_PRICE || sell<0 || sell>buy) throw new IllegalArgumentException("Invalid valuation offer");
         template=template.copy();
      }
      public ItemStack stack() {return template.copy();}
      public ItemStack template() {return template.copy();}
   }
   public record Profile(String name,int enchantmentPercent) {}
   public record EnchantmentLine(Holder<Enchantment> enchantment,int level,long value,boolean curse,boolean priced) {}
   public record Breakdown(long base,long enchantments,long setBonus,long curseLoss,long wearLoss,long limitLoss,int conditionPercent,long fullCondition,long total,Profile profile,List<EnchantmentLine> lines,String rejection,boolean override) {
      public Breakdown {lines=List.copyOf(lines);}
      public String rarity() {return total>=250_000?"Legendary":total>=100_000?"Epic":total>=10_000?"Rare":total>=1_000?"Uncommon":"Common";}
   }
}
