"""Build both Fabric mods with Python 3.10+ and JDK 25; no Gradle daemon needed."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import argparse, hashlib, json, os, shutil, subprocess, sys, urllib.request, zipfile

ROOT=Path(__file__).resolve().parent

def fetch(url):
    request=urllib.request.Request(url,headers={'User-Agent':'SingleplayerShop-ReleaseBuilder/2.3.6'})
    with urllib.request.urlopen(request,timeout=90) as response: return response.read()

def download(url,path,sha1=None):
    if path.exists() and (not sha1 or hashlib.sha1(path.read_bytes()).hexdigest()==sha1): return path
    data=fetch(url)
    if sha1 and hashlib.sha1(data).hexdigest()!=sha1: raise RuntimeError('Checksum mismatch: '+url)
    path.parent.mkdir(parents=True,exist_ok=True)
    temporary=path.with_suffix(path.suffix+'.tmp');temporary.write_bytes(data);temporary.replace(path)
    return path

def dependencies(cache,minecraft,api):
    manifest=json.loads(fetch('https://piston-meta.mojang.com/mc/game/version_manifest_v2.json'))
    info=next(v for v in manifest['versions'] if v['id']==minecraft)
    version=json.loads(fetch(info['url']))
    client=version['downloads']['client']
    cp=[download(client['url'],cache/'minecraft'/minecraft/'client.jar',client['sha1'])]
    def library(lib):
        artifact=lib.get('downloads',{}).get('artifact')
        if not artifact or 'natives' in artifact['path']: return None
        return download(artifact['url'],cache/'libraries'/artifact['path'],artifact['sha1'])
    with ThreadPoolExecutor(max_workers=6) as pool: cp.extend(p for p in pool.map(library,version['libraries']) if p)
    for group,name,ver in [('net.fabricmc','fabric-loader','0.19.5'),('net.fabricmc.fabric-api','fabric-api',api)]:
        url='https://maven.fabricmc.net/'+group.replace('.','/')+'/'+name+'/'+ver+'/'+name+'-'+ver+'.jar'
        sha=fetch(url+'.sha1').decode().strip().split()[0]
        jar=download(url,cache/(name+'-'+ver+'.jar'),sha)
        if name=='fabric-loader': cp.append(jar)
        else:
            nested=cache/('api-'+api);nested.mkdir(parents=True,exist_ok=True)
            with zipfile.ZipFile(jar) as z:
                for entry in z.namelist():
                    if entry.endswith('.jar'):
                        target=nested/Path(entry).name;target.write_bytes(z.read(entry));cp.append(target)
    return cp

def arguments(path,args):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text('\n'.join('"'+str(a).replace('\\','/').replace('"','\\"')+'"' for a in args),encoding='utf-8')
    return '@'+str(path)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--jdk',type=Path,help='JDK directory containing bin/javac (or its bin directory)')
    parser.add_argument('--output',type=Path,default=ROOT/'dist')
    parser.add_argument('--cache',type=Path,default=ROOT/'.build-deps')
    parser.add_argument('--classpath-file',type=Path,help='Reuse an already resolved platform classpath')
    parser.add_argument('--test',action='store_true')
    parser.add_argument('--minecraft',default='26.3')
    parser.add_argument('--api',default='0.163.0+26.3')
    opts=parser.parse_args()
    extension='.exe' if os.name=='nt' else ''
    if opts.jdk:
        binpath=opts.jdk/'bin' if (opts.jdk/'bin').is_dir() else opts.jdk
        javac=binpath/('javac'+extension);java=binpath/('java'+extension)
    else:
        javac=shutil.which('javac');java=shutil.which('java')
    if not javac or not java: parser.error('Install JDK 25 and use --jdk or add it to PATH.')
    cp=opts.classpath_file.read_text().strip().split(os.pathsep) if opts.classpath_file else [str(p) for p in dependencies(opts.cache.resolve(),opts.minecraft,opts.api)]
    output=opts.output.resolve();output.mkdir(parents=True,exist_ok=True)
    build=ROOT/'build-release'
    module_outputs=[];built_jars=[]
    for module,version,basename in [('shop','2.3.6','singleplayershop'),('sellprices','1.1.4','singleplayershop-sellprices')]:
        source=ROOT/module/'src/main'
        classes=build/module/'classes';classes.mkdir(parents=True,exist_ok=True)
        # Only clear this builder's generated class directory, within its fixed build root.
        classes.resolve().relative_to(build.resolve())
        shutil.rmtree(classes)
        classes.mkdir(parents=True)
        source_files=sorted((source/'java').rglob('*.java'))
        args=['--release','25','-encoding','UTF-8','-classpath',os.pathsep.join(cp+module_outputs),'-d',str(classes)]+[str(p) for p in source_files]
        subprocess.run([str(javac),arguments(build/module/'javac.args',args)],check=True)
        jar=output/(basename+'-'+version+'.jar')
        built_jars.append(jar)
        with zipfile.ZipFile(jar,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
            entry=zipfile.ZipInfo('META-INF/MANIFEST.MF',(1980,1,1,0,0,0))
            entry.compress_type=zipfile.ZIP_DEFLATED
            z.writestr(entry,'Manifest-Version: 1.0\r\nFabric-Mapping-Namespace: official\r\nImplementation-Version: '+version+'\r\n\r\n')
            for base in [classes,source/'resources']:
                for file in sorted(base.rglob('*')):
                    if file.is_file():
                        entry=zipfile.ZipInfo(file.relative_to(base).as_posix(),(1980,1,1,0,0,0))
                        entry.compress_type=zipfile.ZIP_DEFLATED;z.writestr(entry,file.read_bytes())
        module_outputs.extend([str(classes),str(source/'resources')])
        print('Built '+jar.name,flush=True)
    if opts.test:
        classes=build/'tests/classes';classes.mkdir(parents=True,exist_ok=True)
        fullcp=os.pathsep.join(cp+module_outputs)
        args=['--release','25','-encoding','UTF-8','-classpath',fullcp,'-d',str(classes)]+[str(p) for p in sorted((ROOT/'tests').rglob('*.java'))]
        subprocess.run([str(javac),arguments(build/'tests/javac.args',args)],check=True)
        scratch=build/'test-run';scratch.mkdir(exist_ok=True)
        args=['-Xmx2G','-cp',fullcp+os.pathsep+str(classes),'dev.isaac.pocketshop.IntegrationTests',str(scratch)]
        subprocess.run([str(java),arguments(build/'tests/java.args',args)],cwd=scratch,check=True)
    hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in built_jars}
    (output/'SHA256SUMS.txt').write_text(''.join(value+'  '+name+'\n' for name,value in sorted(hashes.items())),encoding='utf-8')

if __name__=='__main__': main()
