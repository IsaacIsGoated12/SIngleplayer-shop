package dev.isaac.pocketshop;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import com.google.gson.Strictness;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Collection;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import net.minecraft.core.Holder.Reference;
import net.minecraft.core.HolderLookup.Provider;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.data.registries.VanillaRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.Instrument;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.item.alchemy.PotionContents;
import net.minecraft.world.item.component.Fireworks;
import net.minecraft.world.item.component.InstrumentComponent;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.ItemEnchantments;
import net.minecraft.world.item.enchantment.ItemEnchantments.Mutable;

public final class ShopCatalog {
   private static final long MAX_CONFIG_AMOUNT = 1000000000L;
   private static final int MAX_CATEGORY_ENTRIES = 512;
   private static final int CURRENT_CATALOG_VERSION = 6;
   private static final long MAX_CATALOG_BYTES = 8L * 1024 * 1024;
   private static final Gson GSON = new GsonBuilder().setStrictness(Strictness.STRICT).create();
   private static final Gson PRETTY_GSON = new GsonBuilder().setPrettyPrinting().create();
   private static final Set<String> ROOT_FIELDS = Set.of("startingBalance", "items", "catalogVersion");
   private static final Set<String> ITEM_FIELDS = Set.of("category", "id", "buy", "sell", "variant", "label", "enchantments", "potion", "instrument", "flight");
   private static final Set<String> NEWER_ITEMS = Set.of(
      "minecraft:black_concrete_slab",
      "minecraft:black_concrete_stairs",
      "minecraft:black_cushion",
      "minecraft:black_wool_slab",
      "minecraft:black_wool_stairs",
      "minecraft:blue_concrete_slab",
      "minecraft:blue_concrete_stairs",
      "minecraft:blue_cushion",
      "minecraft:blue_wool_slab",
      "minecraft:blue_wool_stairs",
      "minecraft:brown_concrete_slab",
      "minecraft:brown_concrete_stairs",
      "minecraft:brown_cushion",
      "minecraft:brown_wool_slab",
      "minecraft:brown_wool_stairs",
      "minecraft:cyan_concrete_slab",
      "minecraft:cyan_concrete_stairs",
      "minecraft:cyan_cushion",
      "minecraft:cyan_wool_slab",
      "minecraft:cyan_wool_stairs",
      "minecraft:gray_concrete_slab",
      "minecraft:gray_concrete_stairs",
      "minecraft:gray_cushion",
      "minecraft:gray_wool_slab",
      "minecraft:gray_wool_stairs",
      "minecraft:green_concrete_slab",
      "minecraft:green_concrete_stairs",
      "minecraft:green_cushion",
      "minecraft:green_wool_slab",
      "minecraft:green_wool_stairs",
      "minecraft:light_blue_concrete_slab",
      "minecraft:light_blue_concrete_stairs",
      "minecraft:light_blue_cushion",
      "minecraft:light_blue_wool_slab",
      "minecraft:light_blue_wool_stairs",
      "minecraft:light_gray_concrete_slab",
      "minecraft:light_gray_concrete_stairs",
      "minecraft:light_gray_cushion",
      "minecraft:light_gray_wool_slab",
      "minecraft:light_gray_wool_stairs",
      "minecraft:lime_concrete_slab",
      "minecraft:lime_concrete_stairs",
      "minecraft:lime_cushion",
      "minecraft:lime_wool_slab",
      "minecraft:lime_wool_stairs",
      "minecraft:magenta_concrete_slab",
      "minecraft:magenta_concrete_stairs",
      "minecraft:magenta_cushion",
      "minecraft:magenta_wool_slab",
      "minecraft:magenta_wool_stairs",
      "minecraft:orange_concrete_slab",
      "minecraft:orange_concrete_stairs",
      "minecraft:orange_cushion",
      "minecraft:orange_poplar_leaves",
      "minecraft:orange_wool_slab",
      "minecraft:orange_wool_stairs",
      "minecraft:pink_concrete_slab",
      "minecraft:pink_concrete_stairs",
      "minecraft:pink_cushion",
      "minecraft:pink_wool_slab",
      "minecraft:pink_wool_stairs",
      "minecraft:poplar_boat",
      "minecraft:poplar_button",
      "minecraft:poplar_chest_boat",
      "minecraft:poplar_door",
      "minecraft:poplar_fence",
      "minecraft:poplar_fence_gate",
      "minecraft:poplar_hanging_sign",
      "minecraft:poplar_log",
      "minecraft:poplar_planks",
      "minecraft:poplar_pressure_plate",
      "minecraft:poplar_sapling",
      "minecraft:poplar_shelf",
      "minecraft:poplar_sign",
      "minecraft:poplar_slab",
      "minecraft:poplar_stairs",
      "minecraft:poplar_trapdoor",
      "minecraft:poplar_wood",
      "minecraft:purple_concrete_slab",
      "minecraft:purple_concrete_stairs",
      "minecraft:purple_cushion",
      "minecraft:purple_wool_slab",
      "minecraft:purple_wool_stairs",
      "minecraft:red_concrete_slab",
      "minecraft:red_concrete_stairs",
      "minecraft:red_cushion",
      "minecraft:red_poplar_leaves",
      "minecraft:red_shrub",
      "minecraft:red_wool_slab",
      "minecraft:red_wool_stairs",
      "minecraft:shelf_mushroom",
      "minecraft:straw_bed",
      "minecraft:stripped_poplar_log",
      "minecraft:stripped_poplar_wood",
      "minecraft:white_concrete_slab",
      "minecraft:white_concrete_stairs",
      "minecraft:white_cushion",
      "minecraft:white_wool_slab",
      "minecraft:white_wool_stairs",
      "minecraft:yellow_concrete_slab",
      "minecraft:yellow_concrete_stairs",
      "minecraft:yellow_cushion",
      "minecraft:yellow_poplar_leaves",
      "minecraft:yellow_wool_slab",
      "minecraft:yellow_wool_stairs",
      "minecraft:sulfur",
      "minecraft:sulfur_slab",
      "minecraft:sulfur_stairs",
      "minecraft:sulfur_wall",
      "minecraft:polished_sulfur",
      "minecraft:polished_sulfur_slab",
      "minecraft:polished_sulfur_stairs",
      "minecraft:polished_sulfur_wall",
      "minecraft:sulfur_bricks",
      "minecraft:sulfur_brick_slab",
      "minecraft:sulfur_brick_stairs",
      "minecraft:sulfur_brick_wall",
      "minecraft:cinnabar",
      "minecraft:cinnabar_slab",
      "minecraft:cinnabar_stairs",
      "minecraft:cinnabar_wall",
      "minecraft:polished_cinnabar",
      "minecraft:polished_cinnabar_slab",
      "minecraft:polished_cinnabar_stairs",
      "minecraft:polished_cinnabar_wall",
      "minecraft:cinnabar_bricks",
      "minecraft:cinnabar_brick_slab",
      "minecraft:cinnabar_brick_stairs",
      "minecraft:cinnabar_brick_wall",
      "minecraft:chiseled_sulfur",
      "minecraft:chiseled_cinnabar",
      "minecraft:potent_sulfur",
      "minecraft:sulfur_spike",
      "minecraft:music_disc_bounce",
      "minecraft:sulfur_cube_bucket",
      "minecraft:sulfur_cube_spawn_egg"
   );
   private final long startingBalance;
   private final Map<ShopCatalog.Category, List<ShopCatalog.Entry>> byCategory;
   private final Map<Item, List<ShopCatalog.Entry>> byItem;
   private final ItemValuation valuation;

   private ShopCatalog(long startingBalance, Map<ShopCatalog.Category, List<ShopCatalog.Entry>> categories, Map<Item, List<ShopCatalog.Entry>> items) {
      this.startingBalance = startingBalance;
      Map<ShopCatalog.Category, List<ShopCatalog.Entry>> immutableCategories = new EnumMap<>(ShopCatalog.Category.class);
      categories.forEach((category, entries) -> immutableCategories.put(category, List.copyOf((Collection<? extends ShopCatalog.Entry>)entries)));
      this.byCategory = Map.copyOf(immutableCategories);
      Map<Item, List<ShopCatalog.Entry>> immutableItems = new HashMap<>();
      items.forEach((item, entries) -> immutableItems.put(item, List.copyOf((Collection<? extends ShopCatalog.Entry>)entries)));
      this.byItem = Map.copyOf(immutableItems);
      List<ItemValuation.Offer> offers = new ArrayList<>();
      categories.values().forEach(entries -> entries.forEach(entry -> offers.add(new ItemValuation.Offer(entry.stack(),entry.buyPrice(),entry.sellPrice()))));
      this.valuation = new ItemValuation(offers);
   }

   public static ShopCatalog load(Path configPath) throws IOException {
      return load(configPath, ShopCatalog.VanillaLookup.VALUE);
   }

   public static ShopCatalog load(Path configPath, Provider registries) throws IOException {
      Objects.requireNonNull(configPath, "configPath");
      Objects.requireNonNull(registries, "registries");
      Path absolutePath = configPath.toAbsolutePath();

      try {
         Set<String> removedItems = bundledRemovedItems();
         if (Files.notExists(absolutePath)) {
            JsonObject defaults = bundledDefaults("default-shop.json");
            defaults.addProperty("catalogVersion", CURRENT_CATALOG_VERSION);
            validate(defaults, registries);
            sanitizeRemovedStock(defaults, removedItems);
            ShopCatalog catalog = validate(defaults, registries);
            Files.createDirectories(absolutePath.getParent());
            Files.writeString(absolutePath, serialize(defaults), StandardCharsets.UTF_8, StandardOpenOption.CREATE_NEW, StandardOpenOption.WRITE);
            return catalog;
         }

         if (Files.size(absolutePath) > MAX_CATALOG_BYTES) {
            throw new IOException("PocketShop configuration exceeds the 8 MiB limit. Your file was left unchanged.");
         }
         byte[] original = Files.readAllBytes(absolutePath);
         JsonObject root = parse(new StringReader(new String(original, StandardCharsets.UTF_8)));
         ShopCatalog configured = validate(root, registries);
         int previousVersion = root.has("catalogVersion") ? root.get("catalogVersion").getAsInt() : 0;
         boolean removed = sanitizeRemovedStock(root, removedItems);
         if (previousVersion == CURRENT_CATALOG_VERSION && !removed) {
            return configured;
         }

         if (previousVersion < CURRENT_CATALOG_VERSION) {
            JsonObject defaults = bundledDefaults("default-shop.json");
            validate(defaults, registries);
            sanitizeRemovedStock(defaults, removedItems);
            JsonObject baseline = bundledDefaults(previousVersion < 2 ? "default-shop-v1.json" : previousVersion < 4 ? "default-shop-v3.json" : previousVersion < 5 ? "default-shop-v4.json" : "default-shop-v5.json");
            validate(baseline, registries);
            Map<String, JsonObject> oldDefaults = indexedItems(baseline);
            Map<String, JsonObject> newDefaults = indexedItems(defaults);
            Map<String, JsonObject> existing = indexedItems(root);
            JsonArray mergedItems = root.getAsJsonArray("items");

            for (Map.Entry<String, JsonObject> configuredItem : existing.entrySet()) {
               JsonObject oldDefault = oldDefaults.get(configuredItem.getKey());
               JsonObject newDefault = newDefaults.get(configuredItem.getKey());
               JsonObject originalItem = configuredItem.getValue();
               if (oldDefault != null && newDefault != null) {
                  JsonElement previousBuy = originalItem.get("buy").deepCopy();
                  JsonElement previousSell = originalItem.get("sell").deepCopy();
                  // Preserve each custom price independently, plus labels, categories and variants.
                  for (String price : List.of("buy", "sell")) {
                     if (originalItem.get(price).getAsLong() == oldDefault.get(price).getAsLong()) {
                        originalItem.add(price, newDefault.get(price).deepCopy());
                     }
                  }
                  if (originalItem.get("sell").getAsLong() > originalItem.get("buy").getAsLong()) {
                     originalItem.add("buy", previousBuy);
                     originalItem.add("sell", previousSell);
                  }
               }
            }

            for (JsonElement element : defaults.getAsJsonArray("items")) {
               String key = jsonKey(element.getAsJsonObject());
               if (!existing.containsKey(key) && (previousVersion == 0 || !oldDefaults.containsKey(key))) {
                  mergedItems.add(element.deepCopy());
               }
            }
         }

         root.addProperty("catalogVersion", CURRENT_CATALOG_VERSION);
         ShopCatalog expanded = validate(root, registries);
         backup(absolutePath, original);
         replaceAtomically(absolutePath, serialize(root));
         return expanded;
      } catch (JsonParseException | IllegalArgumentException exception) {
         throw new IOException(
            "Invalid PocketShop configuration at " + absolutePath + ": " + exception.getMessage() + ". Your file was left unchanged.", exception
         );
      }
   }

   private static JsonObject bundledDefaults(String resource) throws IOException {
      try (InputStream defaults = ShopCatalog.class.getResourceAsStream("/" + resource)) {
         if (defaults == null) {
            throw new IOException("PocketShop's bundled " + resource + " is missing");
         } else {
            return parse(new StringReader(new String(defaults.readAllBytes(), StandardCharsets.UTF_8)));
         }
      }
   }

   private static Set<String> bundledRemovedItems() throws IOException {
      try (InputStream stream = ShopCatalog.class.getResourceAsStream("/removed-shop-items.json")) {
         if (stream == null) {
            throw new IOException("PocketShop's bundled removed-shop-items.json is missing");
         }

         JsonElement parsed = (JsonElement)GSON.fromJson(new String(stream.readAllBytes(), StandardCharsets.UTF_8), JsonElement.class);
         if (parsed == null || !parsed.isJsonArray()) {
            throw invalid("removed-shop-items.json must contain an array of item IDs");
         }

         Set<String> removed = new HashSet<>();

         for (JsonElement element : parsed.getAsJsonArray()) {
            if (!element.isJsonPrimitive() || !element.getAsJsonPrimitive().isString()) {
               throw invalid("removed-shop-items.json entries must be item ID strings");
            }

            String value = element.getAsString();
            Identifier id = Identifier.tryParse(value);
            if (id == null
               || !id.toString().equals(value)
               || !id.getNamespace().equals("minecraft")
               || !BuiltInRegistries.ITEM.containsKey(id) && !NEWER_ITEMS.contains(value)
               || !removed.add(value)) {
               throw invalid("removed-shop-items.json has an invalid or duplicate item ID: " + value);
            }
         }

         return Set.copyOf(removed);
      }
   }

   private static boolean sanitizeRemovedStock(JsonObject root, Set<String> removedItems) {
      JsonArray items = root.getAsJsonArray("items");
      boolean changed = false;

      for (int index = items.size() - 1; index >= 0; index--) {
         JsonObject item = items.get(index).getAsJsonObject();
         String id = Identifier.parse(item.get("id").getAsString()).toString();
         if (removedItems.contains(id)) {
            items.remove(index);
            changed = true;
         } else {
            String category = item.get("category").getAsString();
            if (category.equalsIgnoreCase("CREATURES") || category.equalsIgnoreCase("SPECIAL")) {
               item.addProperty("category", ShopCatalog.Category.UTILITY.name());
               changed = true;
            }
         }
      }

      return changed;
   }

   private static JsonObject parse(Reader reader) {
      return object((JsonElement)GSON.fromJson(reader, JsonElement.class), "Configuration");
   }

   private static Map<String, JsonObject> indexedItems(JsonObject root) {
      Map<String, JsonObject> result = new HashMap<>();

      for (JsonElement item : root.getAsJsonArray("items")) {
         JsonObject object = item.getAsJsonObject();
         result.put(jsonKey(object), object);
      }

      return result;
   }

   private static String jsonKey(JsonObject item) {
      return Identifier.parse(item.get("id").getAsString()) + (item.has("variant") ? "#" + item.get("variant").getAsString() : "");
   }

   private static ShopCatalog validate(JsonObject root, Provider registries) {
      checkFields(root, ROOT_FIELDS, "Configuration");
      if (root.has("catalogVersion") && amount(root, "catalogVersion", "Configuration", 0L) > CURRENT_CATALOG_VERSION) {
         throw invalid("Configuration.catalogVersion must be from 0 through " + CURRENT_CATALOG_VERSION);
      }

      long startingBalance = amount(root, "startingBalance", "Configuration", 0L);
      JsonElement rawItems = root.get("items");
      if (rawItems != null && rawItems.isJsonArray()) {
         JsonArray configuredItems = rawItems.getAsJsonArray();
         Map<ShopCatalog.Category, List<ShopCatalog.Entry>> categories = new EnumMap<>(ShopCatalog.Category.class);
         Map<ShopCatalog.Category, Integer> configuredCounts = new EnumMap<>(ShopCatalog.Category.class);
         Map<Item, List<ShopCatalog.Entry>> items = new HashMap<>();
         Set<String> keys = new HashSet<>();

         for (ShopCatalog.Category category : ShopCatalog.Category.values()) {
            categories.put(category, new ArrayList<>());
         }

         for (int index = 0; index < configuredItems.size(); index++) {
            String location = "items[" + index + "]";
            JsonObject itemJson = object(configuredItems.get(index), location);
            checkFields(itemJson, ITEM_FIELDS, location);
            String categoryName = string(itemJson, "category", location);

            ShopCatalog.Category category;
            try {
               category = ShopCatalog.Category.valueOf(categoryName.toUpperCase(Locale.ROOT));
            } catch (IllegalArgumentException exception) {
               throw invalid(location + ".category is unknown: " + categoryName);
            }

            String itemName = string(itemJson, "id", location);
            Identifier itemId = Identifier.tryParse(itemName);
            boolean available = itemId != null && BuiltInRegistries.ITEM.containsKey(itemId);
            if (itemId == null || !available && !NEWER_ITEMS.contains(itemId.toString())) {
               throw invalid(location + ".id is not a registered item: " + itemName);
            }

            if (available && BuiltInRegistries.ITEM.getValue(itemId) == Items.AIR) {
               throw invalid(location + ".id cannot be minecraft:air");
            }

            long buy = amount(itemJson, "buy", location, 1L);
            long sell = amount(itemJson, "sell", location, 0L);
            if (sell > buy) {
               throw invalid(location + ".sell must not exceed its buy price");
            }

            ShopCatalog.Variant variant = variant(itemJson, location);
            String key = itemId + (variant.id().isEmpty() ? "" : "#" + variant.id());
            if (!keys.add(key)) {
               throw invalid(location + " duplicates item variant " + key);
            }

            if (configuredCounts.merge(category, 1, Integer::sum) > 512) {
               throw invalid(category + " contains more than 512 items");
            }

            if (!available) {
               validateUnavailableVariant(variant, registries);
            } else {
               Item item = (Item)BuiltInRegistries.ITEM.getValue(itemId);
               ShopCatalog.Entry entry = new ShopCatalog.Entry(category, item, buy, sell, variant, registries);
               List<ShopCatalog.Entry> variants = items.computeIfAbsent(item, ignored -> new ArrayList<>());
               variants.add(entry);
               List<ShopCatalog.Entry> categoryEntries = categories.get(category);
               categoryEntries.add(entry);
            }
         }

         return new ShopCatalog(startingBalance, categories, items);
      } else {
         throw invalid("'items' must be an array");
      }
   }

   private static Reference<Enchantment> configuredEnchantment(Provider registries, String configuredId, int level) {
      Identifier id = Identifier.tryParse(configuredId);
      if (id == null) {
         throw invalid("Unknown enchantment: " + configuredId);
      } else {
         Reference<Enchantment> enchantment = (Reference<Enchantment>)registries.lookupOrThrow(Registries.ENCHANTMENT)
            .get(ResourceKey.create(Registries.ENCHANTMENT, id))
            .orElseThrow(() -> invalid("Unknown enchantment: " + id));
         if (level >= 1 && level <= ((Enchantment)enchantment.value()).getMaxLevel()) {
            return enchantment;
         } else {
            throw invalid("Enchantment " + id + " level must be 1-" + ((Enchantment)enchantment.value()).getMaxLevel());
         }
      }
   }

   private static void validateUnavailableVariant(ShopCatalog.Variant variant, Provider registries) {
      if (variant.potion().isEmpty() && variant.instrument().isEmpty() && variant.flight() <= 0) {
         variant.enchantments().forEach((id, level) -> configuredEnchantment(registries, id, level));
      } else {
         throw invalid("This newer item cannot configure potion, instrument, or flight components");
      }
   }

   private static ShopCatalog.Variant variant(JsonObject itemJson, String location) {
      String variant = itemJson.has("variant") ? string(itemJson, "variant", location) : "";
      String label = itemJson.has("label") ? string(itemJson, "label", location) : "";
      String potion = itemJson.has("potion") ? string(itemJson, "potion", location) : "";
      String instrument = itemJson.has("instrument") ? string(itemJson, "instrument", location) : "";
      int flight = itemJson.has("flight") ? (int)amount(itemJson, "flight", location, 1L) : 0;
      Map<String, Integer> enchantments = new HashMap<>();
      if (itemJson.has("enchantments")) {
         JsonObject configured = object(itemJson.get("enchantments"), location + ".enchantments");
         if (configured.isEmpty()) {
            throw invalid(location + ".enchantments must not be empty");
         }

         for (String id : configured.keySet()) {
            Identifier parsed = Identifier.tryParse(id);
            if (parsed == null) {
               throw invalid(location + ".enchantments has invalid ID: " + id);
            }

            int level = (int)amount(configured, id, location + ".enchantments", 1L);
            if (enchantments.putIfAbsent(parsed.toString(), level) != null) {
               throw invalid(location + ".enchantments duplicates " + parsed);
            }
         }
      }

      return new ShopCatalog.Variant(variant, label, enchantments, potion, instrument, flight);
   }

   private static String serialize(JsonObject root) {
      return PRETTY_GSON.toJson(root) + System.lineSeparator();
   }

   private static void backup(Path configPath, byte[] original) throws IOException {
      String filename = configPath.getFileName().toString();
      String basename = filename.endsWith(".json") ? filename.substring(0, filename.length() - 5) : filename;
      int suffix = 0;

      while (true) {
         String number = suffix == 0 ? "" : "-" + suffix;
         Path destination = configPath.resolveSibling(basename + ".pre-expansion" + number + ".json");

         try {
            Files.write(destination, original, StandardOpenOption.CREATE_NEW, StandardOpenOption.WRITE);
            return;
         } catch (FileAlreadyExistsException var8) {
            suffix++;
         }
      }
   }

   private static void replaceAtomically(Path destination, String content) throws IOException {
      Path temporary = Files.createTempFile(destination.getParent(), ".pocketshop-expansion-", ".tmp");

      try {
         Files.writeString(temporary, content, StandardCharsets.UTF_8);

         try {
            Files.move(temporary, destination, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
         } catch (AtomicMoveNotSupportedException exception) {
            Files.move(temporary, destination, StandardCopyOption.REPLACE_EXISTING);
         }
      } finally {
         Files.deleteIfExists(temporary);
      }
   }

   public long startingBalance() {
      return this.startingBalance;
   }

   public long sellPrice(ItemStack stack) { return valuation.sellPrice(stack); }
   public ItemValuation.Breakdown valuation(ItemStack stack) { return valuation.quote(stack); }

   public List<ShopCatalog.Entry> entries(ShopCatalog.Category category) {
      return this.byCategory.get(Objects.requireNonNull(category, "category"));
   }

   public Optional<ShopCatalog.Entry> find(ItemStack stack) {
      return stack != null && !stack.isEmpty()
         ? this.byItem.getOrDefault(stack.getItem(), List.of()).stream().filter(entry -> entry.accepts(stack)).findFirst()
         : Optional.empty();
   }

   private static JsonObject object(JsonElement element, String location) {
      if (element != null && element.isJsonObject()) {
         return element.getAsJsonObject();
      } else {
         throw invalid(location + " must be a JSON object");
      }
   }

   private static void checkFields(JsonObject object, Set<String> allowed, String location) {
      for (String field : object.keySet()) {
         if (!allowed.contains(field)) {
            throw invalid(location + " has an unknown field: " + field);
         }
      }
   }

   private static String string(JsonObject object, String field, String location) {
      JsonElement value = object.get(field);
      if (value != null && value.isJsonPrimitive() && value.getAsJsonPrimitive().isString() && !value.getAsString().isBlank()) {
         return value.getAsString();
      } else {
         throw invalid(location + "." + field + " must be a nonempty string");
      }
   }

   private static long amount(JsonObject object, String field, String location, long minimum) {
      JsonElement value = object.get(field);
      String requirement = location + "." + field + " must be a whole number from " + minimum + " through 1000000000";
      if (value != null && value.isJsonPrimitive()) {
         JsonPrimitive primitive = value.getAsJsonPrimitive();
         if (!primitive.isNumber()) {
            throw invalid(requirement);
         }

         long amount;
         try {
            amount = primitive.getAsBigDecimal().longValueExact();
         } catch (NumberFormatException | ArithmeticException exception) {
            throw invalid(requirement);
         }

         if (amount >= minimum && amount <= 1000000000L) {
            return amount;
         } else {
            throw invalid(requirement);
         }
      } else {
         throw invalid(requirement);
      }
   }

   private static IllegalArgumentException invalid(String message) {
      return new IllegalArgumentException(message);
   }

   public enum Category {
      BUILDING("Building", Items.STONE_BRICKS),
      WOOD_NATURE("Wood & Nature", Items.OAK_LOG),
      FARMING("Farming", Items.WHEAT),
      FOOD("Food", Items.COOKED_BEEF),
      RESOURCES("Resources", Items.DIAMOND),
      REDSTONE("Redstone", Items.REDSTONE),
      MOB_DROPS("Mob Drops", Items.BONE),
      TOOLS("Tools", Items.DIAMOND_PICKAXE),
      ARMOR("Armor", Items.DIAMOND_CHESTPLATE),
      COMBAT("Combat", Items.TOTEM_OF_UNDYING),
      DECORATION("Decoration", Items.PAINTING),
      TRANSPORT("Transport", Items.MINECART),
      UTILITY("Utility", Items.CRAFTING_TABLE),
      BREWING("Brewing", Items.BREWING_STAND),
      NETHER_END("Nether & End", Items.END_STONE),
      ENCHANTMENTS("Enchanted Books", Items.ENCHANTED_BOOK),
      ENCHANTED_GEAR("Enchanted Gear", Items.NETHERITE_PICKAXE),
      POTIONS("Potions & Arrows", Items.POTION),
      CREATURES("Creatures", Items.COW_SPAWN_EGG),
      SPECIAL("Special Items", Items.COMMAND_BLOCK);

      private final String title;
      private final Item icon;

      Category(String title, Item icon) {
         this.title = title;
         this.icon = icon;
      }

      public String title() {
         return this.title;
      }

      public Item icon() {
         return this.icon;
      }
   }

   public static final class Entry {
      private final ShopCatalog.Category category;
      private final Item item;
      private final long buyPrice;
      private final long sellPrice;
      private final ShopCatalog.Variant variant;
      private final ItemStack template;
      private final String displayName;
      private final String searchText;

      public Entry(ShopCatalog.Category category, Item item, long buyPrice, long sellPrice) {
         this(category, item, buyPrice, sellPrice, ShopCatalog.Variant.PLAIN, null);
      }

      public Entry(ShopCatalog.Category category, Item item, long buyPrice, long sellPrice, ShopCatalog.Variant variant) {
         this(category, item, buyPrice, sellPrice, variant, ShopCatalog.VanillaLookup.VALUE);
      }

      private Entry(ShopCatalog.Category category, Item item, long buyPrice, long sellPrice, ShopCatalog.Variant variant, Provider registries) {
         this.category = Objects.requireNonNull(category, "category");
         this.item = Objects.requireNonNull(item, "item");
         this.variant = Objects.requireNonNull(variant, "variant");
         if (item != Items.AIR && buyPrice > 0L && buyPrice <= 1000000000L && sellPrice >= 0L && sellPrice <= buyPrice) {
            this.buyPrice = buyPrice;
            this.sellPrice = sellPrice;
            this.template = new ItemStack(item);
            List<String> descriptions = new ArrayList<>();
            if (!variant.enchantments().isEmpty()) {
               Mutable enchantments = new Mutable(ItemEnchantments.EMPTY);

               for (Map.Entry<String, Integer> configured : variant.enchantments().entrySet()) {
                  int level = configured.getValue();
                  Reference<Enchantment> enchantment = ShopCatalog.configuredEnchantment(registries, configured.getKey(), level);
                  enchantments.set(enchantment, level);
                  descriptions.add(
                     ((Enchantment)enchantment.value()).description().getString() + " " + Component.translatable("enchantment.level." + level).getString()
                  );
               }

               this.template.set(item == Items.ENCHANTED_BOOK ? DataComponents.STORED_ENCHANTMENTS : DataComponents.ENCHANTMENTS, enchantments.toImmutable());
            }

            if (!variant.potion().isEmpty()) {
               if (item != Items.POTION && item != Items.SPLASH_POTION && item != Items.LINGERING_POTION && item != Items.TIPPED_ARROW) {
                  throw ShopCatalog.invalid("potion may only be used on potions or tipped arrows");
               }

               Identifier id = Identifier.tryParse(variant.potion());
               if (id == null) {
                  throw ShopCatalog.invalid("Unknown potion: " + variant.potion());
               }

               Reference<Potion> potion = (Reference<Potion>)registries.lookupOrThrow(Registries.POTION)
                  .get(ResourceKey.create(Registries.POTION, id))
                  .orElseThrow(() -> ShopCatalog.invalid("Unknown potion: " + id));
               this.template.set(DataComponents.POTION_CONTENTS, new PotionContents(potion));
               descriptions.add(id.getPath().replace('_', ' '));
            }

            if (!variant.instrument().isEmpty()) {
               if (item != Items.GOAT_HORN) {
                  throw ShopCatalog.invalid("instrument may only be used on goat horns");
               }

               Identifier id = Identifier.tryParse(variant.instrument());
               if (id == null) {
                  throw ShopCatalog.invalid("Unknown instrument: " + variant.instrument());
               }

               Reference<Instrument> instrument = (Reference<Instrument>)registries.lookupOrThrow(Registries.INSTRUMENT)
                  .get(ResourceKey.create(Registries.INSTRUMENT, id))
                  .orElseThrow(() -> ShopCatalog.invalid("Unknown instrument: " + id));
               this.template.set(DataComponents.INSTRUMENT, new InstrumentComponent(instrument));
               descriptions.add(((Instrument)instrument.value()).description().getString());
            }

            if (variant.flight() > 0) {
               if (item != Items.FIREWORK_ROCKET) {
                  throw ShopCatalog.invalid("flight may only be used on firework rockets");
               }

               this.template.set(DataComponents.FIREWORKS, new Fireworks(variant.flight(), List.of()));
               descriptions.add("Flight " + variant.flight());
            }
            if (variant.id().equals("sell_axe")) {
               if(item!=Items.NETHERITE_AXE || sellPrice!=0 || !variant.enchantments().equals(SellAxe.ENCHANTMENTS)) throw ShopCatalog.invalid("Sell Axe requires a netherite axe, all five maximum enchantments, and sell price 0");
               SellAxe.decorate(this.template);
            }

            String nativeName = this.template.getHoverName().getString();
            String enchantmentNames = String.join(", ", descriptions);
            this.displayName = !variant.label().isEmpty()
               ? variant.label()
               : (!descriptions.isEmpty() && variant.potion().isEmpty() ? nativeName + " - " + enchantmentNames : nativeName);
            this.searchText = (this.displayName
                  + " "
                  + nativeName
                  + " "
                  + enchantmentNames
                  + " "
                  + this.key()
                  + " "
                  + category.title()
                  + " "
                  + String.join(" ", variant.enchantments().keySet())
                  + " "
                  + variant.potion()
                  + " "
                  + variant.instrument())
               .toLowerCase(Locale.ROOT)
               .replace('_', ' ');
         } else {
            throw new IllegalArgumentException("Entries require a non-air item and 0 <= sell <= buy <= 1000000000, with buy greater than zero");
         }
      }

      public boolean accepts(ItemStack stack) {
         return stack != null && !stack.isEmpty() && ItemStack.isSameItemSameComponents(stack, this.template);
      }

      public ShopCatalog.Category category() {
         return this.category;
      }

      public Item item() {
         return this.item;
      }

      public long buyPrice() {
         return this.buyPrice;
      }

      public long sellPrice() {
         return this.sellPrice;
      }

      public ShopCatalog.Variant variant() {
         return this.variant;
      }

      public ItemStack stack() {
         return this.template.copy();
      }

      public String key() {
         return BuiltInRegistries.ITEM.getKey(this.item) + (this.variant.id().isEmpty() ? "" : "#" + this.variant.id());
      }

      public String displayName() {
         return this.displayName;
      }

      public String searchText() {
         return this.searchText;
      }
   }

   private static final class VanillaLookup {
      private static final Provider VALUE = MinecraftCompat.vanillaLookup();
   }

   public record Variant(String id, String label, Map<String, Integer> enchantments, String potion, String instrument, int flight) {
      public static final ShopCatalog.Variant PLAIN = new ShopCatalog.Variant("", "", Map.of(), "", "", 0);

      public Variant(String id, String label, Map<String, Integer> enchantments, String potion) {
         this(id, label, enchantments, potion, "", 0);
      }

      public Variant {
         id = Objects.requireNonNull(id, "id");
         label = Objects.requireNonNull(label, "label");
         enchantments = Map.copyOf(Objects.requireNonNull(enchantments, "enchantments"));
         potion = Objects.requireNonNull(potion, "potion");
         instrument = Objects.requireNonNull(instrument, "instrument");
         if (!id.isEmpty() && !id.matches("[a-z0-9_./:-]{1,128}")) {
            throw ShopCatalog.invalid("variant must contain 1-128 lowercase letters, numbers, _, ., /, :, or -");
         }

         if (label.length() <= 96 && !label.chars().anyMatch(Character::isISOControl)) {
            int components = (enchantments.isEmpty() ? 0 : 1) + (potion.isEmpty() ? 0 : 1) + (instrument.isEmpty() ? 0 : 1) + (flight == 0 ? 0 : 1);
            if (components > 1) {
               throw ShopCatalog.invalid("Configure only one of enchantments, potion, instrument, or flight");
            }

            if (id.isEmpty() != (components == 0)) {
               throw ShopCatalog.invalid("A variant ID and one component setting must be supplied together");
            }

            if (flight < 0 || flight > 3) {
               throw ShopCatalog.invalid("flight must be 1, 2, or 3");
            }

            if (enchantments.size() > 16) {
               throw ShopCatalog.invalid("An item may configure at most 16 enchantments");
            }
         } else {
            throw ShopCatalog.invalid("label must contain at most 96 printable characters");
         }
      }
   }
}
