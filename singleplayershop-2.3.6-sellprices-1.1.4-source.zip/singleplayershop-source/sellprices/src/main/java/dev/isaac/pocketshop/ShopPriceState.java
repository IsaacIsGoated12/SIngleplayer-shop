package dev.isaac.pocketshop;

import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents.ServerStarted;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents.EndTick;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents.Disconnect;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents.Join;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class ShopPriceState {
   private static final Logger LOGGER = LoggerFactory.getLogger("singleplayershop-sellprices");
   private static final Map<ServerPlayer, Long> sent = new IdentityHashMap<>();
   private static volatile MinecraftServer activeServer;
   private static volatile ShopPriceState.Snapshot snapshot;
   private static long nextRevision;

   private ShopPriceState() {
   }

   static void register() {
      ServerLifecycleEvents.SERVER_STARTED.register((ServerStarted)server -> {
         activeServer = server;
         snapshot = null;
         sent.clear();
         nextRevision = 0L;
      });
      ServerTickEvents.END_SERVER_TICK.register((EndTick)server -> {
         if (server == activeServer) {
            ShopCatalog catalog = PocketShop.catalog();
            ShopPriceState.Snapshot previous = snapshot;
            if (catalog != null && (previous == null || previous.server() != server || previous.catalog() != catalog)) {
               long revision = ++nextRevision;

               List<SellPricePayload> packets;
               try {
                  packets = SellPricePayload.split(revision, PriceCatalogCodec.encode(catalog, server.registryAccess()));
               } catch (RuntimeException invalidCatalog) {
                  LOGGER.error("Could not synchronize shop sell prices; remote prices were cleared.", invalidCatalog);
                  packets = SellPricePayload.split(revision, "null");
               }

               snapshot = new ShopPriceState.Snapshot(server, catalog, revision, packets);
            }

            for (ServerPlayer player : server.getPlayerList().getPlayers()) {
               sendIfNeeded(player);
            }
         }
      });
      ServerPlayConnectionEvents.JOIN.register((Join)(handler, sender, server) -> sendIfNeeded(handler.player));
      ServerPlayConnectionEvents.DISCONNECT.register((Disconnect)(handler, server) -> sent.remove(handler.player));
      ServerLifecycleEvents.SERVER_STOPPING.register(ShopPriceState::clear);
      ServerLifecycleEvents.SERVER_STOPPED.register(ShopPriceState::clear);
   }

   static ShopCatalog catalogFor(MinecraftServer server) {
      ShopPriceState.Snapshot current = snapshot;
      return server != null && server == activeServer && current != null && current.server() == server ? current.catalog() : null;
   }

   private static void sendIfNeeded(ServerPlayer player) {
      ShopPriceState.Snapshot current = snapshot;
      if (current != null && sent.getOrDefault(player, 0L) != current.revision() && ServerPlayNetworking.canSend(player, SellPricePayload.TYPE)) {
         for (SellPricePayload packet : current.packets()) {
            ServerPlayNetworking.send(player, packet);
         }

         sent.put(player, current.revision());
      }
   }

   private static void clear(MinecraftServer server) {
      if (activeServer == server) {
         activeServer = null;
         snapshot = null;
         sent.clear();
      }
   }

   private record Snapshot(MinecraftServer server, ShopCatalog catalog, long revision, List<SellPricePayload> packets) {
   }
}
