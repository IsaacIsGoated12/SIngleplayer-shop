package dev.isaac.pocketshop;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.stream.Stream;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.registries.VanillaRegistries;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.ItemContainerContents;

/** Keeps the two renamed vanilla APIs compatible across 26.1.2, 26.2 and 26.3. */
final class MinecraftCompat {
   private static final Method ITEM_COPIES = renamed(ItemContainerContents.class, "itemCopies", "allItemsCopyStream");

   private MinecraftCompat() {}

   static HolderLookup.Provider vanillaLookup() {
      return (HolderLookup.Provider)invoke(renamed(VanillaRegistries.class, "createWorldLookup", "createLookup"), null);
   }

   @SuppressWarnings("unchecked")
   static Stream<ItemStack> itemCopies(ItemContainerContents contents) {
      return (Stream<ItemStack>)invoke(ITEM_COPIES, contents);
   }

   private static Method renamed(Class<?> type, String current, String previous) {
      try {
         try { return type.getMethod(current); }
         catch (NoSuchMethodException olderVersion) { return type.getMethod(previous); }
      } catch (ReflectiveOperationException exception) {
         throw new IllegalStateException("Unsupported Minecraft API: " + type.getSimpleName(), exception);
      }
   }

   private static Object invoke(Method method, Object receiver) {
      try { return method.invoke(receiver); }
      catch (InvocationTargetException exception) { throw new IllegalStateException("Minecraft registry/container API failed", exception.getCause()); }
      catch (ReflectiveOperationException exception) { throw new IllegalStateException("Minecraft compatibility API failed", exception); }
   }
}
