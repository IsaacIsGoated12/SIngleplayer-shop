package dev.isaac.pocketshop;

import dev.isaac.pocketshop.SaleContents.Plan;
import dev.isaac.pocketshop.ShopCatalog.Entry;
import java.util.List;
import java.util.function.ToLongFunction;
import java.util.function.Function;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;

public final class SellPriceTooltip {
   private SellPriceTooltip() {
   }

   public static void append(ShopCatalog catalog, ItemStack stack, List<Component> lines) {
      if (catalog != null && stack != null && !stack.isEmpty()) {
         appendQuote(stack, catalog::sellPrice, catalog::valuation, lines);
      }
   }

   public static void appendIndex(SellPriceIndex index, ItemStack stack, List<Component> lines) {
      if (index != null && stack != null && !stack.isEmpty()) {
         appendQuote(stack, index::sellPrice, index::valuation, lines);
      }
   }

   private static void appendQuote(ItemStack stack, ToLongFunction<ItemStack> prices, Function<ItemStack,ItemValuation.Breakdown> values, List<Component> lines) {
      if (!TooltipOptions.enabled) return;
      if (!TooltipOptions.compact) {
         lines.add(Component.empty());
         lines.add(text("Singleplayer Shop", ChatFormatting.DARK_GRAY));
      }
      Plan sale = SaleContents.plan(stack, prices);
      if (!sale.valid()) {
         lines.add(text("Sell: Value exceeds the safe limit", ChatFormatting.GRAY));
         return;
      }
      if (SaleContents.isShulker(stack)) {
         Plan contents = sale;
         if (contents.count() > 0) {
            lines.add(text("Sell contents: " + ShopTransactions.money(contents.total()), ChatFormatting.GOLD));
            lines.add(text(contents.count() + " sellable item" + (contents.count() == 1 ? "" : "s"), ChatFormatting.GREEN));
         } else {
            lines.add(text("No sellable contents", ChatFormatting.GRAY));
         }

         lines.add(text("Shulker box kept", ChatFormatting.GRAY));
      } else {
         long price = sale.count() > 0 ? prices.applyAsLong(stack) : 0L;
         if (price <= 0L) {
            String reason = values.apply(stack).rejection();
            if(reason.isEmpty()) reason="Stored contents protected";
            lines.add(text("Sell: " + reason, ChatFormatting.GRAY));
         } else {
            if (TooltipOptions.compact) {
               lines.add(text("Sell: " + ShopTransactions.money(price) + " each | " + stack.getCount() + " = " + ShopTransactions.money(sale.total()), ChatFormatting.GREEN));
               return;
            }
            lines.add(text("Sell: " + ShopTransactions.money(price) + " each", ChatFormatting.GREEN));
            ItemValuation.Breakdown value=values.apply(stack);
            if(!value.lines().isEmpty() || stack.isDamageableItem() || value.base()>=10000) {
               lines.addAll(ValuationDetails.lines(stack,value,TooltipOptions.details));
            }
            if (stack.getCount() > 1) {
               long total = Math.multiplyExact((long)price, (long)stack.getCount());
               lines.add(text("Stack (" + stack.getCount() + "): " + ShopTransactions.money(total), ChatFormatting.GOLD));
            }
            if (TooltipOptions.fullStack && stack.getMaxStackSize() > 1 && stack.getCount() != stack.getMaxStackSize()) {
               lines.add(text("Full stack (" + stack.getMaxStackSize() + "): " + ShopTransactions.money(Math.multiplyExact(price, stack.getMaxStackSize())), ChatFormatting.GRAY));
            }
         }
      }
   }

   private static Component text(String value, ChatFormatting color) {
      return Component.literal(value).withStyle(color).withStyle(style -> style.withItalic(false));
   }
}
