# Singleplayer Shop 2.3.6 + Sell Prices 1.1.4 — Treasure Economy

Fabric / Java 25. Minecraft **26.1.2, 26.2, and 26.3**.

## Install

Close Minecraft. Replace both older mod JARs with `singleplayershop-2.3.6.jar` and `singleplayershop-sellprices-1.1.4.jar`; keep one version of each installed. Keep the matching Fabric API for your Minecraft version. Validation used Loader 0.19.5 and API 0.155.3+26.1.2, 0.161.0+26.2, and 0.163.0+26.3.

Update both mods together. The shop can run without the addon. LAN/e4mc guests need the matching shop and addon to see synchronized tooltips. Price protocol 3 prevents older clients from interpreting the new economy with the old formula. These locally built releases have not been uploaded to Modrinth.

## What changed

Rare loot now funds real upgrades. Basic crops and building supplies keep their earlier survival prices, while enchanted books, diamond/netherite equipment, elytra, maces, tridents and other treasures command much higher prices. Starting money remains $1,000.

Natural finds at full durability, using the defaults:

| Find | Sell value |
|---|---:|
| Wooden sword, Sharpness I | $82 |
| Wooden sword, Sharpness V | $646 |
| Mending I book | $64,000 |
| Swift Sneak III book | $100,000 |
| Wind Burst III book | $180,000 |
| Elytra, unenchanted | $120,000 |
| Elytra, Unbreaking III + Mending I | $300,600 |
| Diamond pickaxe, Efficiency V / Fortune III / Unbreaking III / Mending I | $222,135 |
| Netherite pickaxe, same four enchantments | $366,201 |
| Treasure Netherite Boots shop variant, naturally obtained equivalent | $524,748 |

These are **natural-item** values. Shop purchases sell for $0. Individual items depend on enchantments, durability, curses and any host price customizations. `price-guide-2.3.6.csv` contains the actual full-condition appraisal for every listing, exported through the release JAR.

Eight new Treasure armor loadouts cover diamond and netherite helmets, chestplates, leggings and boots, adding Thorns III to their compatible protection sets. Enchanted purchased equipment is priced from its base item and all included books. Other rare finds now have substantial payouts too: Nether star $50,000, dragon head $30,000, enchanted golden apple $20,000, heavy core $30,000, and trident $20,000. Beacons, conduits, recovery compasses and shulker boxes have purchase prices consistent with their rare ingredients. Dragon eggs remain protected from selling.

## How appraisals work

1. Start with the ordinary item's configured sell value. An enchanted book has no material base value.
2. Each priced, non-curse enchantment contributes **40% of the matching level's book buy price**, then receives the equipment factor below. A book itself uses 100%.
3. For damageable equipment, two or more priced maximum-level enchantments add 5% per additional maximum-level enchantment, up to **15% of the enchantment subtotal**.
4. Cap the combined pre-discount appraisal at $1 billion. Apply a **25% discount per curse**, then multiply the entire price by the remaining durability fraction. Integer calculations round down at each step.

Material factors for sword/helmet-sized equipment are Wood 2%, Stone 4%, Copper 8%, Leather 6%, Gold 12%, Chainmail 18%, Iron 25%, Diamond 100%, and Netherite 160%. Equipment type also matters: chestplate x1.40, leggings x1.25, boots x0.90, pickaxe x1.10, axe x1.05, shovel x0.65, hoe x0.60, and spear x1.15. The combined factor is rounded down and capped at 200%. Bow 65%, crossbow 75%, fishing rod 55%, turtle shell 65%, and other listed utility equipment 35% have their own factors. Elytra use 200%, tridents 150%, and maces 180%.

All enchantments on the item are inspected; only enchantment/level combinations with a host-configured book price add value. Invalid levels and unexpected gameplay components remain protected. Named enchanted gear/books, armor trims, dye and shield decoration are supported without a separate cosmetic premium. Ordinary custom-named items remain protected. Host-defined positive prices for exact variants override the formula for that exact stack.

Rarity labels summarize the **current sell value**, rather than changing the price: Common below $1,000; Uncommon $1,000+; Rare $10,000+; Epic $100,000+; Legendary $250,000+. A worn item can move to a lower value band.

## New ways to inspect and earn

- **`/shop inspect`** or **`/worth details`**: hold an item to see its base value, material/equipment factor, every enchantment contribution, maximum-level bonus, curse/wear discounts and full-condition value.
- **`/worth top`**: show the five most valuable stacks in your 36 inventory slots, including eligible shulker contents. Equipped armor and offhand are excluded.
- **`/worth inventory`**: total eligible inventory value and how many stacks will be kept.
- **`/shop economy`**: explain the new appraisal system in game.
- **`/earn prices`**: includes enchanted books and equipment, sorts by actual calculated payout, and counts only matching natural items you own. Modified/worn variants can be inspected with `/worth top`.
- Shop listings and sale-selection icons show appraisal breakdowns even without the addon.

Sell Prices 1.1.4 displays rarity, equipment factor, individual enchantment prices, loadout bonus, curse/wear discounts, durability remaining and value at full condition. Stack totals and shulker-content totals continue to use the same authoritative host calculation as real sales.

`/sellprices` toggles tooltips; `/sellprices compact` switches to one price line; **`/sellprices details`** toggles individual enchantment lines; `/sellprices reload` reloads client preferences. Config file `singleplayershop-sellprices.json` accepts boolean `enabled`, `compact`, `fullStack`, and `details`. Older preference files keep working; missing `details` defaults to true.

## Sell Axe

Use **`/shop sellaxe`** or the Utility category. The default price is **$900,000**, reflecting the new late-game economy. It is a real **netherite axe**, named **Sell Axe**, with Efficiency V, Unbreaking III, Mending I, Sharpness V and Fortune III. These are compatible maximum survival levels; Fortune excludes Silk Touch. Its persistent tool marker prevents ordinary renamed axes from acting as Sell Axes.

1. Hit a supported storage block **without sneaking** to preview eligible contents, total payout, protected stacks and the **most valuable stack**.
2. **Sneak-hit the same storage block within 15 seconds** to confirm that exact review.
3. The storage block stays. Protected contents stay in their slots. Shulker boxes stay, with only eligible contents sold.

Supported storage:

- Chests, double chests and trapped chests.
- Barrels, uncolored shulker boxes and all 16 colored shulker boxes.
- Hoppers, dispensers and droppers.
- Furnaces, blast furnaces, smokers, brewing stands and crafters. The preview includes eligible input, fuel and output slots.
- Chiseled bookshelves, shelves, decorated pots and jukeboxes. A shelf sale covers the clicked shelf, without sweeping its linked neighbors.
- Ender Chests: **only the interacting player's personal inventory** is inspected or sold. Another player's Ender Chest contents are never selected.
- Compatible additional storage block entities exposing vanilla `Container` inventories, from 1 through 4,096 slots. Transfer-API-only storage and special virtual inventories are not automatically supported.

A changed storage block, changed prices, changed contents, invalid access or full wallet rejects the sale. Both halves of a double chest are revalidated. Locks, access, distance and unopened loot are checked before reading inventory, and checked again when confirming. Open/interact with undiscovered loot storage normally once first. Chest obstruction and shulker opening clearance are respected. Ender Chest checks use the clicked block without changing your active/open chest. Spectator and vanilla spawn-protected interactions are refused. Integration with other mods' claim/ownership rules is not implemented. Renaming or disenchanting the special axe makes it behave like an ordinary axe.

The transaction checks that the inventory actually applied its removals before retaining the payout. Read-only or failed inventory writes trigger rollback. Normal block-breaking with a Sell Axe is cancelled for supported storage; using an ordinary tool still behaves normally.

## Existing saves and purchase protection

Catalog version 6 automatically upgrades untouched default prices, preserves customized prices and deliberate listing removals, and writes an exact `.pre-expansion.json` backup before replacing an existing config. Version-5 defaults are included for upgrades from 2.3.5, alongside older baselines. Wallet save IDs and quest progress IDs stay compatible. A failed live reload retains the previous working catalog; successful reload closes stale shop menus.

New purchases carry a persistent item component and cannot be directly resold, including through inventory, shulker or storage sales and quest delivery. Purchased stacks stay separate from natural stacks. **Earlier purchases cannot be identified retroactively.** The marker survives item copying/saving and transformations that retain those components. It does not globally trace ingredients, crafted/smelted derivatives or placed-and-broken blocks; vanilla transformations can discard item components.

Existing commands remain available: `/shop`, `/shop search <name>`, `/shop enchants`, `/shop potions`, `/shop price [item]`, `/shop help`, `/shop info`, `/shop reload` (owner/operator), `/sell`, `/sell all`, `/sell hand`, `/worth`, `/earn`, `/balance`, and `/pay`.

## Build and validation

The source archive includes MIT-licensed Java sources, resources, catalog migration baselines, integration tests and a portable Python/JDK builder:

```text
python build_release.py --jdk "C:\path\to\jdk-25" --test
```

Python 3.10+ and JDK 25 are required. The builder downloads/checks dependencies and writes both JARs and checksums to `dist`. A Gradle/Loom wrapper is also included (`gradlew.bat build :sellprices:verifyRelease`); this desktop environment could not complete Loom's Java HTTP downloader because of a loopback-connection error. Release builds used the Python/JDK route.

The finished JARs passed automated tests on all three listed Minecraft versions and Fabric server/client entrypoint smoke checks on 26.3. The recipe audit found no profitable plain buy/craft/resell route among 1,664 modeled routes; it does not model trades, farms, loot generation, modded recipes or component-dependent recipes. Balance is a design choice and may benefit from survival playtesting. No graphical world playthrough or cross-machine LAN/e4mc test was performed. See `VALIDATION-2.3.6.md`.
