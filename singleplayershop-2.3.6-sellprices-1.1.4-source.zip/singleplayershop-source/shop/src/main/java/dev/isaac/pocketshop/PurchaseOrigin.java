package dev.isaac.pocketshop;

import net.minecraft.core.component.DataComponents;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;

/** Vanilla-synchronized, persistent provenance; copied stacks keep their purchase status. */
public final class PurchaseOrigin {
   private static final String KEY = "pocketshop:purchased";
   private PurchaseOrigin() {}

   public static boolean isPurchased(ItemStack stack) {
      if (stack == null || stack.isEmpty()) return false;
      CustomData data = stack.get(DataComponents.CUSTOM_DATA);
      return data != null && data.copyTag().getBooleanOr(KEY, false);
   }

   public static ItemStack mark(ItemStack stack) {
      if (stack != null && !stack.isEmpty()) CustomData.update(DataComponents.CUSTOM_DATA, stack, tag -> tag.putBoolean(KEY, true));
      return stack;
   }

   public static ItemStack purchasedCopy(ItemStack stack) { return mark(stack.copy()); }
}
