package dev.isaac.pocketshop;

import java.util.*;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;

/** Shared readable receipt for commands, shop menus and the optional tooltip addon. */
public final class ValuationDetails {
   private ValuationDetails() {}
   public static List<Component> lines(ItemStack stack,ItemValuation.Breakdown value,boolean eachEnchantment) {
      List<Component> lines=new ArrayList<>();
      if(value.total()<=0) {lines.add(text(value.rejection(),ChatFormatting.GRAY));return lines;}
      lines.add(text(value.rarity()+" | "+value.profile().name(),value.total()>=100_000?ChatFormatting.LIGHT_PURPLE:ChatFormatting.AQUA));
      lines.add(text("Base item: "+money(value.base()),ChatFormatting.GRAY));
      if(value.override()) lines.add(text("Exact variant price set by the host",ChatFormatting.GRAY));
      if(!value.lines().isEmpty()) {
         lines.add(text("Enchantments: +"+money(value.enchantments())+" | equipment factor "+value.profile().enchantmentPercent()+"%",ChatFormatting.GRAY));
         if(eachEnchantment) for(var enchantment:value.lines()) {
            String suffix=enchantment.curse()?" (25% curse penalty)":enchantment.priced()?" +"+money(enchantment.value()):" (no book price configured)";
            var name=enchantment.enchantment().value().description().copy();
            if(enchantment.level()>1 || enchantment.enchantment().value().getMaxLevel()>1) name.append(" ").append(Component.translatable("enchantment.level."+enchantment.level()));
            lines.add(Component.literal("  ").append(name).append(suffix).withStyle(ChatFormatting.DARK_GRAY).withStyle(style->style.withItalic(false)));
         }
      }
      if(value.setBonus()>0) lines.add(text("Max-level loadout bonus: +"+money(value.setBonus()),ChatFormatting.GREEN));
      if(value.limitLoss()>0) lines.add(text("Price cap reduction: -"+money(value.limitLoss()),ChatFormatting.GRAY));
      if(value.curseLoss()>0) lines.add(text("Curse discount: -"+money(value.curseLoss()),ChatFormatting.RED));
      if(stack.isDamageableItem()) {
         int remaining=Math.max(0,stack.getMaxDamage()-stack.getDamageValue());
         lines.add(text("Condition: "+value.conditionPercent()+"% ("+remaining+"/"+stack.getMaxDamage()+")",ChatFormatting.GRAY));
         if(value.wearLoss()>0) {
            lines.add(text("Wear discount: -"+money(value.wearLoss()),ChatFormatting.RED));
            lines.add(text("At full condition: "+money(value.fullCondition()),ChatFormatting.GRAY));
         }
      }
      return lines;
   }
   private static String money(long value) {return ShopTransactions.money(value);}
   private static Component text(String value,ChatFormatting color) {return Component.literal(value).withStyle(color).withStyle(style->style.withItalic(false));}
}
