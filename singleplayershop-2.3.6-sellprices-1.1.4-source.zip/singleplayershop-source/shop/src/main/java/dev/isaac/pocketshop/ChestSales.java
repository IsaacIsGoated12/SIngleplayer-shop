package dev.isaac.pocketshop;

import java.util.*;
import net.minecraft.world.Container;
import net.minecraft.world.item.ItemStack;

/** Snapshot-based container sale. The storage block itself is never removed or sold. */
public final class ChestSales {
   public static final int MAX_STORAGE_SLOTS=4096;
   private ChestSales() {}

   public static Review review(Container container,ShopCatalog catalog) {
      Objects.requireNonNull(container);Objects.requireNonNull(catalog);
      int size=container.getContainerSize();
      if(size<1 || size>MAX_STORAGE_SLOTS) throw new IllegalArgumentException("Supported storage size is 1 through "+MAX_STORAGE_SLOTS+" slots");
      if(SellStorage.hasUnopenedLoot(container)) throw new IllegalArgumentException("Loot storage must be opened normally before selling");
      List<ItemStack> snapshot=new ArrayList<>();
      int count=0,kept=0;long total=0,bestTotal=0;String bestName="";
      for(int slot=0;slot<size;slot++) {
         ItemStack item=container.getItem(slot).copy();snapshot.add(item);
         SaleContents.Plan plan=SaleContents.plan(item,catalog::sellPrice);
         if(!plan.valid()) throw new IllegalArgumentException("Storage value exceeds the safe limit");
         count=Math.addExact(count,plan.count());total=Math.addExact(total,plan.total());
         if(!plan.remaining().isEmpty()) kept++;
         if(plan.total()>bestTotal) {bestTotal=plan.total();bestName=item.getHoverName().getString()+(SaleContents.isShulker(item)?" (contents)":"");}
      }
      return new Review(container,catalog,List.copyOf(snapshot),count,total,kept,bestName,bestTotal);
   }

   public static ShopTransactions.Result sell(Container container,Review review,ShopCatalog catalog,Wallets wallets,UUID player) {
      if(review==null || review.container!=container || review.catalog!=catalog || container.getContainerSize()!=review.snapshot.size() || SellStorage.hasUnopenedLoot(container)) return failure("Storage or prices changed. Hit it again to review.");
      for(int slot=0;slot<review.snapshot.size();slot++) if(!ItemStack.matches(container.getItem(slot),review.snapshot.get(slot))) return failure("Storage contents changed. Nothing was sold; hit it again to review.");
      if(review.count<=0) return failure("No eligible items in this storage. Everything was kept.");
      List<ItemStack> remaining=new ArrayList<>();
      for(ItemStack original:review.snapshot) remaining.add(SaleContents.plan(original,catalog::sellPrice).remaining());
      if(!wallets.credit(player,catalog.startingBalance(),review.total)) return failure("This sale would exceed your balance limit. All storage contents were kept.");
      List<Integer> changed=new ArrayList<>();
      try {
         for(int slot=0;slot<remaining.size();slot++) if(!ItemStack.matches(remaining.get(slot),review.snapshot.get(slot))) {
            changed.add(slot);container.setItem(slot,remaining.get(slot));
         }
         for(int slot=0;slot<remaining.size();slot++) if(!ItemStack.matches(container.getItem(slot),remaining.get(slot))) throw new IllegalStateException("Storage did not apply the reviewed changes");
         container.setChanged();
      } catch(RuntimeException failure) {
         wallets.debit(player,catalog.startingBalance(),review.total);
         for(int slot:changed) container.setItem(slot,review.snapshot.get(slot).copy());
         container.setChanged();
         throw failure;
      }
      return new ShopTransactions.Result(true,"Sold "+review.count+" stored items for "+ShopTransactions.money(review.total)+". Storage block and protected contents kept.",review.count,review.total);
   }

   private static ShopTransactions.Result failure(String message) { return new ShopTransactions.Result(false,message,0,0); }
   public static final class Review {
      private final Container container;
      private final ShopCatalog catalog;
      private final List<ItemStack> snapshot;
      private final int count,kept;
      private final long total;
      private final String bestName;
      private final long bestTotal;
      private Review(Container container,ShopCatalog catalog,List<ItemStack> snapshot,int count,long total,int kept,String bestName,long bestTotal) {
         this.container=container;this.catalog=catalog;this.snapshot=snapshot;this.count=count;this.total=total;this.kept=kept;
         this.bestName=bestName;this.bestTotal=bestTotal;
      }
      public int count() { return count; }
      public long total() { return total; }
      public int keptStacks() { return kept; }
      public String bestName() {return bestName;}
      public long bestTotal() {return bestTotal;}
   }
}
