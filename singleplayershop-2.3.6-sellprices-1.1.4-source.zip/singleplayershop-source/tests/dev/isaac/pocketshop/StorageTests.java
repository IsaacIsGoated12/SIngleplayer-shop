package dev.isaac.pocketshop;

import java.util.*;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.*;
import net.minecraft.world.inventory.PlayerEnderChestContainer;
import net.minecraft.world.item.*;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.*;

/** Real vanilla storage inventories, with no live world or player required. */
public final class StorageTests {
   private static int checks;
   private static void check(boolean value,String name) {checks++;if(!value) throw new AssertionError(name);}
   public static int run(ShopCatalog catalog) {
      checks=0;int kinds=0;
      List<String> blocks=new ArrayList<>(List.of("chest","trapped_chest","barrel","shulker_box","hopper","dispenser","dropper","furnace","blast_furnace","smoker","brewing_stand","crafter","chiseled_bookshelf","decorated_pot","oak_shelf","jukebox"));
      for(var color:DyeColor.values()) blocks.add(color.getName()+"_shulker_box");
      for(String name:blocks) {
         var id=Identifier.parse("minecraft:"+name);
         if(!BuiltInRegistries.BLOCK.containsKey(id)) continue;
         var block=BuiltInRegistries.BLOCK.getValue(id);
         BlockEntity entity=((EntityBlock)block).newBlockEntity(BlockPos.ZERO,block.defaultBlockState());
         check(SellStorage.supports(entity),"Sell Axe recognizes "+name);
         Container storage=(Container)entity;kinds++;
         check(storage.getContainerSize()>0,"vanilla storage has slots "+name);
         // These inventories publish visual/game events when edited and need a world for mutation.
         if(entity instanceof ChiseledBookShelfBlockEntity || entity instanceof JukeboxBlockEntity) {
            check(ChestSales.review(storage,catalog).count()==0,"empty display storage quoted safely "+name);
            continue;
         }
         storage.setItem(0,new ItemStack(Items.WHEAT,Math.min(10,storage.getMaxStackSize())));
         int count=storage.getItem(0).getCount();long expected=count*4L;
         if(storage.getContainerSize()>1) storage.setItem(storage.getContainerSize()-1,PurchaseOrigin.purchasedCopy(new ItemStack(Items.DIAMOND)));
         var review=ChestSales.review(storage,catalog);
         check(review.total()==expected && review.count()==count,"actual vanilla inventory quoted "+name);
         check(review.keptStacks()==(storage.getContainerSize()>1?1:0),"purchased contents kept "+name);
         var wallet=new Wallets();UUID player=UUID.randomUUID();
         check(ChestSales.sell(storage,review,catalog,wallet,player).success(),"actual vanilla inventory sold "+name);
         check(storage.getItem(0).isEmpty() && wallet.balance(player,0)==catalog.startingBalance()+expected,"correct removal and payout "+name);
         if(storage.getContainerSize()>1) check(PurchaseOrigin.isPurchased(storage.getItem(storage.getContainerSize()-1)),"protected contents unchanged "+name);
         check(!entity.isRemoved(),"storage block entity kept "+name);
         check(!ChestSales.sell(storage,review,catalog,wallet,player).success(),"repeated review cannot pay twice "+name);
      }
      var ender=new EnderChestBlockEntity(BlockPos.ZERO,Blocks.ENDER_CHEST.defaultBlockState());
      check(SellStorage.supports(ender),"Ender Chest recognized");
      var alice=new PlayerEnderChestContainer();var bob=new PlayerEnderChestContainer();
      alice.setItem(0,new ItemStack(Items.WHEAT,10));bob.setItem(0,new ItemStack(Items.DIAMOND));
      var aTarget=new SellStorage.Target(alice,List.of(ender),false);
      check(aTarget.sameStorage(new SellStorage.Target(alice,List.of(ender),false)),"same player's Ender Chest target matches");
      check(!aTarget.sameStorage(new SellStorage.Target(bob,List.of(ender),false)),"another player's Ender Chest never matches");
      var review=ChestSales.review(alice,catalog);var wallet=new Wallets();UUID player=UUID.randomUUID();
      check(!ChestSales.sell(bob,review,catalog,wallet,player).success(),"Ender Chest review cannot be applied to another inventory");
      check(ChestSales.sell(alice,review,catalog,wallet,player).success() && bob.getItem(0).is(Items.DIAMOND),"Ender Chest sale touches only the chosen player's contents");
      var left=new ChestBlockEntity(BlockPos.ZERO,Blocks.CHEST.defaultBlockState());var right=new ChestBlockEntity(BlockPos.ZERO.east(),Blocks.CHEST.defaultBlockState());
      var doubleTarget=new SellStorage.Target(new CompoundContainer(left,right),List.of(left,right),true);
      check(doubleTarget.sameStorage(new SellStorage.Target(new CompoundContainer(left,right),List.of(left,right),true)),"rebuilt double-chest wrapper keeps the same target");
      var replacement=new ChestBlockEntity(BlockPos.ZERO.east(),Blocks.CHEST.defaultBlockState());
      check(!doubleTarget.sameStorage(new SellStorage.Target(new CompoundContainer(left,replacement),List.of(left,replacement),true)),"replaced double-chest half invalidates target");
      check(!doubleTarget.sameStorage(new SellStorage.Target(left,List.of(left),false)),"double chest changed to single invalidates target");
      var barrel=new BarrelBlockEntity(BlockPos.ZERO,Blocks.BARREL.defaultBlockState());
      barrel.setLootTable(ResourceKey.create(Registries.LOOT_TABLE,Identifier.parse("minecraft:chests/simple_dungeon")));
      check(SellStorage.hasUnopenedLoot(barrel),"unopened barrel loot detected without reading contents");
      try {ChestSales.review(barrel,catalog);throw new AssertionError("unopened loot should not be generated by sale");} catch(IllegalArgumentException expected) {checks++;}
      check(barrel.getLootTable()!=null,"quoting leaves unopened loot table intact");
      var wide=new SimpleContainer(108);wide.setItem(107,new ItemStack(Items.WHEAT,10));
      check(ChestSales.review(wide,catalog).total()==40,"compatible storage larger than a double chest supported");
      try {ChestSales.review(new SimpleContainer(ChestSales.MAX_STORAGE_SLOTS+1),catalog);throw new AssertionError("oversized storage accepted");} catch(IllegalArgumentException expected) {checks++;}
      var readOnly=new SimpleContainer(new ItemStack(Items.WHEAT,10)) {
         @Override public void setItem(int slot,ItemStack stack) { /* Simulates an incompatible, read-only inventory. */ }
      };
      review=ChestSales.review(readOnly,catalog);wallet=new Wallets();player=UUID.randomUUID();
      try {ChestSales.sell(readOnly,review,catalog,wallet,player);throw new AssertionError("read-only inventory paid out");} catch(IllegalStateException expected) {checks++;}
      check(wallet.balance(player,0)==catalog.startingBalance() && readOnly.getItem(0).getCount()==10,"ignored writes cannot create money or consume items");
      var failing=new SimpleContainer(9) {
         boolean failed;
         @Override public void setItem(int slot,ItemStack stack) {
            if(slot==1 && stack.isEmpty() && !failed) {failed=true;throw new IllegalStateException("Injected write failure");}
            super.setItem(slot,stack);
         }
      };
      failing.setItem(0,new ItemStack(Items.DIAMOND));failing.setItem(1,new ItemStack(Items.WHEAT,10));
      review=ChestSales.review(failing,catalog);wallet=new Wallets();player=UUID.randomUUID();
      try {ChestSales.sell(failing,review,catalog,wallet,player);throw new AssertionError("failed write paid out");} catch(IllegalStateException expected) {checks++;}
      check(wallet.balance(player,0)==catalog.startingBalance() && failing.getItem(0).is(Items.DIAMOND) && failing.getItem(1).getCount()==10,"partial write failure restores original items and wallet");
      check(!SellStorage.supports(null) && !SellStorage.supports(new BeaconBlockEntity(BlockPos.ZERO,Blocks.BEACON.defaultBlockState())),"non-storage blocks never intercepted");
      System.out.println("Storage coverage: "+kinds+" vanilla block variants plus private Ender Chest inventories");
      return checks;
   }
}
