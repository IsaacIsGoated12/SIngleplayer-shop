package dev.isaac.pocketshop;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.permissions.Permissions;
import net.minecraft.world.item.ItemStack;

final class ShopCommands {
   private ShopCommands() {}

   static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
      dispatcher.register(Commands.literal("shop")
         .then(Commands.literal("help").executes(context -> help(context.getSource())))
         .then(Commands.literal("economy").executes(context -> economy(context.getSource())))
         .then(Commands.literal("inspect").executes(context -> inspect(context.getSource())))
         .then(Commands.literal("sellaxe").executes(context -> { PocketShop.openSellAxe(context.getSource().getPlayerOrException());return 1; }))
         .then(Commands.literal("info").executes(context -> {
            int count = java.util.Arrays.stream(ShopCatalog.Category.values()).mapToInt(c -> PocketShop.catalog().entries(c).size()).sum();
            context.getSource().sendSuccess(() -> Component.literal("Singleplayer Shop 2.3.6 | " + count + " listings | " + QuestBoard.quests(PocketShop.catalog()).size() + " delivery quests. Use /shop help.").withStyle(ChatFormatting.GOLD), false);
            return 1;
         }))
         .then(Commands.literal("price")
            .executes(context -> price(context.getSource(), context.getSource().getPlayerOrException().getMainHandItem()))
            .then(Commands.argument("item", StringArgumentType.word()).executes(context -> {
               String query = StringArgumentType.getString(context, "item");
               Identifier id = Identifier.tryParse(query);
               if (id == null || !BuiltInRegistries.ITEM.containsKey(id)) {
                  context.getSource().sendFailure(Component.literal("Unknown item. Try /shop price minecraft:diamond, or hold an item and use /shop price."));
                  return 0;
               }
               return price(context.getSource(), new ItemStack(BuiltInRegistries.ITEM.getValue(id)));
            })))
         .then(Commands.literal("reload").requires(source -> source.permissions().hasPermission(Permissions.COMMANDS_GAMEMASTER)
            || (source.getPlayer() != null && source.getServer().isSingleplayerOwner(new net.minecraft.server.players.NameAndId(source.getPlayer().getGameProfile()))))
            .executes(context -> {
               try {
                  PocketShop.reloadCatalog(context.getSource().getServer());
                  context.getSource().sendSuccess(() -> Component.literal("Shop prices reloaded. Open shops were closed so old quotes cannot be used."), true);
                  return 1;
               } catch (Exception exception) {
                  context.getSource().sendFailure(Component.literal("Reload rejected: " + exception.getMessage() + " The last working shop prices are still active."));
                  return 0;
               }
            })));
      dispatcher.register(Commands.literal("worth")
         .then(Commands.literal("details").executes(context -> inspect(context.getSource())))
         .then(Commands.literal("top").executes(context -> top(context.getSource())))
         .then(Commands.literal("inventory").executes(context -> {
         var player = context.getSource().getPlayerOrException();
         var quote = InventoryAppraisal.inspect(player.getInventory(),36,PocketShop.catalog());
         player.sendSystemMessage(Component.literal(quote.count() + " sellable items: " + ShopTransactions.money(quote.total()) + "; "+quote.keptStacks()+" stacks kept. /worth top shows your five most valuable stacks. Equipment and offhand excluded.").withStyle(ChatFormatting.GOLD));
         return 1;
      })));
   }

   private static int price(CommandSourceStack source, ItemStack stack) {
      if(PurchaseOrigin.isPurchased(stack)) {
         source.sendFailure(Component.literal("Shop purchase: this item cannot be resold."));return 0;
      }
      long resale=PocketShop.catalog().sellPrice(stack);
      var found = PocketShop.catalog().find(stack);
      if (found.isEmpty() && resale<=0) {
         source.sendFailure(Component.literal("This item is protected or has no exact shop listing. Use /shop search to browse item variants."));
         return 0;
      }
      var breakdown=PocketShop.catalog().valuation(stack);
      String buy=found.map(entry -> " | Buy "+ShopTransactions.money(entry.buyPrice())+" each").orElse("");
      source.sendSuccess(() -> Component.literal(stack.getHoverName().getString()+buy+" | Sell "+ShopTransactions.money(resale)+" each | "+breakdown.rarity()+" | /shop inspect for the full appraisal").withStyle(ChatFormatting.GOLD), false);
      return 1;
   }

   private static int inspect(CommandSourceStack source) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
      ItemStack stack=source.getPlayerOrException().getMainHandItem();
      var value=PocketShop.catalog().valuation(stack);
      source.sendSuccess(()->Component.literal(stack.getHoverName().getString()+" | Sell "+ShopTransactions.money(value.total())+" each").withStyle(ChatFormatting.GOLD),false);
      for(Component line:ValuationDetails.lines(stack,value,true)) source.sendSuccess(()->line,false);
      return value.total()>0?1:0;
   }

   private static int top(CommandSourceStack source) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
      var summary=InventoryAppraisal.inspect(source.getPlayerOrException().getInventory(),36,PocketShop.catalog());
      source.sendSuccess(()->Component.literal("Inventory worth: "+ShopTransactions.money(summary.total())+" | "+summary.keptStacks()+" stacks kept. Five most valuable stacks:").withStyle(ChatFormatting.GOLD),false);
      for(var item:summary.top()) source.sendSuccess(()->Component.literal("Slot "+(item.slot()+1)+": "+item.name()+" | "+item.count()+" sellable | "+ShopTransactions.money(item.total())).withStyle(ChatFormatting.AQUA),false);
      source.sendSuccess(()->Component.literal("/sell all opens a review. Equipment and offhand are excluded.").withStyle(ChatFormatting.GRAY),false);
      return 1;
   }

   private static int economy(CommandSourceStack source) {
      for(String line:new String[]{
         "Treasure Economy | Common supplies stay affordable; rare finds fund major upgrades.",
         "Natural enchanted books: 40% of the host's matching book buy price. Curses add no value.",
         "Equipment: base item + enchantments scaled by material AND item type; wood is cheapest, diamond/netherite are premium.",
         "Elytra, tridents and maces have special treasure factors. Two or more priced max-level enchants earn up to a 15% loadout bonus.",
         "Each curse discounts 25%; wear lowers the complete price. /shop inspect shows every contribution.",
         "Epic = $100,000+; Legendary = $250,000+ at the item's current condition. Rarity labels summarize value.",
         "Shop purchases cannot be resold. /worth top finds valuable inventory stacks; /shop sellaxe opens the storage-selling tool."
      }) source.sendSuccess(()->Component.literal(line).withStyle(ChatFormatting.GOLD),false);
      return 1;
   }

   private static int help(CommandSourceStack source) {
      for (String line : new String[]{
         "Singleplayer Shop 2.3.6",
         "/shop | /shop search <item> | /shop enchants | /shop potions",
         "/shop price [item] | /shop inspect - full held-item appraisal",
         "/shop economy - rarity, material, enchantment and condition guide",
         "/shop sellaxe - buy the max-enchanted netherite Sell Axe",
         "/sell | /sell all - review a sale; /sell hand - sell held stack immediately",
         "/worth | /worth inventory | /worth top | /worth details - preview values",
         "/earn | /earn prices | /balance | /pay <player> <amount>",
         "Natural enchanted gear is valued by enchantments and durability. Shop purchases cannot be resold.",
         "Sell Axe: hit storage to preview, then sneak-hit to sell. Storage block and protected contents stay."
      }) source.sendSuccess(() -> Component.literal(line).withStyle(ChatFormatting.GOLD), false);
      return 1;
   }
}
