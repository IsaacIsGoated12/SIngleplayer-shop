package dev.isaac.pocketshop;

import java.util.*;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Container;
import net.minecraft.world.RandomizableContainer;
import net.minecraft.world.entity.monster.Shulker;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.ShulkerBoxBlock;
import net.minecraft.world.level.block.entity.*;
import net.minecraft.world.level.block.state.properties.ChestType;
import net.minecraft.world.phys.Vec3;

/** Resolves the clicked storage and checks access without opening or generating loot. */
final class SellStorage {
   private SellStorage() {}

   static boolean supports(BlockEntity entity) {
      return entity instanceof Container || entity instanceof EnderChestBlockEntity;
   }

   static boolean hasUnopenedLoot(Container container) {
      return container instanceof RandomizableContainer randomizable && randomizable.getLootTable()!=null;
   }

   static Target resolve(ServerPlayer player,BlockPos position) {
      Level level=player.level();
      var state=level.getBlockState(position);
      BlockEntity entity=level.getBlockEntity(position);
      if(!supports(entity)) throw new IllegalArgumentException("This block has no supported storage inventory.");
      checkAnchor(player,entity);
      List<BlockEntity> anchors=new ArrayList<>();anchors.add(entity);
      Container container;
      boolean combined=false;
      if(state.getBlock() instanceof ChestBlock chest && entity instanceof ChestBlockEntity) {
         if(state.getValue(ChestBlock.TYPE)!=ChestType.SINGLE) {
            BlockPos adjacent=position.relative(ChestBlock.getConnectedDirection(state));
            BlockEntity other=level.getBlockEntity(adjacent);
            if(!(other instanceof ChestBlockEntity)) throw new IllegalArgumentException("The double chest changed. Hit it again to review.");
            checkAnchor(player,other);anchors.add(other);combined=true;
         }
         container=ChestBlock.getContainer(chest,state,level,position,false);
         if(container==null) throw new IllegalArgumentException("This chest is blocked or cannot be opened.");
         if(combined && container.getContainerSize()!=((Container)entity).getContainerSize()+((Container)anchors.get(1)).getContainerSize()) throw new IllegalArgumentException("The double chest changed. Hit it again to review.");
      } else if(entity instanceof EnderChestBlockEntity) {
         BlockPos above=position.above();
         if(level.getBlockState(above).isRedstoneConductor(level,above)) throw new IllegalArgumentException("This Ender Chest is blocked.");
         // Never change the active/open chest, and never inspect another player's inventory.
         container=player.getEnderChestInventory();
      } else {
         container=(Container)entity;
         if(entity instanceof ShulkerBoxBlockEntity shulker && shulker.getAnimationStatus()==ShulkerBoxBlockEntity.AnimationStatus.CLOSED) {
            var opening=Shulker.getProgressDeltaAabb(1.0F,state.getValue(ShulkerBoxBlock.FACING),0.0F,0.5F,Vec3.atBottomCenterOf(position)).deflate(1.0E-6);
            if(!level.noCollision(opening)) throw new IllegalArgumentException("This shulker box is blocked and cannot open.");
         }
      }
      if(container.getContainerSize()<1 || container.getContainerSize()>ChestSales.MAX_STORAGE_SLOTS) throw new IllegalArgumentException("Supported storage size is 1 through "+ChestSales.MAX_STORAGE_SLOTS+" slots.");
      // Ender Chest access is anchored to the clicked block, independently of a previously opened chest.
      if(!(entity instanceof EnderChestBlockEntity) && !container.stillValid(player)) throw new IllegalArgumentException("This storage is out of reach or no longer accessible.");
      return new Target(container,anchors,combined);
   }

   private static void checkAnchor(ServerPlayer player,BlockEntity entity) {
      if(entity.isRemoved() || entity.getLevel()!=player.level() || !player.level().mayInteract(player,entity.getBlockPos()) || !Container.stillValidBlockEntity(entity,player)) throw new IllegalArgumentException("This storage is protected, out of reach, or changed.");
      if(entity instanceof BaseContainerBlockEntity locked && !locked.canOpen(player)) throw new IllegalArgumentException("This storage is locked.");
      if(entity instanceof Container container && hasUnopenedLoot(container)) throw new IllegalArgumentException("Open or interact with this loot storage normally once before using the Sell Axe.");
   }

   record Target(Container container,List<BlockEntity> anchors,boolean combinedChest) {
      Target {Objects.requireNonNull(container);anchors=List.copyOf(anchors);}
      boolean sameStorage(Target other) {
         return other!=null && anchors.equals(other.anchors) && combinedChest==other.combinedChest
            && (container==other.container || combinedChest);
      }
   }
}
