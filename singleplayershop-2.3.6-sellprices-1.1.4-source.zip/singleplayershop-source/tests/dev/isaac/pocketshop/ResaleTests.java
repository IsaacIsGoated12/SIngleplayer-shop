package dev.isaac.pocketshop;

import java.util.*;
import com.mojang.serialization.JsonOps;
import net.minecraft.core.HolderLookup.Provider;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.component.DataComponents;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.network.chat.Component;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.item.*;
import net.minecraft.world.item.enchantment.*;
import net.minecraft.world.item.component.*;

public final class ResaleTests {
   private static int checks;
   private static void check(boolean value,String label) { checks++;if(!value)throw new AssertionError(label); }
   private static ItemStack enchant(Provider registries,Item item,String enchantment,int level) {
      ItemStack stack=new ItemStack(item);
      var holder=registries.lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(ResourceKey.create(Registries.ENCHANTMENT,Identifier.parse("minecraft:"+enchantment)));
      if(item==Items.ENCHANTED_BOOK) {
         var builder=new ItemEnchantments.Mutable(ItemEnchantments.EMPTY);builder.set(holder,level);stack.set(DataComponents.STORED_ENCHANTMENTS,builder.toImmutable());
      } else stack.enchant(holder,level);
      return stack;
   }
   public static int run(ShopCatalog catalog,Provider registries) throws Exception {
      checks=0;
      var index=SellPriceIndex.create(catalog,registries,registries);
      var remote=PriceCatalogCodec.decode(PriceCatalogCodec.encode(catalog,registries),registries);
      for(var category:ShopCatalog.Category.values()) for(var entry:catalog.entries(category)) {
         ItemStack template=entry.stack();
         check(catalog.sellPrice(PurchaseOrigin.purchasedCopy(template))==0,"every purchased listing blocked "+entry.key());
         check(remote.sellPrice(template)==catalog.sellPrice(template),"every natural listing remotely valued "+entry.key());
      }
      Set<Item> coverage=new HashSet<>();
      for(var category:ShopCatalog.Category.values()) for(var entry:catalog.entries(category)) {
         ItemStack plain=entry.stack();
         if(!plain.isDamageableItem() || plain.has(DataComponents.CUSTOM_NAME) || !plain.getEnchantments().isEmpty() || entry.sellPrice()<=0) continue;
         ItemStack enchanted=enchant(registries,entry.item(),"unbreaking",3);
         long full=catalog.sellPrice(enchanted);
         check(full>entry.sellPrice(),"enchantment adds value to "+entry.key());
         check(full==remote.sellPrice(enchanted),"remote enchanted price "+entry.key());
         enchanted.setDamageValue(enchanted.getMaxDamage()/2);
         long worn=catalog.sellPrice(enchanted);
         check(worn>0 && worn<full,"wear lowers value "+entry.key());
         check(worn==remote.sellPrice(enchanted),"remote worn price "+entry.key());
         coverage.add(entry.item());
      }
      for(Item item:List.of(Items.DIAMOND_HELMET,Items.DIAMOND_CHESTPLATE,Items.DIAMOND_LEGGINGS,Items.DIAMOND_BOOTS,
         Items.NETHERITE_AXE,Items.NETHERITE_PICKAXE,Items.NETHERITE_SHOVEL,Items.NETHERITE_HOE,Items.NETHERITE_SWORD,
         Items.BOW,Items.CROSSBOW,Items.TRIDENT,Items.MACE,Items.FISHING_ROD,Items.SHIELD,Items.ELYTRA,Items.SHEARS,Items.FLINT_AND_STEEL,Items.BRUSH)) check(coverage.contains(item),"required enchanted item coverage "+item);
      int books=0;
      for(var entry:catalog.entries(ShopCatalog.Category.ENCHANTMENTS)) {
         ItemStack stack=entry.stack();
         var enchantments=stack.getOrDefault(DataComponents.STORED_ENCHANTMENTS,ItemEnchantments.EMPTY);
         boolean curse=enchantments.keySet().stream().anyMatch(e->e.unwrapKey().orElseThrow().identifier().getPath().endsWith("_curse"));
         check(catalog.sellPrice(stack)==(curse?0:entry.buyPrice()*40/100),"all enchanted book levels valued "+entry.key());
         check(catalog.sellPrice(stack)==remote.sellPrice(stack),"all enchanted book levels synchronized "+entry.key());
         books++;
      }
      check(books>=120,"full enchanted book catalog covered");
      var sharp=enchant(registries,Items.DIAMOND_SWORD,"sharpness",5);
      long sharpPrice=catalog.sellPrice(sharp);
      var mending=registries.lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(ResourceKey.create(Registries.ENCHANTMENT,Identifier.parse("minecraft:mending")));
      sharp.enchant(mending,1);
      check(catalog.sellPrice(sharp)>sharpPrice,"multiple enchantments add their individual values");
      ItemStack namedGear=sharp.copy();namedGear.set(DataComponents.CUSTOM_NAME,Component.literal("Loot Blade"));
      namedGear.set(DataComponents.LORE,new ItemLore(List.of(Component.literal("A treasure chest reward"))));
      check(catalog.sellPrice(namedGear)==catalog.sellPrice(sharp) && remote.sellPrice(namedGear)==catalog.sellPrice(sharp),"named enchanted gear is valued like the same natural gear");
      var curse=registries.lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(ResourceKey.create(Registries.ENCHANTMENT,Identifier.parse("minecraft:vanishing_curse")));
      long uncursed=catalog.sellPrice(sharp);sharp.enchant(curse,1);
      check(catalog.sellPrice(sharp)<uncursed,"curse reduces gear value");
      var illegal=enchant(registries,Items.DIAMOND_SWORD,"sharpness",6);check(catalog.sellPrice(illegal)==0,"over-level enchantment protected");
      var book=enchant(registries,Items.ENCHANTED_BOOK,"mending",1);check(catalog.sellPrice(book)==64000,"Mending I treasure book value");
      var purchased=PurchaseOrigin.purchasedCopy(sharp);purchased.setDamageValue(10);purchased.set(DataComponents.REPAIR_COST,4);
      check(catalog.sellPrice(purchased)==0 && remote.sellPrice(purchased)==0,"bought enchanted/repaired/worn gear stays unsellable");
      var ops=registries.createSerializationContext(JsonOps.INSTANCE);
      var saved=ItemStack.CODEC.parse(ops,ItemStack.CODEC.encodeStart(ops,purchased).getOrThrow()).getOrThrow();
      check(PurchaseOrigin.isPurchased(saved) && catalog.sellPrice(saved)==0,"purchase origin survives saved item serialization");
      check(SaleContents.plan(purchased,ignored->100000).count()==0,"purchase restriction enforced even with an arbitrary price function");
      var tool=catalog.entries(ShopCatalog.Category.UTILITY).stream().filter(e->e.variant().id().equals("sell_axe")).findFirst().orElseThrow();
      ItemStack axe=tool.stack();
      check(axe.is(Items.NETHERITE_AXE) && axe.getHoverName().getString().equals("Sell Axe") && SellAxe.isSellAxe(axe),"Sell Axe item, name and identity");
      check(tool.buyPrice()==900000 && tool.sellPrice()==0,"Sell Axe progression price");
      for(var entry:SellAxe.ENCHANTMENTS.entrySet()) {
         var holder=registries.lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(ResourceKey.create(Registries.ENCHANTMENT,Identifier.parse(entry.getKey())));
         check(axe.getEnchantments().getLevel(holder)==entry.getValue() && holder.value().getMaxLevel()==entry.getValue(),"Sell Axe max enchantment "+entry.getKey());
      }
      check(axe.getEnchantments().size()==5 && catalog.sellPrice(axe)==0,"Sell Axe has all five compatible maximum enchants and is unsellable");
      var fakeAxe=new ItemStack(Items.IRON_AXE);fakeAxe.set(DataComponents.CUSTOM_NAME,Component.literal("Sell Axe"));
      check(!SellAxe.isSellAxe(fakeAxe),"renamed non-netherite tools never become a Sell Axe");
      var inv=new SimpleContainer(36);var wallet=new Wallets();UUID id=UUID.randomUUID();wallet.credit(id,catalog.startingBalance(),tool.buyPrice());
      check(new ShopTransactions(catalog).buy(inv,36,wallet,id,tool,1).success() && SellAxe.isSellAxe(inv.getItem(0)),"shop buys the real Sell Axe");
      check(!new ShopTransactions(catalog).sell(inv,0,1,wallet,id).success() && SellAxe.isSellAxe(inv.getItem(0)),"cannot sell the bought Sell Axe");
      chest(catalog,registries,book,sharp,axe);
      var lines=new ArrayList<Component>();SellPriceTooltip.append(catalog,PurchaseOrigin.purchasedCopy(book),lines);
      check(lines.stream().anyMatch(e->e.getString().contains("cannot resell")),"tooltip explains bought enchanted items");
      lines.clear();SellPriceTooltip.append(catalog,sharp,lines);
      check(lines.stream().anyMatch(e->e.getString().contains("Enchantments:")),"tooltip exposes enchantment contribution");
      treasure(catalog,registries,remote);
      System.out.println("Enchanted resale coverage: "+coverage.size()+" gear/tool types; "+books+" book variants");
      return checks;
   }

   private static void treasure(ShopCatalog catalog,Provider registries,SellPriceIndex remote) {
      long previous=0;
      for(Item material:List.of(Items.WOODEN_SWORD,Items.STONE_SWORD,Items.GOLDEN_SWORD,Items.IRON_SWORD,Items.DIAMOND_SWORD,Items.NETHERITE_SWORD)) {
         ItemStack sword=enchant(registries,material,"sharpness",5);long value=catalog.sellPrice(sword);
         check(value>previous,"same enchantment has increasing material value "+material);previous=value;
         check(value==remote.sellPrice(sword),"material-aware price synchronized "+material);
      }
      check(catalog.sellPrice(enchant(registries,Items.WOODEN_SWORD,"sharpness",5))<1000,"wooden Sharpness V remains a cheap find");
      check(catalog.sellPrice(enchant(registries,Items.WOODEN_SWORD,"sharpness",1))<catalog.sellPrice(enchant(registries,Items.WOODEN_SWORD,"sharpness",5)),"enchantment level affects wood value");
      var sword=enchant(registries,Items.DIAMOND_SWORD,"unbreaking",3);
      var pick=enchant(registries,Items.DIAMOND_PICKAXE,"unbreaking",3);
      var shovel=enchant(registries,Items.DIAMOND_SHOVEL,"unbreaking",3);
      check(catalog.valuation(pick).enchantments()>catalog.valuation(sword).enchantments() && catalog.valuation(sword).enchantments()>catalog.valuation(shovel).enchantments(),"tool type independently changes enchantment contribution");
      var lookup=registries.lookupOrThrow(Registries.ENCHANTMENT);
      var wings=enchant(registries,Items.ELYTRA,"unbreaking",3);
      wings.enchant(lookup.getOrThrow(ResourceKey.create(Registries.ENCHANTMENT,Identifier.parse("minecraft:mending"))),1);
      check(catalog.sellPrice(new ItemStack(Items.ELYTRA))==120000,"natural elytra is a six-figure treasure");
      check(catalog.sellPrice(wings)==300600 && remote.sellPrice(wings)==300600,"enchanted elytra has a major rarity premium");
      check(catalog.valuation(wings).setBonus()==8600,"two maximum enchantments earn a loadout bonus");
      check(catalog.valuation(wings).rarity().equals("Legendary"),"rarity reflects current payout");
      wings.setDamageValue(wings.getMaxDamage()/2);
      check(catalog.sellPrice(wings)==150300,"wear halves the whole treasure appraisal");
      var detail=catalog.valuation(wings);
      check(detail.base()+detail.enchantments()+detail.setBonus()-detail.curseLoss()-detail.wearLoss()-detail.limitLoss()==detail.total(),"appraisal contributions reconcile exactly");
      for(var category:ShopCatalog.Category.values()) for(var entry:catalog.entries(category)) {
         var value=catalog.valuation(entry.stack());
         check(value.total()<=entry.buyPrice(),"natural default listing below buy cost "+entry.key());
         if(entry.category()==ShopCatalog.Category.ENCHANTED_GEAR && entry.item()==Items.DIAMOND_PICKAXE) check(value.total()>=100000,"premium diamond tools sell for six figures");
      }
      check(catalog.sellPrice(enchant(registries,Items.ENCHANTED_BOOK,"swift_sneak",3))==100000,"rare Swift Sneak III book six-figure value");
      check(catalog.sellPrice(enchant(registries,Items.ENCHANTED_BOOK,"wind_burst",3))==180000,"rare Wind Burst III book premium");
      var inventory=new SimpleContainer(36);inventory.setItem(0,new ItemStack(Items.WHEAT,64));inventory.setItem(5,wings.copy());inventory.setItem(12,PurchaseOrigin.purchasedCopy(new ItemStack(Items.ELYTRA)));
      var before=inventory.getItem(5).copy();var overview=InventoryAppraisal.inspect(inventory,36,catalog);
      check(overview.total()==150556 && overview.count()==65 && overview.keptStacks()==1,"inventory appraisal combines actual payouts and protected stacks");
      check(overview.top().get(0).slot()==5 && overview.top().get(0).total()==150300,"most valuable inventory stacks sorted by real total");
      check(ItemStack.matches(before,inventory.getItem(5)),"inventory appraisal never mutates gear");
      var earning=EarnMenuSupport.earningEntries(catalog,1);
      check(earning.stream().anyMatch(entry->entry.item()==Items.ENCHANTED_BOOK) && earning.stream().anyMatch(entry->entry.category()==ShopCatalog.Category.ENCHANTED_GEAR),"earning guide includes books and enchanted equipment");
      for(int i=1;i<earning.size();i++) check(catalog.sellPrice(earning.get(i-1).stack())>=catalog.sellPrice(earning.get(i).stack()),"earning guide sorts by calculated resale");
      var bookEntry=catalog.entries(ShopCatalog.Category.ENCHANTMENTS).stream().filter(entry->entry.variant().id().equals("mending_1")).findFirst().orElseThrow();
      var books=new SimpleContainer(36);books.setItem(0,bookEntry.stack());books.setItem(1,PurchaseOrigin.purchasedCopy(bookEntry.stack()));
      check(EarnMenuSupport.ownedQuote(catalog,bookEntry,books).total()==64000 && EarnMenuSupport.ownedQuote(catalog,bookEntry,books).count()==1,"earning guide counts only natural books at real price");
      var lines=new ArrayList<Component>();TooltipOptions.compact=false;TooltipOptions.details=true;
      SellPriceTooltip.append(catalog,wings,lines);
      for(String expected:List.of("Base item:","equipment factor 200%","Max-level loadout bonus:","Wear discount:","At full condition:","150,300")) check(lines.stream().anyMatch(line->line.getString().contains(expected)),"rich tooltip includes "+expected);
      check(lines.stream().filter(line->line.getString().startsWith("  ")).count()==2,"tooltip explains every enchantment separately");
      TooltipOptions.details=false;lines.clear();SellPriceTooltip.append(catalog,wings,lines);
      check(lines.stream().noneMatch(line->line.getString().startsWith("  ")),"details setting hides individual enchantment lines");TooltipOptions.details=true;
      var book1=enchant(registries,Items.ENCHANTED_BOOK,"mending",1);var book2=enchant(registries,Items.ENCHANTED_BOOK,"unbreaking",3);
      var expensive=new ItemValuation(List.of(new ItemValuation.Offer(new ItemStack(Items.NETHERITE_CHESTPLATE),1,1),new ItemValuation.Offer(book1,1_000_000_000,0),new ItemValuation.Offer(book2,1_000_000_000,0)));
      var capped=enchant(registries,Items.NETHERITE_CHESTPLATE,"mending",1);capped.enchant(lookup.getOrThrow(ResourceKey.create(Registries.ENCHANTMENT,Identifier.parse("minecraft:unbreaking"))),3);
      check(expensive.quote(capped).total()==1_000_000_000 && expensive.quote(capped).limitLoss()>0,"extreme custom book prices safely cap the combined appraisal");
      check(expensive.quote(capped).base()+expensive.quote(capped).enchantments()+expensive.quote(capped).setBonus()-expensive.quote(capped).limitLoss()==expensive.quote(capped).total(),"price cap receipt reconciles");
   }

   private static void chest(ShopCatalog catalog,Provider registries,ItemStack book,ItemStack gear,ItemStack axe) {
      var chest=new TrackedContainer(54);chest.setItem(0,book.copy());chest.setItem(27,gear.copy());chest.setItem(53,new ItemStack(Items.WHEAT,10));
      var named=new ItemStack(Items.DIAMOND);named.set(DataComponents.CUSTOM_NAME,Component.literal("Keep"));
      chest.setItem(2,named.copy());chest.setItem(3,PurchaseOrigin.purchasedCopy(new ItemStack(Items.DIAMOND)));chest.setItem(4,axe.copy());
      long expected=catalog.sellPrice(book)+catalog.sellPrice(gear)+40;
      var review=ChestSales.review(chest,catalog);
      check(review.count()==12 && review.total()==expected,"double chest includes enchanted items and both halves");
      check(review.keptStacks()==3,"chest preview reports protected stacks");
      check(review.bestTotal()==Math.max(catalog.sellPrice(gear),catalog.sellPrice(book)) && !review.bestName().isEmpty(),"chest preview highlights the most valuable stack");
      var wallet=new Wallets();var id=UUID.randomUUID();
      chest.touched.clear();
      var result=ChestSales.sell(chest,review,catalog,wallet,id);
      check(result.success() && result.total()==expected && wallet.balance(id,0)==catalog.startingBalance()+expected,"chest payout equals preview");
      check(chest.getItem(0).isEmpty() && chest.getItem(27).isEmpty() && chest.getItem(53).isEmpty(),"only sold chest contents removed");
      check(ItemStack.matches(chest.getItem(2),named) && PurchaseOrigin.isPurchased(chest.getItem(3)) && SellAxe.isSellAxe(chest.getItem(4)),"protected chest contents kept");
      check(chest.touched.equals(Set.of(0,27,53)),"protected chest slots are never rewritten");
      check(!ChestSales.sell(chest,review,catalog,wallet,id).success(),"review cannot pay twice");
      chest.setItem(0,new ItemStack(Items.WHEAT,8));review=ChestSales.review(chest,catalog);chest.setItem(0,new ItemStack(Items.WHEAT,7));
      check(!ChestSales.sell(chest,review,catalog,wallet,id).success() && chest.getItem(0).getCount()==7,"hopper/player changes invalidate chest review");
      var capped=new Wallets();var capId=UUID.randomUUID();capped.credit(capId,0,Wallets.MAX_BALANCE);review=ChestSales.review(chest,catalog);
      check(!ChestSales.sell(chest,review,catalog,capped,capId).success() && chest.getItem(0).getCount()==7,"full wallet leaves chest contents intact");
   }
   private static final class TrackedContainer extends SimpleContainer {
      final Set<Integer> touched=new HashSet<>();
      TrackedContainer(int size) { super(size); }
      @Override public void setItem(int slot,ItemStack stack) { touched.add(slot);super.setItem(slot,stack); }
   }
}
