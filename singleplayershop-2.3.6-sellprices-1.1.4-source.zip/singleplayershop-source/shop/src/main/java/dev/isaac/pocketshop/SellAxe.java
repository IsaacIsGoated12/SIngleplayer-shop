package dev.isaac.pocketshop;

import java.util.*;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.component.ItemLore;
import net.minecraft.world.level.Level;

public final class SellAxe {
   public static final Map<String,Integer> ENCHANTMENTS=Map.of("minecraft:efficiency",5,"minecraft:unbreaking",3,"minecraft:mending",1,"minecraft:sharpness",5,"minecraft:fortune",3);
   private static final String KEY="pocketshop:sell_axe";
   private static final Map<UUID,Pending> REVIEWS=new HashMap<>();
   private SellAxe() {}

   public static void decorate(ItemStack stack) {
      if(!stack.is(Items.NETHERITE_AXE)) throw new IllegalArgumentException("Sell Axe must be a netherite axe");
      PurchaseOrigin.mark(stack);
      CustomData.update(DataComponents.CUSTOM_DATA,stack,tag->tag.putBoolean(KEY,true));
      stack.set(DataComponents.CUSTOM_NAME,Component.literal("Sell Axe").withStyle(ChatFormatting.GOLD).withStyle(style->style.withItalic(false)));
      stack.set(DataComponents.LORE,new ItemLore(List.of(
         Component.literal("Hit storage to preview its contents' sell value.").withStyle(ChatFormatting.GRAY),
         Component.literal("Sneak-hit within 15 seconds to confirm.").withStyle(ChatFormatting.GREEN),
         Component.literal("Storage block and protected contents are kept.").withStyle(ChatFormatting.GRAY),
         Component.literal("Shop purchases cannot be resold.").withStyle(ChatFormatting.DARK_GRAY))));
   }

   public static boolean isSellAxe(ItemStack stack) {
      if(stack==null || !stack.is(Items.NETHERITE_AXE)) return false;
      CustomData data=stack.get(DataComponents.CUSTOM_DATA);
      if(data==null || !data.copyTag().getBooleanOr(KEY,false) || !stack.getHoverName().getString().equals("Sell Axe") || stack.getEnchantments().size()!=ENCHANTMENTS.size()) return false;
      for(var entry:stack.getEnchantments().entrySet()) {
         String id=entry.getKey().unwrapKey().map(key->key.identifier().toString()).orElse("");
         if(!Objects.equals(ENCHANTMENTS.get(id),entry.getIntValue())) return false;
      }
      return true;
   }

   static void register() {
      AttackBlockCallback.EVENT.register((player,level,hand,pos,direction)-> {
         if(!isSellAxe(player.getItemInHand(hand)) || !SellStorage.supports(level.getBlockEntity(pos))) return InteractionResult.PASS;
         if(player instanceof ServerPlayer serverPlayer) interact(serverPlayer,pos);
         return InteractionResult.SUCCESS;
      });
      PlayerBlockBreakEvents.BEFORE.register((level,player,pos,state,entity)->!(isSellAxe(player.getMainHandItem()) && SellStorage.supports(entity)));
      ServerPlayConnectionEvents.DISCONNECT.register((handler,server)->REVIEWS.remove(handler.player.getUUID()));
      ServerLifecycleEvents.SERVER_STOPPED.register(server->REVIEWS.clear());
   }

   private static void interact(ServerPlayer player,BlockPos pos) {
      Level level=player.level();
      Pending old=REVIEWS.remove(player.getUUID());
      if(!player.isAlive() || player.isSpectator() || !player.getAbilities().mayBuild || !level.mayInteract(player,pos)) return;
      SellStorage.Target target;
      try {target=SellStorage.resolve(player,pos);}
      catch(IllegalArgumentException denied) {message(player,denied.getMessage(),false);return;}
      catch(RuntimeException exception) {
         org.slf4j.LoggerFactory.getLogger("pocketshop").error("Could not access Sell Axe storage",exception);
         message(player,"This storage could not be accessed safely. Nothing was sold.",false);return;
      }
      String dimension=level.dimension().toString();
      long now=System.nanoTime();
      if(player.isShiftKeyDown() && (old==null || !old.dimension.equals(dimension) || !old.position.equals(pos) || !old.target.sameStorage(target) || now-old.created>15_000_000_000L)) {
         message(player,"Hit this storage without sneaking to preview it first, then sneak-hit to confirm.",false);return;
      }
      if(player.isShiftKeyDown()) {
         // Resolve access again on confirmation; retain the original double-chest wrapper for its snapshot.
         try {
            ShopTransactions.Result result=ChestSales.sell(old.target.container(),old.review,PocketShop.catalog(),PocketShop.wallets(player),player.getUUID());
            PocketShop.feedback(player,result);
            player.inventoryMenu.broadcastChanges();
         } catch(RuntimeException exception) {
            org.slf4j.LoggerFactory.getLogger("pocketshop").error("Sell Axe storage transaction failed",exception);
            message(player,"Storage sale failed. Check the server log before trying again.",false);
         }
         return;
      }
      try {
         ChestSales.Review review=ChestSales.review(target.container(),PocketShop.catalog());
         if(review.count()==0) { message(player,"No eligible items. Shop purchases and protected contents are kept.",false);return; }
         REVIEWS.put(player.getUUID(),new Pending(dimension,pos.immutable(),target,review,now));
         message(player,"Storage preview: "+review.count()+" items for "+ShopTransactions.money(review.total())+"; "+review.keptStacks()+" stacks kept. Sneak-hit within 15 seconds to sell. Storage block kept.",true);
         message(player,"Most valuable stack: "+review.bestName()+" - "+ShopTransactions.money(review.bestTotal())+". Review carefully before confirming.",true);
      } catch(ArithmeticException | IllegalArgumentException invalid) { message(player,"Could not safely value this storage. Everything was kept.",false); }
      catch(RuntimeException exception) {
         org.slf4j.LoggerFactory.getLogger("pocketshop").error("Could not preview Sell Axe storage",exception);
         message(player,"This storage could not be inspected safely. Nothing was sold.",false);
      }
   }

   private static void message(ServerPlayer player,String text,boolean success) { player.sendSystemMessage(Component.literal("[Sell Axe] "+text).withStyle(success?ChatFormatting.GOLD:ChatFormatting.RED)); }
   private record Pending(String dimension,BlockPos position,SellStorage.Target target,ChestSales.Review review,long created) {}
}
