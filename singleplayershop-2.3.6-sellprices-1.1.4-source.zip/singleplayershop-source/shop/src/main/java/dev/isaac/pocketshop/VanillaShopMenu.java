package dev.isaac.pocketshop;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import net.minecraft.ChatFormatting;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

public final class VanillaShopMenu extends AbstractContainerMenu {
   private static final int TOP_SIZE = 54;
   private static final int[] ITEM_SLOTS = new int[]{
      10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34, 37, 38, 39, 40, 41, 42, 43
   };
   private static final int[] HOME_SLOTS = new int[]{10, 11, 13, 15, 16, 19, 20, 22, 24, 25, 28, 29, 31, 33, 34, 39, 40, 41};
   private static final ShopCatalog.Category[] HOME_CATEGORIES = new ShopCatalog.Category[]{
      ShopCatalog.Category.BUILDING,
      ShopCatalog.Category.WOOD_NATURE,
      ShopCatalog.Category.DECORATION,
      ShopCatalog.Category.NETHER_END,
      ShopCatalog.Category.RESOURCES,
      ShopCatalog.Category.TOOLS,
      ShopCatalog.Category.ARMOR,
      ShopCatalog.Category.COMBAT,
      ShopCatalog.Category.ENCHANTMENTS,
      ShopCatalog.Category.ENCHANTED_GEAR,
      ShopCatalog.Category.FARMING,
      ShopCatalog.Category.FOOD,
      ShopCatalog.Category.MOB_DROPS,
      ShopCatalog.Category.BREWING,
      ShopCatalog.Category.POTIONS,
      ShopCatalog.Category.REDSTONE,
      ShopCatalog.Category.UTILITY,
      ShopCatalog.Category.TRANSPORT
   };
   private static final int[] QUANTITIES = new int[]{1, 8, 16, 32, 64};
   private final ServerPlayer owner;
   private final Inventory inventory;
   private final SimpleContainer display = new SimpleContainer(54);
   private final Set<Integer> selected = new HashSet<>();
   private List<ItemStack> viewSnapshot = List.of();
   private List<ItemStack> reviewedInventory = List.of();
   private List<Integer> reviewedSelection = List.of();
   private ShopTransactions.Quote reviewedQuote = new ShopTransactions.Quote(0, 0L);
   private VanillaShopMenu.Page current;
   private ShopCatalog.Category category;
   private ShopCatalog.Entry purchase;
   private String query;
   private int listPage;
   private int sort;
   private int quantity = 1;
   private String notice = "";
   private boolean noticeSuccess = true;
   private int questFilter;
   private int questTier;
   private QuestBoard.Quest quest;
   private List<ItemStack> questSnapshot = List.of();

   public VanillaShopMenu(int id, Inventory inventory, ServerPlayer owner, String initialPage, String query) {
      super(MenuType.GENERIC_9x6, id);
      this.inventory = inventory;
      this.owner = owner;
      this.query = query == null ? "" : query.trim();
      this.current = initialPage != null && initialPage.startsWith("sell")
         ? VanillaShopMenu.Page.SELL
         : (this.query.isEmpty() ? VanillaShopMenu.Page.HOME : VanillaShopMenu.Page.CATEGORY);
      if ("earn".equals(initialPage)) {
         this.current = VanillaShopMenu.Page.EARN;
      }

      if ("prices".equals(initialPage)) {
         this.current = VanillaShopMenu.Page.PRICES;
      }

      if ("enchants".equals(initialPage) || "potions".equals(initialPage)) {
         this.category = "enchants".equals(initialPage) ? ShopCatalog.Category.ENCHANTMENTS : ShopCatalog.Category.POTIONS;
         this.current = VanillaShopMenu.Page.CATEGORY;
      }

      for (int row = 0; row < 6; row++) {
         for (int column = 0; column < 9; column++) {
            this.addSlot(new Slot(this.display, row * 9 + column, 8 + column * 18, 18 + row * 18) {
               public boolean mayPlace(ItemStack stack) {
                  return false;
               }

               public boolean mayPickup(Player player) {
                  return false;
               }
            });
         }
      }

      this.addStandardInventorySlots(inventory, 8, 139);
      this.viewSnapshot = InventorySales.snapshot(inventory);
      if ("sell_all".equals(initialPage)) {
         this.selectAll();
      }

      this.refresh();
   }

   public String page() {
      return this.current.name().toLowerCase(Locale.ROOT);
   }

   public void refresh() {
      List<ItemStack> next = InventorySales.snapshot(this.inventory);
      boolean changedSelection = this.selected
         .removeIf(
            slot -> slot >= this.viewSnapshot.size() || !ItemStack.matches(this.viewSnapshot.get(slot), next.get(slot)) || !this.sellable(next.get(slot))
         );
      if (changedSelection) {
         this.notice("Your inventory changed. Review your selection again.", false);
         if (this.current == VanillaShopMenu.Page.REVIEW) {
            this.current = VanillaShopMenu.Page.SELL;
         }
      }

      this.viewSnapshot = next;
      this.display.clearContent();
      if (this.current == VanillaShopMenu.Page.SELL) {
         this.drawSell();
      } else {
         this.drawBorder(this.current == VanillaShopMenu.Page.REVIEW);
         switch (this.current) {
            case HOME:
               this.drawHome();
               break;
            case CATEGORY:
               this.drawCategory();
               break;
            case BUY:
               this.drawBuy();
               break;
            case SELL:
            default:
               throw new IllegalStateException("Unknown native shop page");
            case REVIEW:
               this.drawReview();
               break;
            case EARN:
               this.drawEarn();
               break;
            case PRICES:
               this.drawPrices();
               break;
            case QUEST:
               this.drawQuest();
         }
      }

      this.put(
         49,
         MenuIcons.icon(
            Items.GOLD_INGOT,
            "Balance: " + money(PocketShop.balance(this.owner)),
            ChatFormatting.GOLD,
            "Your balance is saved in this world.",
            "Earn money with /earn and /sell."
         )
      );
      this.put(53, MenuIcons.icon(MenuIcons.vanillaItem("red_dye"), "Close shop", ChatFormatting.RED, "Return to your game."));
      this.broadcastFullState();
   }

   private void drawBorder(boolean selling) {
      for (int slot = 0; slot < 54; slot++) {
         int row = slot / 9;
         int column = slot % 9;
         if (row == 0 || row == 5 || column == 0 || column == 8) {
            this.put(slot, MenuIcons.border());
         }
      }

      this.put(0, MenuIcons.accent(selling));
      this.put(8, MenuIcons.accent(selling));
   }

   private void drawHome() {
      int totalItems = Arrays.stream(ShopCatalog.Category.values()).mapToInt(groupx -> PocketShop.catalog().entries(groupx).size()).sum();
      this.header(
         Items.EMERALD, "Singleplayer Shop 2.3.6", totalItems + " offers across " + HOME_CATEGORIES.length + " categories.", "Choose a category to browse."
      );

      for (int index = 0; index < HOME_SLOTS.length; index++) {
         ShopCatalog.Category group = HOME_CATEGORIES[index];
         this.put(
            HOME_SLOTS[index],
            MenuIcons.icon(
               group.icon(), group.title(), ChatFormatting.AQUA, PocketShop.catalog().entries(group).size() + " items available", "Click to browse prices."
            )
         );
      }

      this.put(
         51,
         MenuIcons.icon(
            Items.EMERALD_BLOCK, "Sell your items", ChatFormatting.GREEN, "Sell loose items or shulker contents.", "Review the total before selling."
         )
      );
      this.put(48, this.earnButton());
      this.put(45, this.help());
      this.put(47, MenuIcons.icon(Items.COMPASS, "Search the shop", ChatFormatting.AQUA, "Use /shop search <item name>", "Example: /shop search diamond"));
   }

   private void drawCategory() {
      List<ShopCatalog.Entry> entries = this.listedEntries();
      int pages = Math.max(1, (entries.size() + ITEM_SLOTS.length - 1) / ITEM_SLOTS.length);
      this.listPage = Math.max(0, Math.min(this.listPage, pages - 1));
      this.header(
         this.category == null ? Items.COMPASS : this.category.icon(),
         this.query.isEmpty() ? (this.category == null ? "All items" : this.category.title()) : "Search: " + this.query,
         entries.size() + " items | Page " + (this.listPage + 1) + " of " + pages,
         "Left click: choose purchase amount.",
         "Right click: select matching loose items.",
         "Use /sell for items inside shulkers."
      );

      for (int index = 0; index < ITEM_SLOTS.length; index++) {
         int offset = this.listPage * ITEM_SLOTS.length + index;
         if (offset >= entries.size()) {
            break;
         }

         ShopCatalog.Entry entry = entries.get(offset);
         boolean shulker = SaleContents.isShulker(entry.stack());
         long naturalResale=PocketShop.catalog().sellPrice(entry.stack());
         this.put(
            ITEM_SLOTS[index],
            MenuIcons.decorate(
               entry.stack(),
               this.itemName(entry),
               ChatFormatting.WHITE,
               listingLore(entry,shulker,naturalResale)
            )
         );
      }

      if (entries.isEmpty()) {
         this.put(22, MenuIcons.icon(Items.PAPER, "No matching items", ChatFormatting.YELLOW, "Try another name with /shop search <item>."));
      }

      this.put(45, this.homeButton());
      if (this.listPage > 0) {
         this.put(46, MenuIcons.icon(Items.ARROW, "Previous page", ChatFormatting.AQUA));
      }
      this.put(47, MenuIcons.icon(Items.HOPPER, "Sort: " + this.sortName(), ChatFormatting.AQUA, "Click to change sorting.", "Featured / Price / Name"));
      if (this.listPage + 1 < pages) {
         this.put(50, MenuIcons.icon(Items.ARROW, "Next page", ChatFormatting.AQUA));
      }

      this.put(51, MenuIcons.icon(Items.EMERALD, "Sell inventory", ChatFormatting.GREEN));
      this.put(52, this.earnButton());
   }

   private List<Component> listingLore(ShopCatalog.Entry entry,boolean shulker,long resale) {
      List<Component> lore=new ArrayList<>();
      lore.add(MenuIcons.text("Buy each: "+money(entry.buyPrice()),ChatFormatting.GRAY));
      lore.add(MenuIcons.text(shulker?"Sell contents; box kept":"Natural item sell value: "+(resale>0?money(resale):"Not accepted"),ChatFormatting.GRAY));
      if(resale>0 && (entry.stack().isDamageableItem() || entry.category()==ShopCatalog.Category.ENCHANTMENTS)) lore.addAll(ValuationDetails.lines(entry.stack(),PocketShop.catalog().valuation(entry.stack()),false));
      lore.add(MenuIcons.text("Left click to buy | Right click to select a sale",ChatFormatting.GRAY));
      lore.add(MenuIcons.text("Shop purchases cannot be resold.",ChatFormatting.DARK_GRAY));
      return lore;
   }

   private void drawPrices() {
      List<ShopCatalog.Entry> entries = EarnMenuSupport.earningEntries(PocketShop.catalog(), this.sort);
      int pages = Math.max(1, (entries.size() + ITEM_SLOTS.length - 1) / ITEM_SLOTS.length);
      this.listPage = Math.max(0, Math.min(this.listPage, pages - 1));
      this.header(
         Items.WHEAT, "Sell prices", "Gather, farm, mine, then sell.", "Hover for prices and gathering tips.", "Page " + (this.listPage + 1) + " of " + pages
      );

      for (int index = 0; index < ITEM_SLOTS.length; index++) {
         int offset = this.listPage * ITEM_SLOTS.length + index;
         if (offset >= entries.size()) {
            break;
         }

         this.put(ITEM_SLOTS[index], EarnMenuSupport.icon(PocketShop.catalog(),entries.get(offset), this.inventory));
      }

      this.put(45, this.homeButton());
      if (this.listPage > 0) {
         this.put(46, MenuIcons.icon(Items.ARROW, "Previous page", ChatFormatting.AQUA));
      }

      this.put(
         47,
         MenuIcons.icon(
            Items.HOPPER,
            "Sort: " + (this.sort == 1 ? "Highest payout" : (this.sort == 2 ? "Name: A to Z" : "Gathering guide")),
            ChatFormatting.AQUA,
            "Click to change sorting."
         )
      );
      if (this.listPage + 1 < pages) {
         this.put(50, MenuIcons.icon(Items.ARROW, "Next page", ChatFormatting.AQUA));
      }

      this.put(51, MenuIcons.icon(Items.EMERALD_BLOCK, "Sell inventory", ChatFormatting.GREEN, "Select stacks, review, and confirm."));
      this.put(48, this.earnButton());
   }

   private QuestProgress questProgress() {
      return QuestProgress.get(this.owner.level().getServer());
   }

   private List<QuestBoard.Quest> listedQuests() {
      QuestProgress progress = this.questProgress();
      String needle = this.query.toLowerCase(Locale.ROOT);
      return QuestBoard.quests(PocketShop.catalog())
         .stream()
         .filter(candidate -> this.questTier == 0 || candidate.tier() == this.questTier)
         .filter(
            candidate -> needle.isEmpty()
               || (candidate.title() + " " + BuiltInRegistries.ITEM.getKey(candidate.item()).getPath().replace('_', ' '))
                  .toLowerCase(Locale.ROOT)
                  .contains(needle)
         )
         .filter(candidate -> {
            return switch (this.questFilter) {
               case 1 -> true;
               case 2 -> progress.completed(this.owner.getUUID(), candidate.id());
               default -> progress.ready(this.owner.getUUID(), candidate);
            };
         })
         .toList();
   }

   private void drawEarn() {
      List<QuestBoard.Quest> entries = this.listedQuests();
      QuestProgress progress = this.questProgress();
      int pages = Math.max(1, (entries.size() + ITEM_SLOTS.length - 1) / ITEM_SLOTS.length);
      this.listPage = Math.max(0, Math.min(this.listPage, pages - 1));
      this.header(
         Items.WRITABLE_BOOK,
         "Earn money",
         "Delivery quests: gather, turn in, earn.",
         progress.completedCount(this.owner.getUUID()) + " / " + QuestBoard.quests(PocketShop.catalog()).size() + " quests completed",
         "Page " + (this.listPage + 1) + " of " + pages,
         this.query.isEmpty() ? "Search: /earn search <item or quest>" : "Search: " + this.query,
         "Six tiers: Apprentice through Legend.",
         "Elite and higher orders need two materials."
      );

      for (int index = 0; index < ITEM_SLOTS.length; index++) {
         int offset = this.listPage * ITEM_SLOTS.length + index;
         if (offset >= entries.size()) {
            break;
         }

         QuestBoard.Quest candidate = entries.get(offset);
         boolean done = progress.completed(this.owner.getUUID(), candidate.id());
         boolean ready = progress.ready(this.owner.getUUID(), candidate);
         List<Component> lore = new ArrayList<>();
         lore.add(MenuIcons.text("Tier " + candidate.tier() + " / 6 - " + candidate.tierName(), ChatFormatting.AQUA));

         for (QuestBoard.Requirement requirement : candidate.requirements()) {
            int owned = QuestBoard.owned(requirement, this.inventory);
            lore.add(
               MenuIcons.text(
                  new ItemStack(requirement.item()).getHoverName().getString() + ": " + owned + " / " + requirement.amount(),
                  owned >= requirement.amount() ? ChatFormatting.GREEN : ChatFormatting.GRAY
               )
            );
         }

         lore.add(MenuIcons.text("Reward: " + money(candidate.reward()), ChatFormatting.GOLD));
         lore.add(
            MenuIcons.text(
               done ? "Completed - reward already claimed." : (ready ? "Click to review this delivery." : "Complete the previous tier first."),
               done ? ChatFormatting.GREEN : (ready ? ChatFormatting.AQUA : ChatFormatting.GRAY)
            )
         );
         lore.add(MenuIcons.text("Only ordinary matching items count.", ChatFormatting.GRAY));
         this.put(
            ITEM_SLOTS[index],
            MenuIcons.selected(
               MenuIcons.decorate(
                  new ItemStack(candidate.item()),
                  candidate.title(),
                  done ? ChatFormatting.GREEN : (ready ? ChatFormatting.WHITE : ChatFormatting.DARK_GRAY),
                  lore
               ),
               done
            )
         );
      }

      if (entries.isEmpty()) {
         this.put(22, MenuIcons.icon(Items.PAPER, "No quests in this view", ChatFormatting.YELLOW, "Change the filter below to see more."));
      }

      this.put(45, this.homeButton());
      if (this.listPage > 0) {
         this.put(46, MenuIcons.icon(Items.ARROW, "Previous page", ChatFormatting.AQUA));
      }
      this.put(47, MenuIcons.icon(Items.HOPPER, "Quests: " + switch (this.questFilter) {
         case 1 -> "All";
         case 2 -> "Completed";
         default -> "Available";
      }, ChatFormatting.AQUA, "Click: Available / All / Completed"));
      this.put(48, MenuIcons.icon(Items.WHEAT, "Selling guide", ChatFormatting.GREEN, "Stack prices and gathering tips."));
      if (this.listPage + 1 < pages) {
         this.put(50, MenuIcons.icon(Items.ARROW, "Next page", ChatFormatting.AQUA));
      }

      this.put(51, MenuIcons.icon(Items.EMERALD_BLOCK, "Sell inventory", ChatFormatting.GREEN, "Sell extra supplies at any time."));

      this.put(52, MenuIcons.icon(Items.COMPARATOR, "Difficulty: " + switch (this.questTier) {
         case 1 -> "Apprentice";
         case 2 -> "Expert";
         case 3 -> "Elite";
         case 4 -> "Master";
         case 5 -> "Champion";
         case 6 -> "Legend";
         default -> "All";
      }, ChatFormatting.AQUA, "Click to filter by difficulty.", "Each chain unlocks one tier at a time."));
   }

   private void drawQuest() {
      if (this.quest == null) {
         this.current = VanillaShopMenu.Page.EARN;
         this.drawEarn();
      } else {
         int owned = QuestBoard.owned(this.quest, this.inventory);
         boolean ready = this.questProgress().ready(this.owner.getUUID(), this.quest) && QuestBoard.canComplete(this.quest, this.inventory);
         this.header(
            Items.WRITABLE_BOOK,
            "Review quest",
            this.quest.title(),
            "Tier " + this.quest.tier() + " / 6 - " + this.quest.tierName(),
            "Deliver every listed material to claim the reward."
         );
         this.put(
            13,
            MenuIcons.decorate(
               new ItemStack(this.quest.item()),
               this.quest.title(),
               ChatFormatting.AQUA,
               List.of(
                  MenuIcons.text("Required: " + this.quest.amount() + " items", ChatFormatting.WHITE),
                  MenuIcons.text("You have: " + owned, ChatFormatting.GRAY),
                  MenuIcons.text("Reward: " + money(this.quest.reward()), ChatFormatting.GOLD),
                  MenuIcons.text("Only the required amount is removed.", ChatFormatting.GRAY)
               )
            )
         );
         if (!this.quest.extras().isEmpty()) {
            QuestBoard.Requirement extra = this.quest.extras().getFirst();
            this.put(
               22,
               MenuIcons.icon(
                  extra.item(),
                  "Additional material",
                  ChatFormatting.AQUA,
                  new ItemStack(extra.item()).getHoverName().getString(),
                  "Required: " + extra.amount(),
                  "You have: " + QuestBoard.owned(extra, this.inventory),
                  "This material is part of the same delivery."
               )
            );
         }

         this.put(
            30,
            MenuIcons.icon(
               Items.EMERALD_BLOCK,
               "Complete quest",
               ready ? ChatFormatting.GREEN : ChatFormatting.RED,
               "Turn in " + this.quest.requirements().stream().mapToInt(QuestBoard.Requirement::amount).sum() + " items total.",
               "Receive " + money(this.quest.reward()) + ".",
               ready ? "Click to confirm this delivery." : "Gather the required items first.",
               "Each quest reward can be claimed once."
            )
         );
         this.put(32, MenuIcons.icon(Items.ARROW, "Back to quests", ChatFormatting.AQUA, "Keep your items and return."));
         this.put(45, this.homeButton());
      }
   }

   private void drawBuy() {
      if (this.purchase == null) {
         this.current = VanillaShopMenu.Page.HOME;
         this.drawHome();
      } else {
         int maximum = PocketShop.transactions().maxBuy(this.inventory, 36, PocketShop.wallets(this.owner), this.owner.getUUID(), this.purchase);
         long cost = this.purchase.buyPrice() * this.quantity;
         this.header(Items.CHEST, "Review your purchase", "Choose an amount, then confirm below.");
         ItemStack preview = MenuIcons.decorate(
            this.purchase.stack(),
            this.itemName(this.purchase),
            ChatFormatting.AQUA,
            List.of(
               MenuIcons.text("Buy each: " + money(this.purchase.buyPrice()), ChatFormatting.GRAY),
               MenuIcons.text("You can buy up to " + maximum + " right now.", ChatFormatting.GRAY)
            )
         );
         preview.setCount(Math.min(this.quantity, preview.getMaxStackSize()));
         this.put(13, preview);

         for (int index = 0; index < QUANTITIES.length; index++) {
            int amount = QUANTITIES[index];
            ItemStack choice = MenuIcons.icon(Items.PAPER, "Buy " + amount, ChatFormatting.WHITE, "Total: " + money(this.purchase.buyPrice() * amount));
            choice.setCount(amount);
            this.put(20 + index, MenuIcons.selected(choice, this.quantity == amount));
         }

         this.put(29, MenuIcons.icon(Items.ARROW, "One fewer", ChatFormatting.AQUA));
         this.put(31, MenuIcons.icon(Items.PAPER, "Quantity: " + this.quantity, ChatFormatting.WHITE, "Total cost: " + money(cost)));
         this.put(33, MenuIcons.icon(Items.ARROW, "One more", ChatFormatting.AQUA));
         this.put(38, MenuIcons.icon(Items.CHEST, "Maximum: " + maximum, ChatFormatting.AQUA, "Uses your balance and free inventory space."));
         this.put(
            42,
            MenuIcons.icon(
               Items.EMERALD_BLOCK,
               "Buy " + this.quantity + " for " + money(cost),
               this.quantity <= maximum ? ChatFormatting.GREEN : ChatFormatting.RED,
               "Click to confirm this purchase.",
               this.quantity <= maximum ? "Delivered to your inventory." : "Need more money or inventory space.",
               "Charged only when you confirm."
            )
         );
         this.put(45, MenuIcons.icon(Items.ARROW, "Back to items", ChatFormatting.AQUA));
      }
   }

   private void drawSell() {
      for (int slot = 36; slot < 54; slot++) {
         this.put(slot, MenuIcons.border());
      }

      for (int slot = 0; slot < 36; slot++) {
         ItemStack stack = this.inventory.getItem(slot);
         if (!stack.isEmpty()) {
            SaleContents.Plan plan = this.salePlan(stack);
            boolean eligible = plan.count() > 0;
            boolean chosen = this.selected.contains(slot);
            boolean shulker = SaleContents.isShulker(stack);
            List<Component> lore = new ArrayList<>();
            if (chosen) {
               lore.add(MenuIcons.text("ÃƒÆ’Ã‚Â¢Ãƒâ€¦Ã¢â‚¬Å“ÃƒÂ¢Ã¢â€šÂ¬Ã…â€œ Selected for sale", ChatFormatting.GREEN));
            }

            if (eligible) {
               lore.add(MenuIcons.text((shulker ? "Sellable contents: " : "Items in this stack: ") + plan.count(), ChatFormatting.GRAY));
               lore.add(MenuIcons.text((shulker ? "Contents value: " : "Stack value: ") + money(plan.total()), ChatFormatting.GREEN));
               if(!shulker && (stack.isDamageableItem() || stack.is(Items.ENCHANTED_BOOK))) lore.addAll(ValuationDetails.lines(stack,PocketShop.catalog().valuation(stack),true));
               lore.add(
                  MenuIcons.text(
                     chosen ? "Click to deselect." : (shulker ? "Click to include sellable contents." : "Click to include this stack."), ChatFormatting.GRAY
                  )
               );
            } else {
               lore.add(MenuIcons.text(shulker ? "No sellable contents." : "This item is protected and will not be sold.", ChatFormatting.GRAY));
            }

            if (shulker) {
               lore.add(MenuIcons.text("Shulker box kept", ChatFormatting.AQUA));
               lore.add(MenuIcons.text("Protected contents stay inside.", ChatFormatting.GRAY));
            }

            ItemStack icon = MenuIcons.decorate(
               stack,
               stack.getHoverName().getString() + (eligible ? "" : (shulker ? " [Kept]" : " [Protected]")),
               chosen ? ChatFormatting.GREEN : (eligible ? ChatFormatting.WHITE : ChatFormatting.GRAY),
               lore
            );
            this.put(slot, MenuIcons.selected(icon, chosen));
         }
      }

      List<Integer> selection = this.selection();
      ShopTransactions.Quote quote = InventorySales.quote(PocketShop.catalog(), this.inventory, selection);
      List<String> guidance = new ArrayList<>(
         List.of(
            "Click a stack above or in your inventory below.",
            "The first row above is your hotbar.",
            "Selected: " + selection.size() + " inventory slots | " + money(quote.total()),
            "Shulkers: sell eligible contents; keep the box.",
            "Your items stay in your inventory until confirmed."
         )
      );
      if (!this.notice.isEmpty()) {
         guidance.add(this.notice);
      }

      this.put(40, MenuIcons.icon(Items.BOOK, "Select items to sell", ChatFormatting.GREEN, guidance.toArray(String[]::new)));
      this.put(45, this.homeButton());
      this.put(46, MenuIcons.icon(MenuIcons.vanillaItem("lime_dye"), "Select all sellable items", ChatFormatting.GREEN));
      this.put(47, MenuIcons.icon(MenuIcons.vanillaItem("gray_dye"), "Clear selection", ChatFormatting.GRAY));
      this.put(
         48,
         MenuIcons.icon(
            Items.EMERALD_BLOCK,
            "Review sale",
            quote.count() > 0 ? ChatFormatting.GREEN : ChatFormatting.GRAY,
            quote.count() + " items selected",
            "You receive: " + money(quote.total()),
            "Click to review before selling."
         )
      );
      this.put(52, this.earnButton());
   }

   private void drawReview() {
      long boxes = this.reviewedSelection.stream().filter(slot -> SaleContents.isShulker(this.reviewedInventory.get(slot))).count();
      this.header(Items.EMERALD, "Review your sale", "Sell eligible items from your selection.", "Shulker boxes and protected contents stay.");
      this.put(
         13,
         MenuIcons.icon(
            Items.PAPER,
            "Sale total: " + money(this.reviewedQuote.total()),
            ChatFormatting.GREEN,
            this.reviewedQuote.count() + " sellable items from " + this.reviewedSelection.size() + " inventory slots",
            boxes + (boxes == 1L ? " shulker box kept" : " shulker boxes kept"),
            "Balance after sale: " + money(PocketShop.balance(this.owner) + this.reviewedQuote.total()),
            "Your items have not been removed."
         )
      );
      this.put(
         30,
         MenuIcons.icon(
            Items.EMERALD_BLOCK,
            "Confirm sale",
            ChatFormatting.GREEN,
            "Sell " + this.reviewedQuote.count() + " items for " + money(this.reviewedQuote.total()),
            "Click to complete this sale."
         )
      );
      this.put(32, MenuIcons.icon(Items.ARROW, "Back to selection", ChatFormatting.AQUA, "Keep your items and adjust the selection."));
      this.put(45, this.homeButton());
   }

   public void clicked(int slotId, int button, ContainerInput input, Player player) {
      if (player == this.owner && this.owner.containerMenu == this && this.stillValid(player)) {
         if (input == ContainerInput.PICKUP && (button == 0 || button == 1)) {
            VanillaShopMenu.Page before = this.current;
            int inventorySlot = before == VanillaShopMenu.Page.SELL ? this.mappedInventorySlot(slotId) : -1;
            ItemStack previouslyShown = inventorySlot >= 0 ? this.viewSnapshot.get(inventorySlot).copy() : ItemStack.EMPTY;
            this.refresh();
            if (this.current == before) {
               if (inventorySlot >= 0 && !ItemStack.matches(previouslyShown, this.inventory.getItem(inventorySlot))) {
                  this.notice("Your inventory changed. Review the refreshed items.", false);
                  this.refresh();
               } else if (slotId == 53) {
                  this.owner.closeContainer();
               } else if (slotId == 49) {
                  this.broadcastFullState();
               } else {
                  if (this.current == VanillaShopMenu.Page.SELL && inventorySlot >= 0) {
                     this.toggle(inventorySlot);
                  } else if (slotId >= 0 && slotId < 54) {
                     switch (this.current) {
                        case HOME:
                           this.clickHome(slotId);
                           break;
                        case CATEGORY:
                           this.clickCategory(slotId, button);
                           break;
                        case BUY:
                           this.clickBuy(slotId);
                           break;
                        case SELL:
                           this.clickSell(slotId);
                           break;
                        case REVIEW:
                           this.clickReview(slotId);
                           break;
                        case EARN:
                           this.clickEarn(slotId);
                           break;
                        case PRICES:
                           this.clickPrices(slotId);
                           break;
                        case QUEST:
                           this.clickQuest(slotId);
                     }
                  }

                  if (this.owner.containerMenu == this) {
                     this.refresh();
                  }
               }
            }
         } else {
            this.owner.inventoryMenu.broadcastFullState();
            this.broadcastFullState();
         }
      }
   }

   private void clickHome(int slot) {
      for (int index = 0; index < HOME_SLOTS.length; index++) {
         if (slot == HOME_SLOTS[index]) {
            this.category = HOME_CATEGORIES[index];
            this.query = "";
            this.listPage = 0;
            this.current = VanillaShopMenu.Page.CATEGORY;
            return;
         }
      }

      if (slot == 51) {
         this.current = VanillaShopMenu.Page.SELL;
         this.selected.clear();
      }

      if (slot == 48) {
         this.openEarn();
      } else {
         if (slot == 45 || slot == 47) {
            this.owner
               .sendSystemMessage(
                  MenuIcons.text(
                     "Shop: browse categories or /shop search <item>. Quests: /earn. Selling guide: /earn prices. Sell: select stacks, review, and confirm.",
                     ChatFormatting.AQUA
                  )
               );
         }
      }
   }

   private void clickCategory(int slot, int button) {
      if (slot == 45) {
         this.goHome();
      } else if (slot == 47) {
         this.sort = (this.sort + 1) % 3;
         this.listPage = 0;
      } else if (slot == 51) {
         this.current = VanillaShopMenu.Page.SELL;
         this.selected.clear();
      } else if (slot == 52) {
         this.openEarn();
      } else {
         List<ShopCatalog.Entry> entries = this.listedEntries();
         int pages = Math.max(1, (entries.size() + ITEM_SLOTS.length - 1) / ITEM_SLOTS.length);
         if (slot == 46 && this.listPage > 0) {
            this.listPage--;
         } else if (slot == 50 && this.listPage + 1 < pages) {
            this.listPage++;
         } else {
            for (int index = 0; index < ITEM_SLOTS.length; index++) {
               int offset = this.listPage * ITEM_SLOTS.length + index;
               if (slot == ITEM_SLOTS[index] && offset < entries.size()) {
                  this.purchase = entries.get(offset);
                  if (button == 1) {
                     if (SaleContents.isShulker(this.purchase.stack())) {
                        this.selected.clear();
                        this.current = VanillaShopMenu.Page.SELL;
                        this.notice("Select a shulker to sell its eligible contents. The box stays.", true);
                        return;
                     }

                     if (PocketShop.catalog().sellPrice(this.purchase.stack()) == 0L) {
                        this.notice("This offer is buy only. Left click to purchase.", false);
                        return;
                     }

                     this.selected.clear();

                     for (int inventorySlot = 0; inventorySlot < 36; inventorySlot++) {
                        if (this.purchase.accepts(this.inventory.getItem(inventorySlot)) && PocketShop.catalog().sellPrice(this.inventory.getItem(inventorySlot)) > 0L) {
                           this.selected.add(inventorySlot);
                        }
                     }

                     this.current = VanillaShopMenu.Page.SELL;
                  } else {
                     this.quantity = 1;
                     this.current = VanillaShopMenu.Page.BUY;
                  }

                  return;
               }
            }
         }
      }
   }

   private void openEarn() {
      this.current = VanillaShopMenu.Page.EARN;
      this.listPage = 0;
      this.sort = 0;
      this.questFilter = 0;
      this.questTier = 0;
      this.query = "";
      this.selected.clear();
   }

   private void clickPrices(int slot) {
      if (slot == 45) {
         this.goHome();
      } else if (slot == 48) {
         this.openEarn();
      } else if (slot == 47) {
         this.sort = (this.sort + 1) % 3;
         this.listPage = 0;
      } else if (slot == 51) {
         this.current = VanillaShopMenu.Page.SELL;
         this.selected.clear();
      } else {
         List<ShopCatalog.Entry> entries = EarnMenuSupport.earningEntries(PocketShop.catalog(), this.sort);
         int pages = Math.max(1, (entries.size() + ITEM_SLOTS.length - 1) / ITEM_SLOTS.length);
         if (slot == 46 && this.listPage > 0) {
            this.listPage--;
         } else if (slot == 50 && this.listPage + 1 < pages) {
            this.listPage++;
         } else {
            for (int index = 0; index < ITEM_SLOTS.length; index++) {
               int offset = this.listPage * ITEM_SLOTS.length + index;
               if (slot == ITEM_SLOTS[index] && offset < entries.size()) {
                  ShopCatalog.Entry entry = entries.get(offset);
                  this.selected.clear();

                  for (int itemSlot = 0; itemSlot < 36; itemSlot++) {
                     if (entry.accepts(this.inventory.getItem(itemSlot))) {
                        this.selected.add(itemSlot);
                     }
                  }

                  this.notice(
                     this.selected.isEmpty()
                        ? "Gather " + entry.displayName() + ", then return to sell."
                        : "Review the selected " + entry.displayName() + " before selling.",
                     !this.selected.isEmpty()
                  );
                  this.current = VanillaShopMenu.Page.SELL;
                  return;
               }
            }
         }
      }
   }

   private void clickEarn(int slot) {
      if (slot == 45) {
         this.goHome();
      } else if (slot == 47) {
         this.questFilter = (this.questFilter + 1) % 3;
         this.listPage = 0;
      } else if (slot == 52) {
         this.questTier = (this.questTier + 1) % 7;
         this.listPage = 0;
      } else if (slot == 48) {
         this.current = VanillaShopMenu.Page.PRICES;
         this.listPage = 0;
         this.sort = 0;
      } else if (slot == 51) {
         this.current = VanillaShopMenu.Page.SELL;
         this.selected.clear();
      } else {
         List<QuestBoard.Quest> entries = this.listedQuests();
         int pages = Math.max(1, (entries.size() + ITEM_SLOTS.length - 1) / ITEM_SLOTS.length);
         if (slot == 46 && this.listPage > 0) {
            this.listPage--;
         } else if (slot == 50 && this.listPage + 1 < pages) {
            this.listPage++;
         } else {
            for (int index = 0; index < ITEM_SLOTS.length; index++) {
               int offset = this.listPage * ITEM_SLOTS.length + index;
               if (slot == ITEM_SLOTS[index] && offset < entries.size()) {
                  QuestBoard.Quest candidate = entries.get(offset);
                  if (!this.questProgress().ready(this.owner.getUUID(), candidate)) {
                     this.notice("This quest is completed or needs its previous tier first.", false);
                     return;
                  }

                  this.quest = candidate;
                  this.questSnapshot = InventorySales.snapshot(this.inventory);
                  this.current = VanillaShopMenu.Page.QUEST;
                  return;
               }
            }
         }
      }
   }

   private void clickQuest(int slot) {
      if (slot == 45) {
         this.goHome();
      } else if (slot == 32) {
         this.current = VanillaShopMenu.Page.EARN;
      } else {
         if (slot == 30) {
            ShopTransactions.Result result = QuestBoard.complete(
               this.quest,
               this.inventory,
               this.questSnapshot,
               this.questProgress(),
               PocketShop.wallets(this.owner),
               this.owner.getUUID(),
               PocketShop.catalog().startingBalance()
            );
            this.notice(result.message(), result.success());
            this.current = VanillaShopMenu.Page.EARN;
            this.quest = null;
            this.tell(result);
         }
      }
   }

   private void clickBuy(int slot) {
      if (slot == 45) {
         this.current = VanillaShopMenu.Page.CATEGORY;
      } else {
         if (slot >= 20 && slot <= 24) {
            this.quantity = QUANTITIES[slot - 20];
         }

         if (slot == 29) {
            this.quantity = Math.max(1, this.quantity - 1);
         }

         if (slot == 33) {
            this.quantity = Math.min(2304, this.quantity + 1);
         }

         if (slot == 38) {
            int maximum = PocketShop.transactions().maxBuy(this.inventory, 36, PocketShop.wallets(this.owner), this.owner.getUUID(), this.purchase);
            if (maximum > 0) {
               this.quantity = maximum;
            } else {
               this.notice("You need more money or inventory space.", false);
            }
         }

         if (slot == 42) {
            ShopTransactions.Result result = PocketShop.transactions()
               .buy(this.inventory, 36, PocketShop.wallets(this.owner), this.owner.getUUID(), this.purchase, this.quantity);
            this.notice(result.message(), result.success());
            this.current = VanillaShopMenu.Page.CATEGORY;
            this.tell(result);
         }
      }
   }

   private void clickSell(int slot) {
      if (slot == 45) {
         this.goHome();
      } else if (slot == 52) {
         this.openEarn();
      } else if (slot == 46) {
         this.selectAll();
      } else if (slot == 47) {
         this.selected.clear();
      } else if (slot == 48) {
         ShopTransactions.Quote quote = InventorySales.quote(PocketShop.catalog(), this.inventory, this.selection());
         if (quote.count() == 0) {
            this.notice("Select at least one sellable stack first.", false);
            return;
         }

         this.reviewedInventory = InventorySales.snapshot(this.inventory);
         this.reviewedSelection = this.selection();
         this.reviewedQuote = quote;
         this.current = VanillaShopMenu.Page.REVIEW;
      }
   }

   private void clickReview(int slot) {
      if (slot == 32) {
         this.current = VanillaShopMenu.Page.SELL;
      } else if (slot == 45) {
         this.goHome();
      } else {
         if (slot == 30) {
            ShopTransactions.Result result = InventorySales.sell(
               PocketShop.catalog(), this.inventory, this.reviewedInventory, this.reviewedSelection, PocketShop.wallets(this.owner), this.owner.getUUID()
            );
            this.notice(result.message(), result.success());
            this.selected.clear();
            this.current = VanillaShopMenu.Page.SELL;
            this.tell(result);
         }
      }
   }

   private void tell(ShopTransactions.Result result) {
      this.owner.sendSystemMessage(MenuIcons.text("[Singleplayer Shop] " + result.message(), result.success() ? ChatFormatting.GREEN : ChatFormatting.RED));
      this.owner.inventoryMenu.broadcastChanges();
   }

   private void toggle(int slot) {
      if (!this.sellable(this.inventory.getItem(slot))) {
         this.notice(
            SaleContents.isShulker(this.inventory.getItem(slot))
               ? "No sellable contents. Your shulker box stays."
               : "That item is protected and cannot be sold.",
            false
         );
      } else {
         if (!this.selected.add(slot)) {
            this.selected.remove(slot);
         }
      }
   }

   private int mappedInventorySlot(int menuSlot) {
      if (menuSlot >= 0 && menuSlot < 36) {
         return menuSlot;
      } else {
         return menuSlot >= 54 && menuSlot < this.slots.size() ? this.getSlot(menuSlot).getContainerSlot() : -1;
      }
   }

   private void selectAll() {
      this.selected.clear();

      for (int slot = 0; slot < 36; slot++) {
         if (this.sellable(this.inventory.getItem(slot))) {
            this.selected.add(slot);
         }
      }
   }

   private boolean sellable(ItemStack stack) {
      return this.salePlan(stack).count() > 0;
   }

   private SaleContents.Plan salePlan(ItemStack stack) {
      return SaleContents.plan(stack, PocketShop.catalog()::sellPrice);
   }

   private List<Integer> selection() {
      return this.selected.stream().sorted().toList();
   }

   private List<ShopCatalog.Entry> listedEntries() {
      List<ShopCatalog.Entry> entries = new ArrayList<>();

      for (ShopCatalog.Category group : ShopCatalog.Category.values()) {
         if (this.category == null || this.category == group) {
            entries.addAll(PocketShop.catalog().entries(group));
         }
      }

      String needle = this.query.toLowerCase(Locale.ROOT);
      entries.removeIf(entry -> !needle.isEmpty() && !entry.searchText().toLowerCase(Locale.ROOT).contains(needle));
      if (this.sort == 1) {
         entries.sort(Comparator.comparingLong(ShopCatalog.Entry::buyPrice).thenComparing(this::itemName));
      } else if (this.sort == 2) {
         entries.sort(Comparator.comparing(this::itemName, String.CASE_INSENSITIVE_ORDER));
      }

      return entries;
   }

   private void goHome() {
      this.current = VanillaShopMenu.Page.HOME;
      this.category = null;
      this.query = "";
      this.listPage = 0;
      this.selected.clear();
   }

   private String sortName() {
      return switch (this.sort) {
         case 1 -> "Price: low first";
         case 2 -> "Name: A to Z";
         default -> "Featured";
      };
   }

   private String itemName(ShopCatalog.Entry entry) {
      return entry.displayName();
   }

   private static String money(long amount) {
      return ShopTransactions.money(amount);
   }

   private void put(int slot, ItemStack icon) {
      this.display.setItem(slot, icon);
   }

   private void notice(String message, boolean success) {
      this.notice = message;
      this.noticeSuccess = success;
   }

   private void header(Item item, String title, String... lines) {
      List<Component> lore = new ArrayList<>();

      for (String line : lines) {
         lore.add(MenuIcons.text(line, ChatFormatting.GRAY));
      }

      if (!this.notice.isEmpty()) {
         lore.add(MenuIcons.text(this.notice, this.noticeSuccess ? ChatFormatting.GREEN : ChatFormatting.RED));
      }

      this.put(4, MenuIcons.decorate(new ItemStack(item), title, ChatFormatting.AQUA, lore));
   }

   private ItemStack help() {
      return MenuIcons.icon(
         Items.BOOK,
         "How the shop works",
         ChatFormatting.AQUA,
         "Choose a category, then an item.",
         "Select the amount and confirm your purchase.",
         "Review selected items before selling.",
         "Search with /shop search <item>."
      );
   }

   private ItemStack earnButton() {
      return MenuIcons.icon(
         Items.WHEAT,
         "Earn money",
         ChatFormatting.GREEN,
         "Delivery quests with money rewards.",
         "Selling prices and gathering tips.",
         "Also available with /earn."
      );
   }

   private ItemStack homeButton() {
      return MenuIcons.icon(Items.CHEST, "Back to shop", ChatFormatting.AQUA);
   }

   public ItemStack quickMoveStack(Player player, int slot) {
      return ItemStack.EMPTY;
   }

   public boolean canDragTo(Slot slot) {
      return false;
   }

   public boolean canTakeItemForPickAll(ItemStack stack, Slot slot) {
      return false;
   }

   public boolean stillValid(Player player) {
      return player == this.owner && this.owner.isAlive() && !this.owner.isSpectator() && !this.owner.hasDisconnected();
   }

   private enum Page {
      HOME,
      CATEGORY,
      BUY,
      SELL,
      REVIEW,
      EARN,
      PRICES,
      QUEST;
   }
}
