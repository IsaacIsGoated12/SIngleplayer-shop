package dev.isaac.pocketshop;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import net.minecraft.ChatFormatting;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.Container;
import net.minecraft.world.item.ItemStack;

public final class EarnMenuSupport {
   private static final List<String> FEATURED = List.of(
      "wheat",
      "carrot",
      "potato",
      "sugar_cane",
      "pumpkin",
      "melon",
      "oak_log",
      "cobblestone",
      "coal",
      "raw_iron",
      "iron_ingot",
      "diamond",
      "rotten_flesh",
      "bone",
      "gunpowder",
      "string",
      "spider_eye",
      "bamboo",
      "cactus",
      "kelp",
      "beetroot",
      "sweet_berries",
      "honeycomb",
      "leather",
      "slime_ball",
      "ender_pearl",
      "blaze_rod",
      "nether_wart"
   );

   private EarnMenuSupport() {
   }

   public static List<ShopCatalog.Entry> earningEntries(ShopCatalog catalog, int sort) {
      Objects.requireNonNull(catalog, "catalog");
      List<ShopCatalog.Entry> entries = new ArrayList<>();

      for (ShopCatalog.Category category : ShopCatalog.Category.values()) {
         for (ShopCatalog.Entry entry : catalog.entries(category)) {
            if (catalog.sellPrice(entry.stack()) > 0L && !SaleContents.isShulker(entry.stack())) {
               entries.add(entry);
            }
         }
      }

      Comparator<ShopCatalog.Entry> alphabetical = Comparator.comparing(entryx -> entryx.stack().getHoverName().getString(), String.CASE_INSENSITIVE_ORDER);

      Comparator<ShopCatalog.Entry> order = switch (sort) {
         case 1 -> Comparator.<ShopCatalog.Entry>comparingLong(entry -> catalog.sellPrice(entry.stack())).reversed().thenComparing(alphabetical);
         case 2 -> alphabetical;
         default -> Comparator.comparingInt(EarnMenuSupport::featuredRank)
            .thenComparingInt(entryx -> categoryRank(entryx.category()))
            .thenComparing(alphabetical);
      };
      entries.sort(order);
      return List.copyOf(entries);
   }

   public static ShopTransactions.Quote ownedQuote(ShopCatalog catalog,ShopCatalog.Entry entry, Container inventory) {
      Objects.requireNonNull(entry, "entry");
      Objects.requireNonNull(inventory, "inventory");
      if (catalog.sellPrice(entry.stack()) > 0L && !SaleContents.isShulker(entry.stack())) {
         int count = 0;long total=0;

         for (int slot = 0; slot < Math.min(36, inventory.getContainerSize()); slot++) {
            ItemStack stack = inventory.getItem(slot);
            if (entry.accepts(stack) && !PurchaseOrigin.isPurchased(stack)) {
               count = Math.addExact(count, stack.getCount());
               total=Math.addExact(total,Math.multiplyExact(catalog.sellPrice(stack),stack.getCount()));
            }
         }

         return new ShopTransactions.Quote(count,total);
      } else {
         return new ShopTransactions.Quote(0, 0L);
      }
   }

   public static ItemStack icon(ShopCatalog catalog,ShopCatalog.Entry entry, Container inventory) {
      ItemStack original = entry.stack();
      int stackSize = original.getMaxStackSize();
      ShopTransactions.Quote owned = ownedQuote(catalog,entry, inventory);
      long resale=catalog.sellPrice(original);
      List<Component> lore = new ArrayList<>();
      lore.add(MenuIcons.text("Natural sell each: " + money(resale), ChatFormatting.GREEN));
      if (stackSize > 1) {
         lore.add(MenuIcons.text("Stack of " + stackSize + ": " + money(resale * stackSize), ChatFormatting.GREEN));
      }

      lore.add(MenuIcons.text("Ready to sell: " + owned.count() + " items", ChatFormatting.WHITE));
      lore.add(MenuIcons.text("Counts matching items outside shulkers.", ChatFormatting.GRAY));
      lore.add(MenuIcons.text("Your items are worth: " + money(owned.total()), ChatFormatting.GOLD));
      if(original.isDamageableItem() || original.is(net.minecraft.world.item.Items.ENCHANTED_BOOK)) lore.addAll(ValuationDetails.lines(original,catalog.valuation(original),false));
      lore.add(MenuIcons.text("Worn or differently enchanted items: /worth top",ChatFormatting.GRAY));
      lore.add(MenuIcons.text("Shop purchases cannot be resold.",ChatFormatting.DARK_GRAY));
      lore.add(Component.empty());
      lore.add(MenuIcons.text(gatheringHint(entry), ChatFormatting.GRAY));
      lore.add(MenuIcons.text("Click to select matching loose stacks.", ChatFormatting.AQUA));
      lore.add(MenuIcons.text("Use /sell to select shulker contents.", ChatFormatting.GRAY));
      lore.add(MenuIcons.text("Then review and confirm the sale.", ChatFormatting.GRAY));
      return MenuIcons.decorate(original, original.getHoverName().getString(), ChatFormatting.WHITE, lore);
   }

   private static int featuredRank(ShopCatalog.Entry entry) {
      int index = FEATURED.indexOf(path(entry));
      return index >= 0 ? index : FEATURED.size();
   }

   private static int categoryRank(ShopCatalog.Category category) {
      return switch (category) {
         case FARMING -> 0;
         case WOOD_NATURE -> 1;
         case MOB_DROPS -> 2;
         case RESOURCES -> 3;
         case BUILDING -> 4;
         default -> 5;
      };
   }

   private static String gatheringHint(ShopCatalog.Entry entry) {
      return switch (path(entry)) {
         case "elytra" -> "Search End ships; keep a spare pair for yourself.";
         case "enchanted_book" -> "Explore loot chests, fish, or enchant books; rare enchantments are valuable.";
         case "netherite_ingot", "netherite_scrap", "ancient_debris" -> "Explore and mine the Nether for ancient debris.";
         case "mace", "heavy_core" -> "Explore trial chambers and ominous vaults.";
         case "trident" -> "Hunt drowned carrying tridents.";
         case "wheat", "carrot", "potato", "beetroot" -> "Harvest crops; keep some to replant.";
         case "sugar_cane" -> "Grow beside water; leave the bottom block.";
         case "pumpkin", "melon" -> "Grow stems and harvest the fruit blocks.";
         case "oak_log" -> "Harvest trees and replant saplings.";
         case "cobblestone" -> "Sell spare blocks from mining.";
         case "coal", "raw_iron", "diamond" -> "Mine ore and bring back the drops.";
         case "iron_ingot" -> "Smelt raw iron from your mining trips.";
         case "rotten_flesh" -> "Collect drops from zombies.";
         case "bone" -> "Collect drops from skeletons.";
         case "gunpowder" -> "Collect drops from creepers.";
         case "string", "spider_eye" -> "Collect drops from spiders.";
         case "bamboo", "cactus", "kelp" -> "Harvest the growth; keep a base to regrow.";
         case "sweet_berries" -> "Harvest ripe berry bushes.";
         case "honeycomb" -> "Shear a full beehive with smoke below.";
         case "leather" -> "Raise cows and sell spare leather.";
         case "slime_ball" -> "Collect drops from slimes.";
         case "ender_pearl" -> "Collect drops from endermen.";
         case "blaze_rod" -> "Collect blaze drops in Nether fortresses.";
         case "nether_wart" -> "Grow on soul sand; keep some to replant.";
         default -> "Sell spare, unmodified items of this type.";
      };
   }

   private static String path(ShopCatalog.Entry entry) {
      return BuiltInRegistries.ITEM.getKey(entry.item()).getPath();
   }

   private static String money(long amount) {
      return ShopTransactions.money(amount);
   }
}
