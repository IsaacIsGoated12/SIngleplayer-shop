package dev.isaac.pocketshop;

import java.util.Arrays;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.ItemLore;

public final class MenuIcons {
   private MenuIcons() {
   }

   public static Component text(String value, ChatFormatting color) {
      return Component.literal(value).withStyle(color).withStyle(style -> style.withItalic(false));
   }

   public static ItemStack icon(Item item, String title, ChatFormatting color, String... lines) {
      return decorate(new ItemStack(item), title, color, Arrays.stream(lines).map(line -> text(line, ChatFormatting.GRAY)).toList());
   }

   public static ItemStack decorate(ItemStack original, String title, ChatFormatting color, List<Component> lore) {
      ItemStack icon = original.copy();
      icon.set(DataComponents.CUSTOM_NAME, text(title, color));
      icon.set(DataComponents.LORE, new ItemLore(lore));
      return icon;
   }

   public static ItemStack selected(ItemStack icon, boolean selected) {
      icon.set(DataComponents.ENCHANTMENT_GLINT_OVERRIDE, selected);
      return icon;
   }

   public static ItemStack border() {
      return icon(vanillaItem("black_stained_glass_pane"), " ", ChatFormatting.DARK_GRAY);
   }

   public static ItemStack accent(boolean selling) {
      return icon(vanillaItem(selling ? "lime_stained_glass_pane" : "cyan_stained_glass_pane"), " ", ChatFormatting.DARK_GRAY);
   }

   static Item vanillaItem(String name) {
      return (Item)BuiltInRegistries.ITEM.getValue(Identifier.withDefaultNamespace(name));
   }
}
