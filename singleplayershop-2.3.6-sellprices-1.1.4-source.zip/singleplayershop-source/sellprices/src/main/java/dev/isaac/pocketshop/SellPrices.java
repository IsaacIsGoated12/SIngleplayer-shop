package dev.isaac.pocketshop;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;

public final class SellPrices implements ModInitializer {
   public void onInitialize() {
      PayloadTypeRegistry.clientboundPlay().register(SellPricePayload.TYPE, SellPricePayload.CODEC);
      ShopPriceState.register();
   }
}
