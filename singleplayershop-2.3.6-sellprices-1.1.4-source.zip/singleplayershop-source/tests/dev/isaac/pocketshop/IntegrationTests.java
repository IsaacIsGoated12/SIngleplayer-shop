package dev.isaac.pocketshop;

import java.nio.file.*;
import java.util.*;
import net.minecraft.SharedConstants;
import net.minecraft.server.Bootstrap;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.*;
import net.minecraft.world.*;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.NonNullList;
import net.minecraft.core.HolderLookup.Provider;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.component.ItemContainerContents;
import com.google.gson.*;
import com.mojang.serialization.JsonOps;

public final class IntegrationTests {
   private static int checks;
   private static final Gson JSON = new GsonBuilder().setPrettyPrinting().create();
   private static void check(boolean condition, String label) { checks++; if (!condition) throw new AssertionError(label); }
   private static void rejects(Throwing action, String label) throws Exception {
      try { action.run(); } catch (IllegalArgumentException | java.io.IOException expected) { checks++; return; }
      throw new AssertionError("Expected rejection: " + label);
   }
   private interface Throwing { void run() throws Exception; }
   private static ShopCatalog.Entry entry(ShopCatalog catalog, Item item) { return catalog.find(new ItemStack(item)).orElseThrow(); }
   private static JsonObject json(String resource) throws Exception {
      try (var input=ShopCatalog.class.getResourceAsStream("/"+resource)) { return JSON.fromJson(new String(input.readAllBytes(),java.nio.charset.StandardCharsets.UTF_8),JsonObject.class); }
   }
   private static JsonObject row(JsonObject root, String id) { for(var e:root.getAsJsonArray("items")) if(e.getAsJsonObject().get("id").getAsString().equals("minecraft:"+id) && !e.getAsJsonObject().has("variant")) return e.getAsJsonObject(); throw new AssertionError(id); }

   public static void main(String[] args) throws Exception {
      SharedConstants.tryDetectVersion();
      Bootstrap.bootStrap();
      var registries = MinecraftCompat.vanillaLookup();
      // 26.3 binds item defaults after world registries are available.
      try {
         var initializers=BuiltInRegistries.class.getField("DATA_COMPONENT_INITIALIZERS").get(null);
         var pending=(List<?>)initializers.getClass().getMethod("build",Provider.class).invoke(initializers,registries);
         for(var value:pending) {
            var api=Class.forName("net.minecraft.core.component.DataComponentInitializers$PendingComponents");
            api.getMethod("apply").invoke(value);
         }
      } catch (NoSuchFieldException olderVersion) { /* Earlier releases bind defaults during bootstrap. */ }
      Path scratch = Path.of(args[0]);
      Files.createDirectories(scratch);
      Files.writeString(scratch.resolve("registered-items.txt"), String.join("\n", BuiltInRegistries.ITEM.keySet().stream().map(Object::toString).sorted().toList()));
      scratch=Files.createTempDirectory(scratch,"suite-");
      ShopCatalog catalog = ShopCatalog.load(scratch.resolve("fresh.json"), registries);
      int count = Arrays.stream(ShopCatalog.Category.values()).mapToInt(c -> catalog.entries(c).size()).sum();
      System.out.println("Loaded catalog: " + count + " entries; quests: " + QuestBoard.quests(catalog).size());
      long expected=json("default-shop.json").getAsJsonArray("items").asList().stream().filter(e -> BuiltInRegistries.ITEM.containsKey(net.minecraft.resources.Identifier.parse(e.getAsJsonObject().get("id").getAsString()))).count();
      check(count == expected,"all listings available on this Minecraft version retained");
      check(entry(catalog,Items.WHEAT).sellPrice()==4,"balanced crop payout");
      check(entry(catalog,Items.DIAMOND).buyPrice()==2500,"rare material price");
      migrations(scratch,registries,catalog);
      wallets();
      transactions(catalog);
      sales(catalog);
      quests(catalog);
      networking(catalog,registries);
      tooltips(catalog);
      checks+=ResaleTests.run(catalog,registries);
      checks+=StorageTests.run(catalog);
      System.out.println("PASS: " + checks + " checks on Minecraft " + SharedConstants.getCurrentVersion().name());
      Files.writeString(scratch.resolve("result.txt"),"PASS "+checks+" checks\n");
   }

   private static void migrations(Path scratch,Provider registries,ShopCatalog catalog) throws Exception {
      var old=json("default-shop-v3.json");
      row(old,"wheat").addProperty("buy",20);
      row(old,"carrot").addProperty("sell",6);
      row(old,"oak_log").addProperty("sell",20); // A custom sell price above the new default buy price.
      old.getAsJsonArray("items").remove(row(old,"diamond"));
      Path file=scratch.resolve("custom.json");
      String original=JSON.toJson(old);Files.writeString(file,original);
      var migrated=ShopCatalog.load(file,registries);
      check(entry(migrated,Items.WHEAT).buyPrice()==20,"custom buy preserved");
      check(entry(migrated,Items.WHEAT).sellPrice()==4,"untouched sell upgraded independently");
      check(entry(migrated,Items.CARROT).sellPrice()==6,"custom sell preserved");
      check(entry(migrated,Items.OAK_LOG).buyPrice()==24 && entry(migrated,Items.OAK_LOG).sellPrice()==20,"migration preserves a valid customized price pair");
      check(migrated.find(new ItemStack(Items.DIAMOND)).isEmpty(),"deliberate removal preserved");
      check(Files.readString(scratch.resolve("custom.pre-expansion.json")).equals(original),"exact config backup");
      String upgraded=Files.readString(file);ShopCatalog.load(file,registries);
      check(Files.readString(file).equals(upgraded),"migration idempotent");
      check(JSON.fromJson(upgraded,JsonObject.class).get("catalogVersion").getAsInt()==6,"catalog schema upgraded");
      for(String baseline:List.of("default-shop-v1.json","default-shop-v3.json","default-shop-v4.json","default-shop-v5.json")) {
         Path path=scratch.resolve(baseline);
         Files.writeString(path,JSON.toJson(json(baseline)));
         var loaded=ShopCatalog.load(path,registries);
         check(entry(loaded,Items.WHEAT).sellPrice()==4,"legacy upgrade "+baseline);
         check(entry(loaded,Items.ELYTRA).buyPrice()==500000 && entry(loaded,Items.ELYTRA).sellPrice()==120000,"treasure prices migrate "+baseline);
      }
      var customized=json("default-shop-v5.json");row(customized,"elytra").addProperty("buy",600000);row(customized,"elytra").addProperty("sell",140000);
      Path customTreasure=scratch.resolve("custom-treasure.json");Files.writeString(customTreasure,JSON.toJson(customized));
      var treasure=ShopCatalog.load(customTreasure,registries);
      check(entry(treasure,Items.ELYTRA).buyPrice()==600000 && entry(treasure,Items.ELYTRA).sellPrice()==140000,"custom treasure buy and sell survive new economy");
      Path bad=scratch.resolve("invalid.json");
      Files.writeString(bad,"{broken");
      rejects(()->ShopCatalog.load(bad,registries),"invalid JSON");
      check(Files.readString(bad).equals("{broken"),"invalid config left untouched");
      var future=json("default-shop.json");future.addProperty("catalogVersion",999);Files.writeString(bad,JSON.toJson(future));
      rejects(()->ShopCatalog.load(bad,registries),"future schema");
      var invalid=json("default-shop.json");row(invalid,"wheat").addProperty("buy",0);Files.writeString(bad,JSON.toJson(invalid));
      rejects(()->ShopCatalog.load(bad,registries),"zero buy");
      invalid=json("default-shop.json");row(invalid,"wheat").addProperty("sell",1000000);Files.writeString(bad,JSON.toJson(invalid));
      rejects(()->ShopCatalog.load(bad,registries),"sell exceeds buy");
      invalid=json("default-shop.json");invalid.getAsJsonArray("items").add(row(invalid,"wheat").deepCopy());Files.writeString(bad,JSON.toJson(invalid));
      rejects(()->ShopCatalog.load(bad,registries),"duplicate listing");
   }

   private static void wallets() throws Exception {
      var wallets=new Wallets();var alice=UUID.randomUUID();var bob=UUID.randomUUID();
      check(wallets.balance(alice,1000)==1000,"starting balance");
      check(wallets.debit(alice,1000,50) && wallets.balance(alice,0)==950,"debit");
      check(!wallets.debit(alice,0,951) && wallets.balance(alice,0)==950,"insufficient funds no debit");
      check(wallets.transfer(alice,bob,1000,150)==Wallets.TransferResult.SUCCESS,"payment succeeds");
      check(wallets.balance(alice,0)==800 && wallets.balance(bob,0)==1150,"payment conserves money");
      check(wallets.transfer(alice,alice,0,1)==Wallets.TransferResult.SELF_PAYMENT,"self payment rejected");
      check(wallets.transfer(alice,bob,0,0)==Wallets.TransferResult.INVALID_AMOUNT,"zero payment rejected");
      check(!wallets.credit(alice,0,Wallets.MAX_BALANCE),"wallet limit enforced");
      rejects(()->wallets.credit(alice,0,-1),"negative credit");
      var encoded=Wallets.CODEC.encodeStart(JsonOps.INSTANCE,wallets).getOrThrow();
      var decoded=Wallets.CODEC.parse(JsonOps.INSTANCE,encoded).getOrThrow();
      check(decoded.balance(alice,0)==800 && decoded.balance(bob,0)==1150,"balances survive serialization");
   }

   private static void transactions(ShopCatalog catalog) {
      var tx=new ShopTransactions(catalog);var inv=new SimpleContainer(36);var wallet=new Wallets();var id=UUID.randomUUID();
      var wheat=entry(catalog,Items.WHEAT);
      inv.setItem(0,new ItemStack(Items.WHEAT,60));
      var result=tx.buy(inv,36,wallet,id,wheat,8);
      check(result.success() && inv.getItem(0).getCount()==60 && inv.getItem(1).getCount()==8 && PurchaseOrigin.isPurchased(inv.getItem(1)),"purchases stay separate from natural stacks");
      check(wallet.balance(id,0)==catalog.startingBalance()-8*wheat.buyPrice(),"purchase charged exact total");
      long before=wallet.balance(id,0);
      check(!tx.buy(inv,36,wallet,id,wheat,2305).success() && wallet.balance(id,0)==before,"oversized purchase rejected");
      check(!tx.buy(inv,36,wallet,id,entry(catalog,Items.ELYTRA),1).success() && wallet.balance(id,0)==before,"unaffordable purchase leaves wallet intact");
      for(int i=0;i<36;i++) inv.setItem(i,new ItemStack(Items.STONE,64));
      check(!tx.buy(inv,36,wallet,id,wheat,1).success() && wallet.balance(id,0)==before,"full inventory never charged");
      check(tx.maxBuy(inv,36,wallet,id,wheat)==0,"max buy honors full inventory");
   }

   private static void sales(ShopCatalog catalog) {
      var wheat=new ItemStack(Items.WHEAT,32);
      var named=new ItemStack(Items.DIAMOND);named.set(DataComponents.CUSTOM_NAME,Component.literal("Keep me"));
      var damaged=new ItemStack(Items.DIAMOND_PICKAXE);damaged.setDamageValue(1);
      java.util.function.ToLongFunction<ItemStack> prices=catalog::sellPrice;
      check(SaleContents.plan(wheat,prices).total()==128,"sale quote exact");
      check(SaleContents.plan(named,prices).count()==0,"named items protected");
      check(SaleContents.plan(damaged,prices).count()==1 && catalog.sellPrice(damaged)<catalog.sellPrice(new ItemStack(Items.DIAMOND_PICKAXE)),"damaged gear sells at reduced value");
      check(!SaleContents.plan(new ItemStack(Items.WHEAT,2),item->Long.MAX_VALUE).valid(),"overflow sale rejected");
      var items=NonNullList.withSize(27,ItemStack.EMPTY);items.set(0,wheat);items.set(3,named);items.set(8,new ItemStack(Items.SHULKER_BOX));
      var shulker=new ItemStack(Items.SHULKER_BOX);shulker.set(DataComponents.CONTAINER,ItemContainerContents.fromItems(items));
      var original=shulker.copy();var plan=SaleContents.plan(shulker,prices);
      check(plan.count()==32 && plan.total()==128,"shulker sells only allowed contents");
      check(plan.remaining().is(Items.SHULKER_BOX),"shulker box kept");
      var contents=MinecraftCompat.itemCopies(plan.remaining().get(DataComponents.CONTAINER)).toList();
      check(contents.get(0).isEmpty() && ItemStack.matches(contents.get(3),named) && contents.get(8).is(Items.SHULKER_BOX),"protected and nested contents retained in their slots");
      check(ItemStack.matches(shulker,original),"quoting never mutates original shulker");
      var barrel=new ItemStack(Items.BARREL);barrel.set(DataComponents.CONTAINER,ItemContainerContents.fromItems(List.of(wheat)));
      check(SaleContents.plan(barrel,prices).count()==0,"filled non-shulker container protected");
      var inv=new SimpleContainer(36);inv.setItem(0,wheat.copy());inv.setItem(1,named.copy());
      var wallet=new Wallets();var id=UUID.randomUUID();var snapshot=InventorySales.snapshot(inv);
      inv.setItem(0,new ItemStack(Items.WHEAT,31));
      check(!InventorySales.sell(catalog,inv,snapshot,List.of(0),wallet,id).success() && inv.getItem(0).getCount()==31,"changed sale snapshot rejected");
      snapshot=InventorySales.snapshot(inv);
      check(!InventorySales.sell(catalog,inv,snapshot,List.of(0,0),wallet,id).success(),"duplicate selected slot rejected");
      var sale=InventorySales.sell(catalog,inv,snapshot,List.of(0),wallet,id);
      check(sale.success() && inv.getItem(0).isEmpty() && ItemStack.matches(inv.getItem(1),named),"confirmed sale consumes exact selection");
      check(wallet.balance(id,0)==catalog.startingBalance()+124,"selected sale payout exact");
      var capped=new Wallets();var capId=UUID.randomUUID();capped.credit(capId,0,Wallets.MAX_BALANCE);
      inv.setItem(0,new ItemStack(Items.WHEAT,1));
      check(!new ShopTransactions(catalog).sell(inv,0,1,capped,capId).success() && inv.getItem(0).getCount()==1,"wallet cap leaves sale items untouched");
   }

   private static void quests(ShopCatalog catalog) {
      var board=QuestBoard.quests(catalog);var ids=new HashSet<String>();
      for(var quest:board) {
         check(ids.add(quest.id()),"unique quest id "+quest.id());
         long ordinary=0,buy=0;
         for(var req:quest.requirements()) { var e=entry(catalog,req.item());ordinary+=req.amount()*e.sellPrice();buy+=req.amount()*e.buyPrice(); }
         check(quest.reward()>=ordinary && quest.reward()<=buy*70/100,"quest reward respects sale and purchase values "+quest.id());
      }
      var quest=board.getFirst();var inv=new SimpleContainer(36);inv.setItem(0,new ItemStack(quest.item(),quest.amount()));
      var progress=new QuestProgress();var wallet=new Wallets();var id=UUID.randomUUID();
      var result=QuestBoard.complete(quest,inv,InventorySales.snapshot(inv),progress,wallet,id,catalog.startingBalance());
      check(result.success() && progress.completed(id,quest.id()),"quest consumes delivery and records completion");
      check(!QuestBoard.complete(quest,inv,InventorySales.snapshot(inv),progress,wallet,id,catalog.startingBalance()).success(),"quest cannot pay twice");
      var encoded=QuestProgress.CODEC.encodeStart(JsonOps.INSTANCE,progress).getOrThrow();
      check(QuestProgress.CODEC.parse(JsonOps.INSTANCE,encoded).getOrThrow().completed(id,quest.id()),"quest progress survives serialization");
   }

   private static void networking(ShopCatalog catalog,Provider registries) throws Exception {
      String document=PriceCatalogCodec.encode(catalog,registries);
      var legacy=JsonParser.parseString(document).getAsJsonObject();legacy.addProperty("schema",2);
      rejects(()->PriceCatalogCodec.decode(legacy.toString(),registries),"old valuation protocol cannot silently show outdated prices");
      var index=PriceCatalogCodec.decode(document,registries);
      for(var category:ShopCatalog.Category.values()) for(var e:catalog.entries(category)) check(index.sellPrice(e.stack())==catalog.sellPrice(e.stack()),"host and client prices match "+e.key());
      var chunks=SellPricePayload.split(1,document);check(chunks.size()>1,"catalog split into multiple packets");
      var state=new RemotePriceState();Object connection=new Object();state.begin(connection);
      check(!state.receive(new Object(),chunks.getFirst(),registries),"other connection rejected");
      check(!state.receive(connection,chunks.get(1),registries),"out-of-order first packet rejected");
      for(var chunk:chunks) state.receive(connection,chunk,registries);
      check(state.revision()==1 && state.indexFor(connection,registries)!=null,"same revision can recover from out-of-order start");
      var newer=SellPricePayload.split(2,document);state.receive(connection,newer.getFirst(),registries);
      check(state.indexFor(connection,registries)==null,"old prices hidden during new sync");
      state.receive(connection,newer.get(2),registries);
      for(var chunk:newer) state.receive(connection,chunk,registries);
      check(state.revision()==2,"interrupted catalog transfer can restart");
      check(!state.receive(connection,chunks.getFirst(),registries) && state.revision()==2,"stale revision cannot replace prices");
      var malformed=SellPricePayload.split(3,"null");state.receive(connection,malformed.getFirst(),registries);
      check(state.indexFor(connection,registries)==null,"invalid remote catalog clears prices");
      for(var chunk:SellPricePayload.split(3,document)) state.receive(connection,chunk,registries);
      check(state.revision()==3,"malformed transfer can recover at same revision");
      state.clear();check(state.indexFor(connection,registries)==null && state.revision()==0,"disconnect clears all price state");
      rejects(()->PriceCatalogCodec.decode("[".repeat(65)+"]".repeat(65),registries),"deeply nested network data");
      rejects(()->new SellPricePayload(1,0,257,"x"),"too many fragments");
      rejects(()->new SellPricePayload(0,0,1,"x"),"invalid revision");
      rejects(()->PriceCatalogCodec.decode("[{\"stack\":{\"id\":\"minecraft:wheat\"},\"sell\":-1}]",registries),"negative remote price");
   }

   private static void tooltips(ShopCatalog catalog) {
      TooltipOptions.enabled=true;TooltipOptions.compact=false;TooltipOptions.fullStack=true;
      List<Component> lines=new ArrayList<>();SellPriceTooltip.append(catalog,new ItemStack(Items.WHEAT,3),lines);
      String text=String.join("\n",lines.stream().map(Component::getString).toList());
      check(text.contains("$4 each") && text.contains("Stack (3): $12") && text.contains("Full stack (64): $256"),"tooltip item, current and full stack agree");
      TooltipOptions.compact=true;lines.clear();SellPriceTooltip.append(catalog,new ItemStack(Items.WHEAT,3),lines);
      check(lines.size()==1 && lines.getFirst().getString().contains("$12"),"compact tooltip is a single accurate line");
      TooltipOptions.enabled=false;lines.clear();SellPriceTooltip.append(catalog,new ItemStack(Items.WHEAT),lines);check(lines.isEmpty(),"tooltip toggle respected");
      TooltipOptions.enabled=true;TooltipOptions.compact=false;
      var named=new ItemStack(Items.DIAMOND);named.set(DataComponents.CUSTOM_NAME,Component.literal("Keep"));lines.clear();SellPriceTooltip.append(catalog,named,lines);
      check(lines.stream().anyMatch(c->c.getString().contains("Named item protected")),"protected tooltip explains named items");
   }
}
