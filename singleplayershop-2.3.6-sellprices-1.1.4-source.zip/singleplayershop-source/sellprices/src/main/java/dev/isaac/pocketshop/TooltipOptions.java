package dev.isaac.pocketshop;

import com.google.gson.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.Set;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.LoggerFactory;

/** Client preferences never affect the host's authoritative prices. */
final class TooltipOptions {
   private static final Gson JSON = new GsonBuilder().setPrettyPrinting().setStrictness(Strictness.STRICT).create();
   private static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("singleplayershop-sellprices.json"); }
   static boolean enabled = true;
   static boolean compact = false;
   static boolean fullStack = true;
   static boolean details = true;

   private TooltipOptions() {}

   static boolean load() {
      try {
         Path FILE=file();
         if (!Files.exists(FILE)) return save();
         if (Files.size(FILE) > 4096) throw new IllegalArgumentException("tooltip config exceeds 4 KiB");
         JsonObject object = JSON.fromJson(Files.readString(FILE, StandardCharsets.UTF_8), JsonObject.class);
         if (object == null || !Set.of("enabled", "compact", "fullStack", "details").containsAll(object.keySet())) throw new IllegalArgumentException("unknown option");
         boolean nextEnabled = bool(object,"enabled",true);
         boolean nextCompact = bool(object,"compact",false);
         boolean nextFullStack = bool(object,"fullStack",true);
         boolean nextDetails=bool(object,"details",true);
         enabled=nextEnabled; compact=nextCompact; fullStack=nextFullStack;details=nextDetails;
         return true;
      } catch (Exception exception) {
         LoggerFactory.getLogger("singleplayershop-sellprices").warn("Could not load tooltip preferences; keeping the last working settings.", exception);
         return false;
      }
   }

   private static boolean bool(JsonObject object, String key, boolean fallback) {
      if (!object.has(key)) return fallback;
      JsonElement value=object.get(key);
      if (!value.isJsonPrimitive() || !value.getAsJsonPrimitive().isBoolean()) throw new IllegalArgumentException(key+" must be true or false");
      return value.getAsBoolean();
   }

   static boolean save() {
      Path temporary=null;
      try {
         Path FILE=file();
         JsonObject object=new JsonObject();
         object.addProperty("enabled",enabled);object.addProperty("compact",compact);object.addProperty("fullStack",fullStack);
         object.addProperty("details",details);
         Files.createDirectories(FILE.getParent());
         temporary=Files.createTempFile(FILE.getParent(),".sellprices-",".tmp");
         Files.writeString(temporary,JSON.toJson(object)+System.lineSeparator(),StandardCharsets.UTF_8);
         try { Files.move(temporary,FILE,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING); }
         catch (AtomicMoveNotSupportedException exception) { Files.move(temporary,FILE,StandardCopyOption.REPLACE_EXISTING); }
         return true;
      } catch (Exception exception) {
         LoggerFactory.getLogger("singleplayershop-sellprices").warn("Could not save tooltip preferences.",exception);
         return false;
      } finally {
         if (temporary!=null) try { Files.deleteIfExists(temporary); } catch (java.io.IOException ignored) {}
      }
   }
}
