package dev.isaac.pocketshop;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import net.minecraft.world.Container;
import net.minecraft.world.item.ItemStack;

public final class InventorySales {
   private static final int MAIN_INVENTORY_SLOTS = 36;
   private static final ShopTransactions.Quote EMPTY_QUOTE = new ShopTransactions.Quote(0, 0L);

   private InventorySales() {
   }

   public static List<ItemStack> snapshot(Container inventory) {
      int limit = limit(inventory);
      List<ItemStack> copy = new ArrayList<>(limit);

      for (int slot = 0; slot < limit; slot++) {
         copy.add(inventory.getItem(slot).copy());
      }

      return List.copyOf(copy);
   }

   public static ShopTransactions.Quote quote(ShopCatalog catalog, Container inventory, List<Integer> selected) {
      return validate(catalog, inventory, selected).quote();
   }

   public static ShopTransactions.Result sell(
      ShopCatalog catalog, Container inventory, List<ItemStack> snapshot, List<Integer> selected, Wallets wallets, UUID account
   ) {
      Objects.requireNonNull(wallets, "wallets");
      Objects.requireNonNull(account, "account");
      InventorySales.Selection selection = validate(catalog, inventory, selected);
      if (!selection.valid()) {
         return failure(selection.error());
      }

      if (snapshot != null && snapshot.size() == limit(inventory)) {
         for (InventorySales.Selected item : selection.items()) {
            int slot = item.slot();
            ItemStack reviewed = snapshot.get(slot);
            if (reviewed == null || !ItemStack.matches(inventory.getItem(slot), reviewed) || !ItemStack.matches(item.original(), reviewed)) {
               return failure("Your selected items changed. Review your selection before selling.");
            }
         }

         ShopTransactions.Quote quote = selection.quote();
         if (!wallets.credit(account, catalog.startingBalance(), quote.total())) {
            return failure("This sale would exceed the balance limit. Your items were kept.");
         }

         for (InventorySales.Selected item : selection.items()) {
            inventory.setItem(item.slot(), item.remaining());
         }

         inventory.setChanged();
         return new ShopTransactions.Result(
            true, "Sold " + quote.count() + " items for " + ShopTransactions.money(quote.total()) + ".", quote.count(), quote.total()
         );
      } else {
         return failure("Your inventory review is no longer valid. Review the sale again.");
      }
   }

   private static InventorySales.Selection validate(ShopCatalog catalog, Container inventory, List<Integer> selected) {
      Objects.requireNonNull(catalog, "catalog");
      int limit = limit(inventory);
      if (selected != null && !selected.isEmpty()) {
         if (selected.size() > limit) {
            return invalid("The selected inventory slots were invalid.");
         }

         Set<Integer> unique = new HashSet<>();
         List<InventorySales.Selected> items = new ArrayList<>(selected.size());
         int count = 0;
         long total = 0L;

         for (Integer slot : selected) {
            if (slot == null || slot < 0 || slot >= limit || !unique.add(slot)) {
               return invalid("The selected inventory slots were invalid.");
            }

            ItemStack stack = inventory.getItem(slot).copy();
            SaleContents.Plan plan = SaleContents.plan(stack, catalog::sellPrice);
            if (!plan.valid()) {
               return invalid("That sale is too large. Choose fewer stacks.");
            }

            if (plan.count() == 0) {
               return invalid("A selected item cannot be sold. Your items were kept.");
            }

            try {
               count = Math.addExact(count, plan.count());
               total = Math.addExact(total, plan.total());
            } catch (ArithmeticException exception) {
               return invalid("That sale is too large. Choose fewer stacks.");
            }

            items.add(new InventorySales.Selected(slot, stack, plan.remaining()));
         }

         return new InventorySales.Selection(List.copyOf(items), new ShopTransactions.Quote(count, total), "");
      } else {
         return invalid("Select at least one sellable stack.");
      }
   }

   private static int limit(Container inventory) {
      return Math.min(36, Objects.requireNonNull(inventory, "inventory").getContainerSize());
   }

   private static InventorySales.Selection invalid(String reason) {
      return new InventorySales.Selection(List.of(), EMPTY_QUOTE, reason);
   }

   private static ShopTransactions.Result failure(String message) {
      return new ShopTransactions.Result(false, message, 0, 0L);
   }

   private record Selected(int slot, ItemStack original, ItemStack remaining) {
   }

   private record Selection(List<InventorySales.Selected> items, ShopTransactions.Quote quote, String error) {
      boolean valid() {
         return this.error.isEmpty();
      }
   }
}
