# 2.3.6 / Sell Prices 1.1.4

## Treasure economy

- Make enchanted treasure worth substantial money: six-figure diamond/netherite loadouts, rare books and elytra.
- Scale each enchantment by its exact book level, material and equipment type. Wooden gear stays inexpensive.
- Add capped maximum-level loadout bonuses, transparent rarity bands, proportional wear and curse discounts.
- Reprice rare materials and loot; align enchanted purchases and rare manufactured items with their ingredients.
- Keep survival staples and $1,000 starting money; retain purchased-item resale restrictions.
- Add eight Treasure armor loadouts across diamond/netherite armor slots.

## Expanded Sell Axe storage

- Add barrels, all shulker colors, hoppers, dispensers, droppers, furnaces, blast furnaces, smokers, brewing stands, crafters, bookshelves, shelves, decorated pots and jukeboxes.
- Support the interacting player's own Ender Chest contents and compatible vanilla Container inventories up to 4,096 slots.
- Preserve each storage block and protected contents, and recheck access before confirming.
- Refuse unopened loot, blocked chests/shulkers, stale reviews and incompatible inventory writes.
- Verify actual removals and roll back failed storage writes.

## Appraisal features

- Add `/shop inspect`, `/worth details`, `/worth top` and `/shop economy`.
- Include real enchanted-book and equipment payouts in the earning guide; sort by calculated payout.
- Show detailed appraisals in the main shop and sale-selection menus.
- Highlight the most valuable stack during Sell Axe storage previews.
- Keep the named, max-enchanted netherite Sell Axe and reviewed storage-content sales; update its default price to $900,000.

## Sell Prices 1.1.4

- Show base value, rarity, equipment factor, each enchantment, loadout bonus, curse/wear discounts, durability and full-condition value.
- Add `/sellprices details`; preserve compact mode and existing preferences.
- Use synchronized price protocol 3 so older clients cannot calculate new host prices with the old formula.

## Compatibility

- Support Minecraft 26.1.2, 26.2 and 26.3 on Fabric/Java 25.
- Migrate catalog version 6 from version-5 and older baselines with exact backups and custom-price preservation.
- Preserve wallet and quest save identities; require compatible addon versions.
