package dev.isaac.pocketshop;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import net.minecraft.core.UUIDUtil;
import net.minecraft.resources.Identifier;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.level.saveddata.SavedDataType;

public final class QuestProgress extends SavedData {
   private static final Codec<String> ID_CODEC = Codec.STRING
      .validate(id -> validId(id) ? DataResult.success(id) : DataResult.error(() -> "Invalid quest ID: " + id));
   private static final Codec<Set<String>> COMPLETED_CODEC = ID_CODEC.listOf().xmap(Set::copyOf, completed -> completed.stream().sorted().toList());
   static final Codec<QuestProgress> CODEC = Codec.unboundedMap(UUIDUtil.STRING_CODEC, COMPLETED_CODEC).xmap(QuestProgress::new, progress -> {
      Map<UUID, Set<String>> copy = new HashMap<>();
      progress.players.forEach((player, completed) -> copy.put(player, Set.copyOf((Collection<? extends String>)completed)));
      return Map.copyOf(copy);
   });
   private static final SavedDataType<QuestProgress> TYPE = new SavedDataType(
      Identifier.fromNamespaceAndPath("pocketshop", "quests"), QuestProgress::new, CODEC, null
   );
   private final Map<UUID, Set<String>> players = new HashMap<>();

   public QuestProgress() {
   }

   private QuestProgress(Map<UUID, Set<String>> saved) {
      this();
      saved.forEach((player, completed) -> this.players.put(player, new HashSet<>((Collection<? extends String>)completed)));
   }

   public static QuestProgress get(MinecraftServer server) {
      return (QuestProgress)Objects.requireNonNull(server, "server").overworld().getDataStorage().computeIfAbsent(TYPE);
   }

   public boolean completed(UUID player, String id) {
      return this.players.getOrDefault(Objects.requireNonNull(player, "player"), Set.of()).contains(Objects.requireNonNull(id, "id"));
   }

   public boolean ready(UUID player, QuestBoard.Quest quest) {
      Objects.requireNonNull(quest, "quest");
      return !this.completed(player, quest.id()) && (quest.prerequisite().isEmpty() || this.completed(player, quest.prerequisite()));
   }

   public int completedCount(UUID player) {
      return this.players.getOrDefault(Objects.requireNonNull(player, "player"), Set.of()).size();
   }

   boolean complete(UUID player, String id) {
      Objects.requireNonNull(player, "player");
      if (!validId(id)) {
         throw new IllegalArgumentException("Invalid quest ID");
      }

      if (!this.players.computeIfAbsent(player, ignored -> new HashSet<>()).add(id)) {
         return false;
      }

      this.setDirty();
      return true;
   }

   static boolean validId(String id) {
      return id != null && id.matches("[a-z0-9_./:-]{1,128}");
   }
}
