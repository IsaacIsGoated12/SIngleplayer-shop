package dev.isaac.pocketshop;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import net.minecraft.core.UUIDUtil;
import net.minecraft.resources.Identifier;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.level.saveddata.SavedDataType;

public final class Wallets extends SavedData {
   public static final long MAX_BALANCE = 1000000000000L;
   private static final Codec<Long> BALANCE_CODEC = Codec.LONG
      .validate(
         value -> value >= 0L && value <= 1000000000000L ? DataResult.success(value) : DataResult.error(() -> "Balance must be between 0 and 1000000000000")
      );
   static final Codec<Wallets> CODEC = Codec.unboundedMap(UUIDUtil.STRING_CODEC, BALANCE_CODEC).xmap(Wallets::new, wallets -> Map.copyOf(wallets.accounts));
   private static final SavedDataType<Wallets> TYPE = new SavedDataType(Identifier.fromNamespaceAndPath("pocketshop", "wallets"), Wallets::new, CODEC, null);
   private final Map<UUID, Long> accounts;

   public Wallets() {
      this.accounts = new HashMap<>();
   }

   private Wallets(Map<UUID, Long> accounts) {
      this.accounts = new HashMap<>(accounts);
   }

   public static Wallets get(MinecraftServer server) {
      return (Wallets)Objects.requireNonNull(server, "server").overworld().getDataStorage().computeIfAbsent(TYPE);
   }

   public long balance(UUID player, long startingBalance) {
      Objects.requireNonNull(player, "player");
      if (startingBalance >= 0L && startingBalance <= 1000000000000L) {
         Long existing = this.accounts.get(player);
         if (existing != null) {
            return existing;
         }

         this.accounts.put(player, startingBalance);
         this.setDirty();
         return startingBalance;
      } else {
         throw new IllegalArgumentException("Starting balance must be between 0 and 1000000000000");
      }
   }

   public boolean canCredit(UUID player, long startingBalance, long amount) {
      requireNonnegative(amount);
      return amount <= 1000000000000L - this.balance(player, startingBalance);
   }

   public boolean credit(UUID player, long startingBalance, long amount) {
      requireNonnegative(amount);
      long current = this.balance(player, startingBalance);
      if (amount > 1000000000000L - current) {
         return false;
      }

      if (amount != 0L) {
         this.accounts.put(player, current + amount);
         this.setDirty();
      }

      return true;
   }

   public boolean debit(UUID player, long startingBalance, long amount) {
      requireNonnegative(amount);
      long current = this.balance(player, startingBalance);
      if (amount > current) {
         return false;
      }

      if (amount != 0L) {
         this.accounts.put(player, current - amount);
         this.setDirty();
      }

      return true;
   }

   public Wallets.TransferResult transfer(UUID sender, UUID recipient, long startingBalance, long amount) {
      Objects.requireNonNull(sender, "sender");
      Objects.requireNonNull(recipient, "recipient");
      if (startingBalance < 0L || startingBalance > 1000000000000L) {
         throw new IllegalArgumentException("Starting balance must be between 0 and 1000000000000");
      }

      if (amount <= 0L || amount > 1000000000000L) {
         return Wallets.TransferResult.INVALID_AMOUNT;
      }

      if (sender.equals(recipient)) {
         return Wallets.TransferResult.SELF_PAYMENT;
      }

      long senderBalance = this.accounts.getOrDefault(sender, startingBalance);
      long recipientBalance = this.accounts.getOrDefault(recipient, startingBalance);
      if (amount > senderBalance) {
         return Wallets.TransferResult.INSUFFICIENT_FUNDS;
      }

      if (amount > 1000000000000L - recipientBalance) {
         return Wallets.TransferResult.RECIPIENT_FULL;
      }

      this.accounts.put(sender, senderBalance - amount);
      this.accounts.put(recipient, recipientBalance + amount);
      this.setDirty();
      return Wallets.TransferResult.SUCCESS;
   }

   private static void requireNonnegative(long amount) {
      if (amount < 0L) {
         throw new IllegalArgumentException("Amount cannot be negative");
      }
   }

   public enum TransferResult {
      SUCCESS,
      INVALID_AMOUNT,
      SELF_PAYMENT,
      INSUFFICIENT_FUNDS,
      RECIPIENT_FULL;
   }
}
