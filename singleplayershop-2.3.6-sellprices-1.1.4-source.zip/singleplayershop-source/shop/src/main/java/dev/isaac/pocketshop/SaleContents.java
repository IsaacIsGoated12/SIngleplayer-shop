package dev.isaac.pocketshop;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.ToLongFunction;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.BundleContents;
import net.minecraft.world.item.component.ItemContainerContents;
import net.minecraft.world.level.block.ShulkerBoxBlock;

public final class SaleContents {
   private static final int SHULKER_SLOTS = 27;

   private SaleContents() {
   }

   public static boolean isShulker(ItemStack stack) {
      return stack != null && !stack.isEmpty() && stack.getItem() instanceof BlockItem item && item.getBlock() instanceof ShulkerBoxBlock;
   }

   public static SaleContents.Plan plan(ItemStack stack, ToLongFunction<ItemStack> unitPrice) {
      Objects.requireNonNull(unitPrice, "unitPrice");
      ItemStack original = stack == null ? ItemStack.EMPTY : stack.copy();
      if (!original.isEmpty() && !original.has(DataComponents.CONTAINER_LOOT)) {
         try {
            if (!isShulker(original)) {
               if (hasStoredItems(original) || PurchaseOrigin.isPurchased(original)) {
                  return kept(original);
               }

               long price = unitPrice.applyAsLong(original);
               return price <= 0L
                  ? kept(original)
                  : new SaleContents.Plan(original.getCount(), Math.multiplyExact(price, original.getCount()), ItemStack.EMPTY, true);
            } else {
               if (original.getCount() != 1) {
                  return kept(original);
               }

               ItemContainerContents contents = (ItemContainerContents)original.get(DataComponents.CONTAINER);
               if (contents == null) {
                  return kept(original);
               }

               List<ItemStack> items = new ArrayList<>(MinecraftCompat.itemCopies(contents).limit(28L).toList());
               if (items.size() > 27) {
                  return kept(original);
               }

               if (!contents.equals(ItemContainerContents.fromItems(items))) {
                  return kept(original);
               }

               int count = 0;
               long total = 0L;

               for (int slot = 0; slot < items.size(); slot++) {
                  ItemStack item = items.get(slot);
                  if (!item.isEmpty()
                     && !PurchaseOrigin.isPurchased(item)
                     && !isShulker(item)
                     && !item.has(DataComponents.BUNDLE_CONTENTS)
                     && !item.has(DataComponents.CONTAINER_LOOT)
                     && !hasStoredItems(item)) {
                     long price = unitPrice.applyAsLong(item);
                     if (price > 0L) {
                        count = Math.addExact(count, item.getCount());
                        total = Math.addExact(total, Math.multiplyExact(price, item.getCount()));
                        items.set(slot, ItemStack.EMPTY);
                     }
                  }
               }

               if (count == 0) {
                  return kept(original);
               }

               ItemStack remaining = original.copy();
               remaining.set(DataComponents.CONTAINER, ItemContainerContents.fromItems(items));
               return new SaleContents.Plan(count, total, remaining, true);
            }
         } catch (ArithmeticException overflow) {
            return new SaleContents.Plan(0, 0L, original, false);
         }
      } else {
         return kept(original);
      }
   }

   private static boolean hasStoredItems(ItemStack stack) {
      var projectiles=stack.get(DataComponents.CHARGED_PROJECTILES);
      if(projectiles!=null && !projectiles.isEmpty()) return true;
      ItemContainerContents container = (ItemContainerContents)stack.get(DataComponents.CONTAINER);
      if (container != null && container.nonEmptyItems().iterator().hasNext()) {
         return true;
      }

      BundleContents bundle = (BundleContents)stack.get(DataComponents.BUNDLE_CONTENTS);
      return bundle != null && !bundle.isEmpty();
   }

   private static SaleContents.Plan kept(ItemStack stack) {
      return new SaleContents.Plan(0, 0L, stack, true);
   }

   public static final class Plan {
      private final int count;
      private final long total;
      private final ItemStack remaining;
      private final boolean valid;

      private Plan(int count, long total, ItemStack remaining, boolean valid) {
         this.count = count;
         this.total = total;
         this.remaining = remaining.copy();
         this.valid = valid;
      }

      public int count() {
         return this.count;
      }

      public long total() {
         return this.total;
      }

      public ItemStack remaining() {
         return this.remaining.copy();
      }

      public boolean valid() {
         return this.valid;
      }
   }
}
