package dev.isaac.pocketshop;

import java.util.Objects;
import net.minecraft.core.HolderLookup.Provider;

public final class RemotePriceState {
   private Object connection;
   private Provider registries;
   private SellPriceIndex index;
   private long revision;
   private int nextChunk;
   private int chunkCount;
   private StringBuilder pending;
   private String document;

   public void begin(Object connection) {
      this.clear();
      this.connection = Objects.requireNonNull(connection, "connection");
   }

   public void clear() {
      this.connection = null;
      this.registries = null;
      this.index = null;
      this.document = null;
      this.revision = 0L;
      this.discardPending();
   }

   public boolean receive(Object connection, SellPricePayload payload, Provider registries) {
      if (this.connection != null && this.connection == connection) {
         Objects.requireNonNull(payload, "payload");
         Objects.requireNonNull(registries, "registries");
         if (payload.revision() < this.revision) {
            return false;
         }

         if (payload.revision() > this.revision
            || (payload.revision() == this.revision && this.pending == null && this.index == null && payload.index() == 0)) {
            this.revision = payload.revision();
            this.index = null;
            this.document = null;
            this.discardPending();
            if (payload.index() != 0) {
               return false;
            }

            this.registries = registries;
            this.pending = new StringBuilder();
            this.chunkCount = payload.count();
         }

         if (this.pending == null) {
            return false;
         }

         if (payload.index() == this.nextChunk
            && payload.count() == this.chunkCount
            && this.registries == registries
            && this.pending.length() + payload.fragment().length() <= 6144000) {
            this.pending.append(payload.fragment());
            if (++this.nextChunk < this.chunkCount) {
               return false;
            }

            try {
               String complete = this.pending.toString();
               this.index = PriceCatalogCodec.decode(complete, registries);
               this.document = complete;
               return true;
            } catch (RuntimeException invalidCatalog) {
               this.index = null;
               return false;
            } finally {
               this.discardPending();
            }
         } else {
            this.index = null;
            this.discardPending();
            return false;
         }
      } else {
         return false;
      }
   }

   public SellPriceIndex indexFor(Object connection, Provider registries) {
      if (this.connection != null && this.connection == connection) {
         if (this.registries != registries && this.document != null) {
            this.registries = Objects.requireNonNull(registries, "registries");

            try {
               this.index = PriceCatalogCodec.decode(this.document, registries);
            } catch (RuntimeException invalidCatalog) {
               this.index = null;
            }
         }

         return this.registries == registries ? this.index : null;
      } else {
         return null;
      }
   }

   public long revision() {
      return this.index == null ? 0L : this.revision;
   }

   private void discardPending() {
      this.pending = null;
      this.nextChunk = 0;
      this.chunkCount = 0;
   }
}
