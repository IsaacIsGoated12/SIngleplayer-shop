package dev.isaac.pocketshop;

import java.util.*;
import com.google.gson.JsonElement;
import com.mojang.serialization.JsonOps;
import net.minecraft.core.HolderLookup.Provider;
import net.minecraft.world.item.ItemStack;

/** Rebound host offers evaluated with exactly the same algorithm used by the shop. */
public final class SellPriceIndex {
   private final ItemValuation valuation;
   private SellPriceIndex(List<Template> templates) {
      valuation=new ItemValuation(templates.stream().map(t->new ItemValuation.Offer(t.stack(),t.buy(),t.price())).toList());
   }
   public static SellPriceIndex fromTemplates(List<Template> templates) {
      Objects.requireNonNull(templates);
      if(templates.size()>PriceCatalogCodec.MAX_ENTRIES) throw new IllegalArgumentException("Too many sale templates");
      return new SellPriceIndex(List.copyOf(templates));
   }
   public static SellPriceIndex create(ShopCatalog catalog,Provider serverRegistries,Provider clientRegistries) {
      List<Template> templates=new ArrayList<>();
      var source=serverRegistries.createSerializationContext(JsonOps.INSTANCE);
      var target=clientRegistries.createSerializationContext(JsonOps.INSTANCE);
      for(var category:ShopCatalog.Category.values()) for(var entry:catalog.entries(category)) {
         JsonElement encoded=ItemStack.CODEC.encodeStart(source,entry.stack()).getOrThrow();
         ItemStack rebound=ItemStack.CODEC.parse(target,encoded).getOrThrow();
         templates.add(new Template(rebound,entry.sellPrice(),entry.buyPrice()));
      }
      return fromTemplates(templates);
   }
   public long sellPrice(ItemStack stack) { return valuation.sellPrice(stack); }
   public ItemValuation.Breakdown valuation(ItemStack stack) { return valuation.quote(stack); }
   public record Template(ItemStack stack,long price,long buy) {
      public Template(ItemStack stack,long price) { this(stack,price,Math.max(1,price)); }
      public Template {
         Objects.requireNonNull(stack);
         if(stack.isEmpty() || stack.getCount()!=1 || buy<1 || buy>ItemValuation.MAX_PRICE || price<0 || price>buy) throw new IllegalArgumentException("Invalid sale template");
         stack=stack.copy();
      }
      public ItemStack stack() { return stack.copy(); }
   }
}
