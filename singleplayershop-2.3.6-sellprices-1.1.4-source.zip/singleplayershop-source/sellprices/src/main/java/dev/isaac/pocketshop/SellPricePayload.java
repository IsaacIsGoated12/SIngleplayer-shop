package dev.isaac.pocketshop;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import net.minecraft.resources.Identifier;

public record SellPricePayload(long revision, int index, int count, String fragment) implements CustomPacketPayload {
   public static final int MAX_FRAGMENT_CHARS = 24000;
   public static final int MAX_CHUNKS = 256;
   public static final int MAX_DOCUMENT_CHARS = 6144000;
   public static final Type<SellPricePayload> TYPE = new Type(Identifier.fromNamespaceAndPath("singleplayershop_sellprices", "catalog_v3"));
   public static final StreamCodec<FriendlyByteBuf, SellPricePayload> CODEC = StreamCodec.of((buffer, value) -> {
      buffer.writeLong(value.revision());
      buffer.writeVarInt(value.index());
      buffer.writeVarInt(value.count());
      buffer.writeUtf(value.fragment(), 24000);
   }, buffer -> new SellPricePayload(buffer.readLong(), buffer.readVarInt(), buffer.readVarInt(), buffer.readUtf(24000)));

   public SellPricePayload(long revision, int index, int count, String fragment) {
      Objects.requireNonNull(fragment, "fragment");
      if (revision >= 1L && count >= 1 && count <= 256 && index >= 0 && index < count && !fragment.isEmpty() && fragment.length() <= 24000) {
         this.revision = revision;
         this.index = index;
         this.count = count;
         this.fragment = fragment;
      } else {
         throw new IllegalArgumentException("Invalid shop price packet");
      }
   }

   public static List<SellPricePayload> split(long revision, String document) {
      Objects.requireNonNull(document, "document");
      if (!document.isEmpty() && document.length() <= 6144000) {
         List<String> fragments = new ArrayList<>();
         int start = 0;

         while (start < document.length()) {
            int end = Math.min(document.length(), start + 24000);
            if (end < document.length() && Character.isHighSurrogate(document.charAt(end - 1))) {
               end--;
            }

            fragments.add(document.substring(start, end));
            if (fragments.size() > 256) {
               throw new IllegalArgumentException("Too many shop catalog fragments");
            }

            start = end;
         }

         List<SellPricePayload> result = new ArrayList<>(fragments.size());

         for (int index = 0; index < fragments.size(); index++) {
            result.add(new SellPricePayload(revision, index, fragments.size(), fragments.get(index)));
         }

         return List.copyOf(result);
      } else {
         throw new IllegalArgumentException("Shop price catalog exceeds the transfer limit");
      }
   }

   public Type<? extends CustomPacketPayload> type() {
      return TYPE;
   }
}
