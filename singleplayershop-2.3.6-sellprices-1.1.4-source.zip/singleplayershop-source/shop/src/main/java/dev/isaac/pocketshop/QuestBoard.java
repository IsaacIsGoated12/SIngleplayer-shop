package dev.isaac.pocketshop;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.Container;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

public final class QuestBoard {
   public static final int TIER_COUNT = 6;
   private static final int MAIN_SLOTS = 36;
   private static final int[] NORMAL_AMOUNTS = new int[]{64, 256, 1024, 2048, 2048, 2048};
   private static final int[] RARE_AMOUNTS = new int[]{4, 16, 64, 128, 256, 512};
   private static final int[] EXTRA_AMOUNTS = new int[]{0, 0, 32, 128, 192, 256};
   private static final int[] BONUS_PERCENT = new int[]{125, 130, 135, 140, 145, 150};
   private static volatile QuestBoard.CachedBoard cachedBoard;
   private static final List<QuestBoard.Chain> CHAINS = List.of(
      new QuestBoard.Chain(Items.WHEAT, "Wheat Harvest"),
      new QuestBoard.Chain(Items.CARROT, "Carrot Harvest"),
      new QuestBoard.Chain(Items.POTATO, "Potato Harvest"),
      new QuestBoard.Chain(Items.SUGAR_CANE, "Sugar Cane Supply"),
      new QuestBoard.Chain(Items.PUMPKIN, "Pumpkin Patch"),
      new QuestBoard.Chain(Items.MELON_SLICE, "Melon Harvest"),
      new QuestBoard.Chain(Items.CACTUS, "Desert Harvest"),
      new QuestBoard.Chain(Items.BAMBOO, "Bamboo Supply"),
      new QuestBoard.Chain(Items.SWEET_BERRIES, "Berry Basket"),
      new QuestBoard.Chain(Items.NETHER_WART, "Nether Harvest"),
      new QuestBoard.Chain(Items.OAK_LOG, "Oak Lumber"),
      new QuestBoard.Chain(Items.SPRUCE_LOG, "Spruce Lumber"),
      new QuestBoard.Chain(Items.BIRCH_LOG, "Birch Lumber"),
      new QuestBoard.Chain(Items.COBBLESTONE, "Quarry Delivery"),
      new QuestBoard.Chain(Items.COBBLED_DEEPSLATE, "Deep Quarry"),
      new QuestBoard.Chain(Items.SAND, "Sand Supply"),
      new QuestBoard.Chain(Items.GRAVEL, "Gravel Supply"),
      new QuestBoard.Chain(Items.DIRT, "Landscaper's Order"),
      new QuestBoard.Chain(Items.COAL, "Coal Delivery"),
      new QuestBoard.Chain(Items.RAW_IRON, "Iron Prospector"),
      new QuestBoard.Chain(Items.RAW_COPPER, "Copper Prospector"),
      new QuestBoard.Chain(Items.REDSTONE, "Redstone Supply"),
      new QuestBoard.Chain(Items.LAPIS_LAZULI, "Lapis Collection"),
      new QuestBoard.Chain(Items.DIAMOND, "Diamond Prospector", true),
      new QuestBoard.Chain(Items.EMERALD, "Emerald Collection", true),
      new QuestBoard.Chain(Items.BONE, "Bone Collection"),
      new QuestBoard.Chain(Items.ROTTEN_FLESH, "Zombie Cleanup"),
      new QuestBoard.Chain(Items.STRING, "String Supply"),
      new QuestBoard.Chain(Items.GUNPOWDER, "Gunpowder Supply"),
      new QuestBoard.Chain(Items.ENDER_PEARL, "Ender Collection", true),
      new QuestBoard.Chain(Items.BEETROOT, "Beetroot Harvest"),
      new QuestBoard.Chain(Items.KELP, "Kelp Harvest"),
      new QuestBoard.Chain(Items.APPLE, "Orchard Basket"),
      new QuestBoard.Chain(Items.COCOA_BEANS, "Cocoa Harvest"),
      new QuestBoard.Chain(Items.HONEYCOMB, "Beekeeper's Delivery"),
      new QuestBoard.Chain(Items.GLOW_BERRIES, "Cave Berry Basket"),
      new QuestBoard.Chain(Items.BROWN_MUSHROOM, "Brown Mushroom Forage"),
      new QuestBoard.Chain(Items.RED_MUSHROOM, "Red Mushroom Forage"),
      new QuestBoard.Chain(Items.COD, "Cod Catch"),
      new QuestBoard.Chain(Items.SALMON, "Salmon Catch"),
      new QuestBoard.Chain(Items.TROPICAL_FISH, "Tropical Catch"),
      new QuestBoard.Chain(Items.PUFFERFISH, "Pufferfish Catch"),
      new QuestBoard.Chain(Items.COOKED_COD, "Fish Supper"),
      new QuestBoard.Chain(Items.COOKED_SALMON, "Salmon Supper"),
      new QuestBoard.Chain(Items.COOKED_BEEF, "Steak Supper"),
      new QuestBoard.Chain(Items.COOKED_CHICKEN, "Chicken Supper"),
      new QuestBoard.Chain(Items.BAKED_POTATO, "Baked Potato Order"),
      new QuestBoard.Chain(Items.BREAD, "Baker's Delivery"),
      new QuestBoard.Chain(Items.JUNGLE_LOG, "Jungle Lumber"),
      new QuestBoard.Chain(Items.ACACIA_LOG, "Acacia Lumber"),
      new QuestBoard.Chain(Items.DARK_OAK_LOG, "Dark Oak Lumber"),
      new QuestBoard.Chain(Items.MANGROVE_LOG, "Mangrove Lumber"),
      new QuestBoard.Chain(Items.CHERRY_LOG, "Cherry Lumber"),
      new QuestBoard.Chain(Items.STONE, "Stone Supply"),
      new QuestBoard.Chain(Items.GRANITE, "Granite Supply"),
      new QuestBoard.Chain(Items.DIORITE, "Diorite Supply"),
      new QuestBoard.Chain(Items.ANDESITE, "Andesite Supply"),
      new QuestBoard.Chain(Items.TUFF, "Tuff Supply"),
      new QuestBoard.Chain(Items.CALCITE, "Calcite Supply"),
      new QuestBoard.Chain(Items.NETHERRACK, "Nether Quarry"),
      new QuestBoard.Chain(Items.BLACKSTONE, "Blackstone Quarry"),
      new QuestBoard.Chain(Items.QUARTZ, "Quartz Prospector"),
      new QuestBoard.Chain(Items.RAW_GOLD, "Gold Prospector"),
      new QuestBoard.Chain(Items.LEATHER, "Leather Supply"),
      new QuestBoard.Chain(Items.FEATHER, "Feather Collection"),
      new QuestBoard.Chain(Items.SPIDER_EYE, "Spider Cleanup"),
      new QuestBoard.Chain(Items.SLIME_BALL, "Slime Collection"),
      new QuestBoard.Chain(Items.MAGMA_CREAM, "Magma Collection"),
      new QuestBoard.Chain(Items.BLAZE_ROD, "Fortress Delivery"),
      new QuestBoard.Chain(Items.GHAST_TEAR, "Ghast Tear Collection", true),
      new QuestBoard.Chain(Items.PHANTOM_MEMBRANE, "Night Patrol", true),
      new QuestBoard.Chain(Items.PAPER, "Paper Supply"),
      new QuestBoard.Chain(Items.GLASS, "Glassmaker's Order"),
      new QuestBoard.Chain(Items.BRICK, "Brickmaker's Order"),
      new QuestBoard.Chain(Items.STONE_BRICKS, "Mason's Delivery"),
      new QuestBoard.Chain(Items.CHARCOAL, "Charcoal Supply"),
      new QuestBoard.Chain(Items.CHEST, "Storage Delivery"),
      new QuestBoard.Chain(Items.TORCH, "Lighting Delivery"),
      new QuestBoard.Chain(Items.LADDER, "Ladder Supply"),
      new QuestBoard.Chain(Items.IRON_INGOT, "Iron Smelter"),
      new QuestBoard.Chain(vanillaItem("gold_ingot"), "Gold Smelter"),
      new QuestBoard.Chain(vanillaItem("copper_ingot"), "Copper Smelter"),
      new QuestBoard.Chain(vanillaItem("netherite_scrap"), "Netherite Refinery", true),
      new QuestBoard.Chain(vanillaItem("netherite_ingot"), "Netherite Treasury", true),
      new QuestBoard.Chain(vanillaItem("ancient_debris"), "Ancient Excavation", true),
      new QuestBoard.Chain(vanillaItem("amethyst_shard"), "Geode Collection"),
      new QuestBoard.Chain(vanillaItem("flint"), "Flint Delivery"),
      new QuestBoard.Chain(vanillaItem("clay_ball"), "Potter's Supplies"),
      new QuestBoard.Chain(vanillaItem("glowstone_dust"), "Glowstone Dust Collection"),
      new QuestBoard.Chain(vanillaItem("prismarine_shard"), "Guardian Salvage"),
      new QuestBoard.Chain(vanillaItem("prismarine_crystals"), "Ocean Crystal Collection"),
      new QuestBoard.Chain(vanillaItem("nautilus_shell"), "Nautilus Collection", true),
      new QuestBoard.Chain(vanillaItem("heart_of_the_sea"), "Buried Treasure", true),
      new QuestBoard.Chain(vanillaItem("shulker_shell"), "End City Salvage", true),
      new QuestBoard.Chain(vanillaItem("echo_shard"), "Ancient City Relics", true),
      new QuestBoard.Chain(vanillaItem("pale_oak_log"), "Pale Oak Lumber"),
      new QuestBoard.Chain(vanillaItem("crimson_stem"), "Crimson Lumber"),
      new QuestBoard.Chain(vanillaItem("warped_stem"), "Warped Lumber"),
      new QuestBoard.Chain(vanillaItem("oak_sapling"), "Oak Nursery"),
      new QuestBoard.Chain(vanillaItem("spruce_sapling"), "Spruce Nursery"),
      new QuestBoard.Chain(vanillaItem("birch_sapling"), "Birch Nursery"),
      new QuestBoard.Chain(vanillaItem("jungle_sapling"), "Jungle Nursery"),
      new QuestBoard.Chain(vanillaItem("acacia_sapling"), "Acacia Nursery"),
      new QuestBoard.Chain(vanillaItem("dark_oak_sapling"), "Dark Oak Nursery"),
      new QuestBoard.Chain(vanillaItem("cherry_sapling"), "Cherry Nursery"),
      new QuestBoard.Chain(vanillaItem("pale_oak_sapling"), "Pale Oak Nursery"),
      new QuestBoard.Chain(vanillaItem("mangrove_propagule"), "Mangrove Nursery"),
      new QuestBoard.Chain(vanillaItem("azalea"), "Azalea Garden"),
      new QuestBoard.Chain(vanillaItem("flowering_azalea"), "Flowering Garden"),
      new QuestBoard.Chain(vanillaItem("moss_block"), "Moss Garden"),
      new QuestBoard.Chain(vanillaItem("vine"), "Vine Collection"),
      new QuestBoard.Chain(vanillaItem("lily_pad"), "Pond Garden"),
      new QuestBoard.Chain(vanillaItem("big_dripleaf"), "Dripleaf Garden"),
      new QuestBoard.Chain(vanillaItem("wheat_seeds"), "Wheat Seed Reserve"),
      new QuestBoard.Chain(vanillaItem("beetroot_seeds"), "Beetroot Seed Reserve"),
      new QuestBoard.Chain(vanillaItem("pumpkin_seeds"), "Pumpkin Seed Reserve"),
      new QuestBoard.Chain(vanillaItem("melon_seeds"), "Melon Seed Reserve"),
      new QuestBoard.Chain(vanillaItem("sugar"), "Sugar Refinery"),
      new QuestBoard.Chain(vanillaItem("melon"), "Whole Melon Delivery"),
      new QuestBoard.Chain(vanillaItem("hay_block"), "Hay Bale Reserve"),
      new QuestBoard.Chain(vanillaItem("dried_kelp"), "Dried Kelp Kitchen"),
      new QuestBoard.Chain(vanillaItem("dried_kelp_block"), "Kelp Fuel Reserve"),
      new QuestBoard.Chain(vanillaItem("cooked_porkchop"), "Pork Supper"),
      new QuestBoard.Chain(vanillaItem("cooked_mutton"), "Mutton Supper"),
      new QuestBoard.Chain(vanillaItem("cooked_rabbit"), "Rabbit Supper"),
      new QuestBoard.Chain(vanillaItem("cookie"), "Cookie Bakery"),
      new QuestBoard.Chain(vanillaItem("pumpkin_pie"), "Pumpkin Pie Bakery"),
      new QuestBoard.Chain(vanillaItem("golden_carrot"), "Golden Carrot Kitchen"),
      new QuestBoard.Chain(vanillaItem("soul_sand"), "Soul Sand Supply"),
      new QuestBoard.Chain(vanillaItem("soul_soil"), "Soul Soil Supply"),
      new QuestBoard.Chain(vanillaItem("basalt"), "Basalt Quarry"),
      new QuestBoard.Chain(vanillaItem("smooth_basalt"), "Smooth Basalt Supply"),
      new QuestBoard.Chain(vanillaItem("magma_block"), "Magma Block Delivery"),
      new QuestBoard.Chain(vanillaItem("nether_brick"), "Nether Brick Furnace"),
      new QuestBoard.Chain(vanillaItem("nether_bricks"), "Fortress Masonry"),
      new QuestBoard.Chain(vanillaItem("crying_obsidian"), "Crying Obsidian Collection"),
      new QuestBoard.Chain(vanillaItem("obsidian"), "Obsidian Quarry"),
      new QuestBoard.Chain(vanillaItem("end_stone"), "End Stone Quarry"),
      new QuestBoard.Chain(vanillaItem("end_stone_bricks"), "End Stone Masonry"),
      new QuestBoard.Chain(vanillaItem("purpur_block"), "Purpur Masonry"),
      new QuestBoard.Chain(vanillaItem("chorus_fruit"), "Chorus Harvest"),
      new QuestBoard.Chain(vanillaItem("popped_chorus_fruit"), "Chorus Furnace"),
      new QuestBoard.Chain(vanillaItem("glowstone"), "Glowstone Lighting"),
      new QuestBoard.Chain(vanillaItem("blaze_powder"), "Blaze Powder Supply"),
      new QuestBoard.Chain(vanillaItem("ender_eye"), "Stronghold Supplies", true),
      new QuestBoard.Chain(vanillaItem("clay"), "Clay Quarry"),
      new QuestBoard.Chain(vanillaItem("terracotta"), "Terracotta Workshop"),
      new QuestBoard.Chain(vanillaItem("white_wool"), "White Wool Delivery"),
      new QuestBoard.Chain(vanillaItem("black_wool"), "Black Wool Delivery"),
      new QuestBoard.Chain(vanillaItem("orange_wool"), "Orange Wool Delivery"),
      new QuestBoard.Chain(vanillaItem("red_wool"), "Red Wool Delivery"),
      new QuestBoard.Chain(vanillaItem("blue_wool"), "Blue Wool Delivery"),
      new QuestBoard.Chain(vanillaItem("green_wool"), "Green Wool Delivery"),
      new QuestBoard.Chain(vanillaItem("prismarine"), "Ocean Monument Masonry"),
      new QuestBoard.Chain(vanillaItem("sea_lantern"), "Sea Lantern Lighting"),
      new QuestBoard.Chain(vanillaItem("arrow"), "Archer's Supplies"),
      new QuestBoard.Chain(vanillaItem("bone_meal"), "Fertilizer Reserve"),
      new QuestBoard.Chain(vanillaItem("book"), "Library Delivery"),
      new QuestBoard.Chain(vanillaItem("copper_block"), "Copper Warehouse"),
      new QuestBoard.Chain(vanillaItem("quartz_block"), "Quartz Masonry")
   );

   private QuestBoard() {
   }

   private static Item vanillaItem(String id) {
      return (Item)BuiltInRegistries.ITEM.getValue(Identifier.withDefaultNamespace(id));
   }

   public static List<QuestBoard.Quest> quests(ShopCatalog catalog) {
      Objects.requireNonNull(catalog, "catalog");
      QuestBoard.CachedBoard cached = cachedBoard;
      if (cached != null && cached.catalog() == catalog) {
         return cached.quests();
      }

      List<QuestBoard.Quest> result = new ArrayList<>(CHAINS.size() * NORMAL_AMOUNTS.length);

      List<QuestBoard.Chain> chains = new ArrayList<>(CHAINS);
      for (String name : List.of("poplar_log", "poplar_planks", "poplar_wood", "stripped_poplar_log", "poplar_shelf",
         "red_poplar_leaves", "orange_poplar_leaves", "yellow_poplar_leaves", "shelf_mushroom", "red_shrub", "white_concrete_stairs", "white_wool_stairs")) {
         Identifier id = Identifier.fromNamespaceAndPath("minecraft", name);
         if (BuiltInRegistries.ITEM.containsKey(id)) {
            Item item = BuiltInRegistries.ITEM.getValue(id);
            chains.add(new QuestBoard.Chain(item, "Wilderness: " + name.replace('_', ' ')));
         }
      }
      for (QuestBoard.Chain chain : chains) {
         Optional<ShopCatalog.Entry> entry = catalog.find(new ItemStack(chain.item()));
         if (!entry.isEmpty() && entry.get().sellPrice() > 0L) {
            long buy = entry.get().buyPrice();
            long sell = entry.get().sellPrice();
            if (sell * 100L <= buy * 70L) {
               String prefix = BuiltInRegistries.ITEM.getKey(chain.item()).getPath();
               int[] amounts = chain.rare() ? RARE_AMOUNTS : NORMAL_AMOUNTS;
               ShopCatalog.Entry companion = companion(catalog, entry.get());

               for (int tier = 0; tier < amounts.length; tier++) {
                  if (tier < 2 || companion != null) {
                     int amount = amounts[tier];
                     long ordinarySale = Math.multiplyExact(amount, sell);
                     long combinedBuy = Math.multiplyExact(amount, buy);
                     List<QuestBoard.Requirement> extras = List.of();
                     if (tier >= 2) {
                        int extraAmount = EXTRA_AMOUNTS[tier];
                        extras = List.of(new QuestBoard.Requirement(companion.item(), extraAmount));
                        ordinarySale = Math.addExact(ordinarySale, Math.multiplyExact(extraAmount, companion.sellPrice()));
                        combinedBuy = Math.addExact(combinedBuy, Math.multiplyExact(extraAmount, companion.buyPrice()));
                     }

                     long bonus = (Math.multiplyExact(ordinarySale, BONUS_PERCENT[tier]) + 99L) / 100L;
                     long buyCap = Math.multiplyExact(combinedBuy, 70L) / 100L;
                     long reward = Math.min(1000000000000L, Math.min(bonus, buyCap));
                     result.add(
                        new QuestBoard.Quest(
                           prefix + "_" + (tier + 1),
                           chain.title() + " " + (tier + 1),
                           chain.item(),
                           amount,
                           reward,
                           tier == 0 ? "" : prefix + "_" + tier,
                           extras,
                           tier + 1
                        )
                     );
                  }
               }
            }
         }
      }

      List<QuestBoard.Quest> board = List.copyOf(result);
      cachedBoard = new QuestBoard.CachedBoard(catalog, board);
      return board;
   }

   public static int owned(QuestBoard.Quest quest, Container inventory) {
      Objects.requireNonNull(quest, "quest");
      return owned(new QuestBoard.Requirement(quest.item(), quest.amount()), inventory);
   }

   public static int owned(QuestBoard.Requirement requirement, Container inventory) {
      Objects.requireNonNull(requirement, "requirement");
      long total = 0L;
      ItemStack plain = new ItemStack(requirement.item());

      for (int slot = 0; slot < limit(inventory); slot++) {
         ItemStack stack = inventory.getItem(slot);
         if (matches(stack, plain)) {
            total += stack.getCount();
         }
      }

      return (int)Math.min(2147483647L, total);
   }

   public static boolean canComplete(QuestBoard.Quest quest, Container inventory) {
      Objects.requireNonNull(quest, "quest");

      for (QuestBoard.Requirement requirement : quest.requirements()) {
         if (owned(requirement, inventory) < requirement.amount()) {
            return false;
         }
      }

      return true;
   }

   public static QuestBoard.Quote quote(QuestBoard.Quest quest, Container inventory) {
      return new QuestBoard.Quote(owned(quest, inventory), quest.amount(), quest.reward());
   }

   public static ShopTransactions.Result complete(
      QuestBoard.Quest quest, Container inventory, List<ItemStack> snapshot, QuestProgress progress, Wallets wallets, UUID player, long startingBalance
   ) {
      Objects.requireNonNull(quest, "quest");
      Objects.requireNonNull(progress, "progress");
      Objects.requireNonNull(wallets, "wallets");
      Objects.requireNonNull(player, "player");
      if (progress.completed(player, quest.id())) {
         return failure("You already completed this delivery.");
      }

      if (!progress.ready(player, quest)) {
         return failure("Complete the previous delivery tier first.");
      }

      int slots = limit(inventory);
      if (snapshot != null && snapshot.size() == slots) {
         List<QuestBoard.Delivery> delivery = new ArrayList<>();
         int deliveredCount = 0;

         for (QuestBoard.Requirement requirement : quest.requirements()) {
            ItemStack plain = new ItemStack(requirement.item());
            int remaining = requirement.amount();

            for (int slot = 0; slot < slots && remaining > 0; slot++) {
               ItemStack reviewed = snapshot.get(slot);
               if (matches(reviewed, plain)) {
                  int take = Math.min(remaining, reviewed.getCount());
                  delivery.add(new QuestBoard.Delivery(slot, take));
                  remaining -= take;
               }
            }

            if (remaining != 0) {
               return failure("You need " + requirement.amount() + " ordinary " + plain.getHoverName().getString() + " for this delivery.");
            }

            deliveredCount = Math.addExact(deliveredCount, requirement.amount());
         }

         for (QuestBoard.Delivery part : delivery) {
            if (!ItemStack.matches(inventory.getItem(part.slot()), snapshot.get(part.slot()))) {
               return failure("Your delivery items changed. Review the quest again; your items were kept.");
            }
         }

         if (!wallets.credit(player, startingBalance, quest.reward())) {
            return failure("This reward would exceed the balance limit. Your items were kept.");
         }

         for (QuestBoard.Delivery part : delivery) {
            ItemStack remainder = inventory.getItem(part.slot()).copy();
            remainder.shrink(part.amount());
            inventory.setItem(part.slot(), remainder.isEmpty() ? ItemStack.EMPTY : remainder);
         }

         inventory.setChanged();
         progress.complete(player, quest.id());
         return new ShopTransactions.Result(
            true, "Completed " + quest.title() + "! Earned " + ShopTransactions.money(quest.reward()) + ".", deliveredCount, quest.reward()
         );
      } else {
         return failure("Review this delivery again before confirming.");
      }
   }

   private static ShopCatalog.Entry companion(ShopCatalog catalog, ShopCatalog.Entry primary) {
      Item preferred = switch (primary.category()) {
         case FARMING -> primary.item() == Items.CARROT ? Items.WHEAT : Items.CARROT;
         case FOOD -> Items.WHEAT;
         case WOOD_NATURE -> Items.COAL;
         case RESOURCES -> primary.item() == Items.IRON_INGOT ? Items.COAL : Items.IRON_INGOT;
         case MOB_DROPS -> Items.ARROW;
         case BUILDING -> Items.OAK_LOG;
         case NETHER_END -> Items.GOLD_INGOT;
         default -> Items.COBBLESTONE;
      };

      for (Item item : List.of(preferred, Items.COAL, Items.OAK_LOG)) {
         if (item != primary.item()) {
            Optional<ShopCatalog.Entry> candidate = catalog.find(new ItemStack(item));
            if (candidate.isPresent() && candidate.get().sellPrice() > 0L && candidate.get().sellPrice() * 100L <= candidate.get().buyPrice() * 70L) {
               return candidate.get();
            }
         }
      }

      return null;
   }

   private static boolean matches(ItemStack stack, ItemStack plain) {
      return stack != null && !stack.isEmpty() && ItemStack.isSameItemSameComponents(stack, plain);
   }

   private static int limit(Container inventory) {
      return Math.min(36, Objects.requireNonNull(inventory, "inventory").getContainerSize());
   }

   private static ShopTransactions.Result failure(String message) {
      return new ShopTransactions.Result(false, message, 0, 0L);
   }

   private record CachedBoard(ShopCatalog catalog, List<QuestBoard.Quest> quests) {
   }

   private record Chain(Item item, String title, boolean rare) {
      Chain(Item item, String title) {
         this(item, title, false);
      }
   }

   private record Delivery(int slot, int amount) {
   }

   public record Quest(String id, String title, Item item, int amount, long reward, String prerequisite, List<QuestBoard.Requirement> extras, int tier) {
      public Quest(String id, String title, Item item, int amount, long reward, String prerequisite) {
         this(id, title, item, amount, reward, prerequisite, List.of(), tierFromId(id));
      }

      public Quest {
         if (!QuestProgress.validId(id)) {
            throw new IllegalArgumentException("Invalid quest ID");
         }

         Objects.requireNonNull(title, "title");
         Objects.requireNonNull(item, "item");
         Objects.requireNonNull(prerequisite, "prerequisite");
         extras = List.copyOf(Objects.requireNonNull(extras, "extras"));
         if (title.isBlank()
            || title.length() > 96
            || item == Items.AIR
            || amount < 1
            || amount > 2048
            || reward < 1L
            || reward > 1000000000000L
            || tier < 1
            || tier > 6
            || extras.size() > 1
            || !prerequisite.isEmpty() && !QuestProgress.validId(prerequisite)
            || prerequisite.equals(id)) {
            throw new IllegalArgumentException("Invalid quest definition");
         }

         if (extras.stream().anyMatch(requirement -> requirement.item() == item)) {
            throw new IllegalArgumentException("Quest materials must be distinct");
         }
      }

      public List<QuestBoard.Requirement> requirements() {
         List<QuestBoard.Requirement> requirements = new ArrayList<>(this.extras.size() + 1);
         requirements.add(new QuestBoard.Requirement(this.item, this.amount));
         requirements.addAll(this.extras);
         return List.copyOf(requirements);
      }

      public String tierName() {
         return switch (this.tier) {
            case 1 -> "Apprentice";
            case 2 -> "Expert";
            case 3 -> "Elite";
            case 4 -> "Master";
            case 5 -> "Champion";
            default -> "Legend";
         };
      }

      private static int tierFromId(String id) {
         return id != null && id.matches(".*_[1-6]") ? id.charAt(id.length() - 1) - 48 : 1;
      }
   }

   public record Quote(int owned, int required, long reward) {
   }

   public record Requirement(Item item, int amount) {
      public Requirement(Item item, int amount) {
         Objects.requireNonNull(item, "item");
         if (item != Items.AIR && amount >= 1 && amount <= 2048) {
            this.item = item;
            this.amount = amount;
         } else {
            throw new IllegalArgumentException("Invalid quest material requirement");
         }
      }
   }
}
