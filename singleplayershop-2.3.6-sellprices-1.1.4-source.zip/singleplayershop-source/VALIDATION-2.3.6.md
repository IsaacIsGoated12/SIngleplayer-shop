# Release validation: Singleplayer Shop 2.3.6 / Sell Prices 1.1.4

## Finished release JARs

The same Java 25 bytecode from the delivered JARs was tested against each Minecraft runtime. Class entries were compared byte-for-byte with the builder output; ZIP integrity, metadata, version manifests, catalog schema 6, all 1,913 bundled listings, and the addon's compatible shop range were checked.

| Minecraft | Active listings | Delivery quests | Passed assertions |
|---|---:|---:|---:|
| 26.1.2 | 1,778 | 912 | 11,532 |
| 26.2 | 1,808 | 912 | 11,681 |
| 26.3 | 1,913 | 984 | 12,350 |

The initial source also compiled against all three versions. The final shared release was compiled against 26.3, then exercised on the earlier runtimes. Earlier versions skip unavailable newer item IDs.

## Covered behavior

- Every active catalog listing: natural server/client price agreement, purchased resale rejection and default natural payout below purchase cost.
- 84 distinct gear/tool types: enchantment value, proportional damage discount and synchronized prices; 128 enchanted-book variants, including curses and all configured levels.
- Wooden-to-netherite material progression, independent tool-type factors, six-figure premium tools/books, $120,000 base elytra, $300,600 enchanted elytra and $150,300 half-worn elytra.
- Maximum-level bonuses, exact receipt reconciliation, rarity thresholds, extreme custom price caps, invalid enchantment levels and named enchanted items.
- Inventory rankings, correct totals, protected stack counts, non-mutating appraisals, actual-value earning-guide sorting and natural-only book counts.
- Detailed/compact/disabled tooltips, individual enchantment detail toggle, condition, discounts, potential full-condition value and stack math.
- Catalog migrations from v1/v3/v4/v5, exact backups, independent custom price preservation, custom elytra prices, intentional removed listings, invalid configuration rejection and idempotent migration.
- Wallet balance persistence, safe transfer/debit/credit, limits, capacity-aware purchases and separation of purchased/natural stacks.
- Inventory and double-chest sales, shulker contents, named items and nested storage protection, exact reviewed payouts, protected slots never rewritten, duplicate payouts refused, stale hopper/player changes refused and full-wallet rejection.
- Sell Axe identity, netherite-only construction, name, all five compatible maximum enchantments, shop purchase and resale refusal, and most-valuable storage preview data.
- Quest identities, reward bounds and saved progress; chunked network snapshots, exact catalog decoding, connection isolation, out-of-order recovery, stale revision refusal, disconnect cleanup and explicit rejection of old protocol 2 data.

Fabric Loader 0.19.5 with Fabric API 0.163.0+26.3 also loaded both final JARs through Knot on server and client environments. Main entrypoints and the client initializer completed successfully. These smoke checks initialize the actual mod callbacks; they do not simulate a complete world/player session.

## Expanded storage tests

32 vanilla storage block variants are recognized and inspected, including all 17 shulker variants. Thirty of these use their actual vanilla inventory implementation for reviewed sales and protected-item checks. Chiseled bookshelf and jukebox tests cover recognition and empty inspection; their editing callbacks require a live level and were not simulated.

Separate tests cover personal Ender Chest inventory isolation, rejection of a review against another inventory, recreated double-chest wrappers, replaced chest halves, unopened barrel loot remaining untouched, 108-slot compatible storage, excessive-size rejection, read-only inventory write rejection and rollback after a partially applied write fails. Storage block entities remain present after the tested inventory transactions.

The new world access resolver follows vanilla lock, reach, chest-obstruction and shulker-opening rules. Automated inventory tests do not exercise a live player's attack packets or a live world's obstruction/protection callbacks; these still need graphical playtesting.

## Economy audit

The default catalog was checked against 1,664 vanilla recipe routes, including multi-step ingredients, tag alternatives, cooking, stonecutting and smithing transforms. Template duplication uses marginal cost. No profitable modeled plain-item buy/craft/resell route remained. Furnace fuel is ignored conservatively. The maximum equipment enchantment factor and loadout bonus recover at most 92% of matching book retail cost, before wear/curses, with integer rounding downward.

The model excludes villager trades, farms, loot generation, modded recipes and component-dependent/dynamic recipes. It does not establish a universal exploit-free economy or substitute for survival playtesting. See `balance-report-2.3.6.json`.

## Practical limits

- No graphical world playthrough, live storage swing/confirmation, death/respawn interaction or cross-machine LAN/e4mc session was performed.
- The purchase marker cannot recognize purchases from versions before the marker existed. It follows item components, without global ingredient/block provenance.
- Fabric claim/protection integrations outside vanilla access rules are not implemented.
- The Gradle/Loom downloader could not complete in this desktop environment because of a Java loopback-connection error. The included Python/JDK builder compiled the release and ran its tests successfully.
- These builds are local artifacts; they have not been published to Modrinth.
