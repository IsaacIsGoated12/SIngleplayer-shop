package dev.isaac.pocketshop;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.LongArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import java.util.IdentityHashMap;
import java.util.Map;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents.EndTick;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

final class PayCommand {
   private static final Map<MinecraftServer, Boolean> LAN_STATES = new IdentityHashMap<>();

   private PayCommand() {
   }

   static void initialize() {
      ServerTickEvents.END_SERVER_TICK.register((EndTick)server -> {
         boolean available = isLanWorld(server);
         Boolean previous = LAN_STATES.put(server, available);
         if (available != Boolean.TRUE.equals(previous)) {
            for (ServerPlayer player : server.getPlayerList().getPlayers()) {
               server.getCommands().sendCommands(player);
            }
         }
      });
      ServerLifecycleEvents.SERVER_STOPPED.register(LAN_STATES::remove);
   }

   static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
      dispatcher.register(
         (LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("pay").requires(PayCommand::available))
               .executes(context -> fail(((CommandSourceStack)context.getSource()).getPlayerOrException(), "Use /pay <player> <amount>.")))
            .then(
               Commands.argument("player", StringArgumentType.word())
                  .suggests(
                     (context, builder) -> SharedSuggestionProvider.suggest(
                        ((CommandSourceStack)context.getSource())
                           .getServer()
                           .getPlayerList()
                           .getPlayers()
                           .stream()
                           .filter(player -> player != ((CommandSourceStack)context.getSource()).getPlayer())
                           .map(player -> player.getGameProfile().name()),
                        builder
                     )
                  )
                  .then(
                     Commands.argument("amount", LongArgumentType.longArg(1L, 1000000000000L))
                        .executes(
                           context -> pay(
                              (CommandSourceStack)context.getSource(),
                              StringArgumentType.getString(context, "player"),
                              LongArgumentType.getLong(context, "amount")
                           )
                        )
                  )
            )
      );
   }

   private static boolean isLanWorld(MinecraftServer server) {
      return server.isSingleplayer() && !server.isDedicatedServer() && server.isPublished();
   }

   private static boolean available(CommandSourceStack source) {
      return source.getPlayer() != null && isLanWorld(source.getServer());
   }

   private static int pay(CommandSourceStack source, String recipientName, long amount) {
      ServerPlayer sender = source.getPlayer();
      if (sender == null) {
         return 0;
      }

      if (!available(source)) {
         return fail(sender, "Payments are available only while this world is open to LAN.");
      }

      MinecraftServer server = source.getServer();
      if (server.getPlayerList().getPlayer(sender.getUUID()) != sender) {
         return 0;
      }

      ServerPlayer recipient = server.getPlayerList().getPlayerByName(recipientName);
      if (recipient == null) {
         return fail(sender, "That player is not online in this world.");
      }

      Wallets.TransferResult result = Wallets.get(server).transfer(sender.getUUID(), recipient.getUUID(), PocketShop.catalog().startingBalance(), amount);
      if (result != Wallets.TransferResult.SUCCESS) {
         return fail(sender, switch (result) {
            case INVALID_AMOUNT -> "Enter a positive whole-number amount up to " + ShopTransactions.money(1000000000000L) + ".";
            case SELF_PAYMENT -> "You cannot pay yourself.";
            case INSUFFICIENT_FUNDS -> "You do not have enough money for that payment.";
            case RECIPIENT_FULL -> "That payment would exceed the recipient's balance limit.";
            case SUCCESS -> throw new IllegalStateException("Unexpected successful transfer");
         });
      } else {
         String payment = ShopTransactions.money(amount);
         PocketShop.feedback(
            sender,
            new ShopTransactions.Result(
               true,
               "Paid " + payment + " to " + recipient.getGameProfile().name() + ". Your balance is " + ShopTransactions.money(PocketShop.balance(sender)) + ".",
               0,
               amount
            )
         );
         PocketShop.feedback(
            recipient,
            new ShopTransactions.Result(
               true,
               "Received "
                  + payment
                  + " from "
                  + sender.getGameProfile().name()
                  + ". Your balance is "
                  + ShopTransactions.money(PocketShop.balance(recipient))
                  + ".",
               0,
               amount
            )
         );
         return 1;
      }
   }

   private static int fail(ServerPlayer player, String message) {
      PocketShop.feedback(player, new ShopTransactions.Result(false, message, 0, 0L));
      return 0;
   }
}
