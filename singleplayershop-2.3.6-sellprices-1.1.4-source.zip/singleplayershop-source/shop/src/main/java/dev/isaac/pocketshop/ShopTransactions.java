package dev.isaac.pocketshop;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import net.minecraft.world.Container;
import net.minecraft.world.item.ItemStack;

public final class ShopTransactions {
   private final ShopCatalog catalog;

   public ShopTransactions(ShopCatalog catalog) {
      this.catalog = catalog;
   }

   public static String money(long amount) {
      return "$" + NumberFormat.getIntegerInstance(Locale.US).format(amount);
   }

   public int capacity(Container inventory, int slots, ItemStack item) {
      int space = 0;
      int limit = Math.min(item.getMaxStackSize(), inventory.getMaxStackSize());

      for (int i = 0; i < slots; i++) {
         ItemStack existing = inventory.getItem(i);
         if (existing.isEmpty()) {
            space += limit;
         } else if (ItemStack.isSameItemSameComponents(existing, item)) {
            space += Math.max(0, limit - existing.getCount());
         }
      }

      return space;
   }

   public int maxBuy(Container inventory, int slots, Wallets wallets, UUID player, ShopCatalog.Entry entry) {
      long affordable = wallets.balance(player, this.catalog.startingBalance()) / entry.buyPrice();
      return (int)Math.min(2304L, Math.min(affordable, this.capacity(inventory, slots, PurchaseOrigin.purchasedCopy(entry.stack()))));
   }

   public ShopTransactions.Result buy(Container inventory, int slots, Wallets wallets, UUID player, ShopCatalog.Entry entry, int quantity) {
      if (quantity >= 1 && quantity <= 2304) {
         long cost = Math.multiplyExact(entry.buyPrice(), quantity);
         if (wallets.balance(player, this.catalog.startingBalance()) < cost) {
            return failure("You need " + money(cost) + " for this purchase.");
         }

        ItemStack template = PurchaseOrigin.purchasedCopy(entry.stack());
         if (this.capacity(inventory, slots, template) < quantity) {
            return failure("Make some room in your inventory first.");
         }

         List<ItemStack> planned = new ArrayList<>();

         for (int i = 0; i < slots; i++) {
            planned.add(inventory.getItem(i).copy());
         }

         int remaining = quantity;
         int limit = Math.min(template.getMaxStackSize(), inventory.getMaxStackSize());

         for (ItemStack existing : planned) {
            if (!existing.isEmpty() && ItemStack.isSameItemSameComponents(existing, template)) {
               int add = Math.min(remaining, Math.max(0, limit - existing.getCount()));
               existing.grow(add);
               remaining -= add;
            }
         }

         for (int i = 0; i < slots && remaining > 0; i++) {
            if (planned.get(i).isEmpty()) {
               int add = Math.min(remaining, limit);
               planned.set(i, template.copyWithCount(add));
               remaining -= add;
            }
         }

         if (remaining != 0) {
            return failure("The purchase could not fit. Nothing was charged.");
         }

         if (!wallets.debit(player, this.catalog.startingBalance(), cost)) {
            return failure("Your balance has changed. Try again.");
         }

         for (int i = 0; i < slots; i++) {
            inventory.setItem(i, planned.get(i));
         }

         inventory.setChanged();
         return new ShopTransactions.Result(true, "Bought " + quantity + " x " + entry.displayName() + " for " + money(cost) + ". Shop purchases cannot be resold.", quantity, cost);
      } else {
         return failure("Choose a quantity from 1 to 2,304.");
      }
   }

   public ShopTransactions.Quote quote(Container inventory, int from, int to) {
      return this.planSale(inventory, from, to).quote();
   }

   public ShopTransactions.Result sell(Container inventory, int from, int to, Wallets wallets, UUID player) {
      ShopTransactions.Sale sale = this.planSale(inventory, from, to);
      if (!sale.valid()) {
         return failure("That sale is too large or its inventory slots are invalid. Your items were kept.");
      }

      ShopTransactions.Quote quote = sale.quote();
      if (quote.count() == 0) {
         return failure("No eligible items. Shop purchases and protected contents are kept.");
      }

      for (ShopTransactions.SoldSlot slot : sale.slots()) {
         if (!ItemStack.matches(inventory.getItem(slot.slot()), slot.original())) {
            return failure("Your items changed. Try the sale again.");
         }
      }

      if (!wallets.credit(player, this.catalog.startingBalance(), quote.total())) {
         return failure("This sale would exceed the balance limit. Your items were kept.");
      }

      for (ShopTransactions.SoldSlot slot : sale.slots()) {
         inventory.setItem(slot.slot(), slot.remaining());
      }

      inventory.setChanged();
      return new ShopTransactions.Result(true, "Sold " + quote.count() + " items for " + money(quote.total()) + ".", quote.count(), quote.total());
   }

   private ShopTransactions.Sale planSale(Container inventory, int from, int to) {
      if (from >= 0 && to >= from && to <= Math.min(36, inventory.getContainerSize())) {
         List<ShopTransactions.SoldSlot> slots = new ArrayList<>();
         int count = 0;
         long total = 0L;

         try {
            for (int slot = from; slot < to; slot++) {
               ItemStack original = inventory.getItem(slot).copy();
               SaleContents.Plan plan = SaleContents.plan(original, this.catalog::sellPrice);
               if (!plan.valid()) {
                  return invalidSale();
               }

               if (plan.count() != 0) {
                  count = Math.addExact(count, plan.count());
                  total = Math.addExact(total, plan.total());
                  slots.add(new ShopTransactions.SoldSlot(slot, original, plan.remaining()));
               }
            }
         } catch (ArithmeticException overflow) {
            return invalidSale();
         }

         return new ShopTransactions.Sale(List.copyOf(slots), new ShopTransactions.Quote(count, total), true);
      } else {
         return invalidSale();
      }
   }

   private static ShopTransactions.Sale invalidSale() {
      return new ShopTransactions.Sale(List.of(), new ShopTransactions.Quote(0, 0L), false);
   }

   private static ShopTransactions.Result failure(String message) {
      return new ShopTransactions.Result(false, message, 0, 0L);
   }

   public record Quote(int count, long total) {
   }

   public record Result(boolean success, String message, int count, long total) {
   }

   private record Sale(List<ShopTransactions.SoldSlot> slots, ShopTransactions.Quote quote, boolean valid) {
   }

   private record SoldSlot(int slot, ItemStack original, ItemStack remaining) {
   }
}
