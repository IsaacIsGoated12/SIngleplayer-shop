package dev.isaac.pocketshop;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.Strictness;
import com.mojang.serialization.JsonOps;
import dev.isaac.pocketshop.ShopCatalog.Category;
import dev.isaac.pocketshop.ShopCatalog.Entry;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import net.minecraft.core.HolderLookup.Provider;
import net.minecraft.resources.RegistryOps;
import net.minecraft.world.item.ItemStack;

public final class PriceCatalogCodec {
   public static final int MAX_ENTRIES = 10240;
   public static final long MAX_PRICE = 1000000000L;
   private static final Gson GSON = new GsonBuilder().setStrictness(Strictness.STRICT).create();

   private PriceCatalogCodec() {
   }

   public static String encode(ShopCatalog catalog, Provider registries) {
      Objects.requireNonNull(catalog, "catalog");
      RegistryOps<JsonElement> ops = Objects.requireNonNull(registries, "registries").createSerializationContext(JsonOps.INSTANCE);
      JsonArray rows = new JsonArray();

      for (Category category : Category.values()) {
         for (Entry entry : catalog.entries(category)) {
            ItemStack source = entry.stack();
            JsonObject row = new JsonObject();
            row.add("stack", (JsonElement)ItemStack.CODEC.encodeStart(ops, source).getOrThrow());
            row.addProperty("sell", entry.sellPrice());
            row.addProperty("buy", entry.buyPrice());
            rows.add(row);
            if (rows.size() > 10240) {
               throw invalid("Too many shop price templates");
            }
         }
      }

      JsonObject envelope=new JsonObject();envelope.addProperty("schema",3);envelope.add("entries",rows);
      String document = envelope.toString();
      if (document.length() > 6144000) {
         throw invalid("Shop price catalog is too large");
      } else {
         return document;
      }
   }

   public static SellPriceIndex decode(String document, Provider registries) {
      Objects.requireNonNull(registries, "registries");
      validateJsonSizeAndDepth(document);
      JsonElement parsed = (JsonElement)GSON.fromJson(document, JsonElement.class);
      if (parsed != null && parsed.isJsonObject()
         && parsed.getAsJsonObject().keySet().equals(Set.of("schema","entries"))
         && parsed.getAsJsonObject().get("schema").isJsonPrimitive()
         && parsed.getAsJsonObject().getAsJsonPrimitive("schema").isNumber()
         && parsed.getAsJsonObject().get("schema").getAsString().equals("3")
         && parsed.getAsJsonObject().get("entries").isJsonArray()
         && parsed.getAsJsonObject().getAsJsonArray("entries").size() <= 10240) {
         RegistryOps<JsonElement> ops = registries.createSerializationContext(JsonOps.INSTANCE);
         List<SellPriceIndex.Template> templates = new ArrayList<>();

         for (JsonElement element : parsed.getAsJsonObject().getAsJsonArray("entries")) {
            if (!element.isJsonObject()) {
               throw invalid("Invalid shop price row");
            }

            JsonObject row = element.getAsJsonObject();
            if (row.keySet().equals(Set.of("stack", "sell", "buy")) && row.get("sell").isJsonPrimitive() && row.getAsJsonPrimitive("sell").isNumber()
               && row.get("buy").isJsonPrimitive() && row.getAsJsonPrimitive("buy").isNumber()) {
               String number = row.get("sell").getAsString();
               if (!number.matches("0|[1-9][0-9]{0,9}")) {
                  throw invalid("Invalid shop sale price");
               }

               long price = Long.parseLong(number);
               String buyNumber=row.get("buy").getAsString();
               if(!buyNumber.matches("[1-9][0-9]{0,9}")) throw invalid("Invalid shop buy price");
               long buy=Long.parseLong(buyNumber);
               if(buy>MAX_PRICE || price>buy) throw invalid("Invalid shop price pair");
               if (price > 1000000000L) {
                  throw invalid("Shop sale price exceeds the limit");
               }

               ItemStack stack = (ItemStack)ItemStack.CODEC.parse(ops, row.get("stack")).getOrThrow();
               if (!stack.isEmpty() && stack.getCount() == 1) {
                  templates.add(new SellPriceIndex.Template(stack, price, buy));
                  continue;
               }

               throw invalid("Invalid shop item template");
            }

            throw invalid("Invalid shop price fields");
         }

         return SellPriceIndex.fromTemplates(templates);
      } else {
         throw invalid("Invalid price template list");
      }
   }

   private static void validateJsonSizeAndDepth(String document) {
      if (document != null && !document.isEmpty() && document.length() <= 6144000) {
         int depth = 0;
         boolean string = false;
         boolean escaped = false;

         for (int index = 0; index < document.length(); index++) {
            char value = document.charAt(index);
            if (string) {
               if (escaped) {
                  escaped = false;
               } else if (value == '\\') {
                  escaped = true;
               } else if (value == '"') {
                  string = false;
               }
            } else if (value == '"') {
               string = true;
            } else if (value == '[' || value == '{') {
               if (++depth > 64) {
                  throw invalid("Shop item components are nested too deeply");
               }
            } else if (value == ']' || value == '}') {
               if (--depth < 0) {
                  throw invalid("Unbalanced shop catalog");
               }
            }
         }

         if (string || depth != 0) {
            throw invalid("Incomplete shop catalog");
         }
      } else {
         throw invalid("Invalid shop catalog size");
      }
   }

   private static IllegalArgumentException invalid(String message) {
      return new IllegalArgumentException(message);
   }
}
