package dev.isaac.pocketshop;

import java.util.*;
import net.minecraft.world.Container;
import net.minecraft.world.item.ItemStack;

/** A non-mutating inventory overview, including the true eligible contents of shulkers. */
public final class InventoryAppraisal {
   private InventoryAppraisal() {}
   public static Summary inspect(Container inventory,int limit,ShopCatalog catalog) {
      List<Valuable> values=new ArrayList<>();int count=0,kept=0;long total=0;
      for(int slot=0;slot<Math.min(limit,inventory.getContainerSize());slot++) {
         ItemStack stack=inventory.getItem(slot);
         if(stack.isEmpty()) continue;
         var plan=SaleContents.plan(stack,catalog::sellPrice);
         if(!plan.valid()) throw new IllegalArgumentException("Inventory exceeds safe valuation limit");
         count=Math.addExact(count,plan.count());total=Math.addExact(total,plan.total());
         if(!plan.remaining().isEmpty()) kept++;
         if(plan.count()>0) values.add(new Valuable(slot,stack.getHoverName().getString()+(SaleContents.isShulker(stack)?" (contents)":""),plan.count(),plan.total()));
      }
      values.sort(Comparator.comparingLong(Valuable::total).reversed().thenComparingInt(Valuable::slot));
      return new Summary(count,total,kept,values.stream().limit(5).toList());
   }
   public record Valuable(int slot,String name,int count,long total) {}
   public record Summary(int count,long total,int keptStacks,List<Valuable> top) {public Summary {top=List.copyOf(top);}}
}
